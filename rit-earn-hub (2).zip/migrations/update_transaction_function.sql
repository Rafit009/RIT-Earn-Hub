-- Update the function to use settings from the database
CREATE OR REPLACE FUNCTION update_transaction_status(
transaction_type TEXT,
transaction_id UUID,
new_status TEXT,
updated_via TEXT DEFAULT 'admin_panel'
)
RETURNS BOOLEAN AS $$
DECLARE
transaction_record RECORD;
user_id UUID;
amount DECIMAL;
should_activate BOOLEAN := FALSE;
user_record RECORD;
payment_method TEXT;
activation_amount DECIMAL;
currency_symbol TEXT;
BEGIN
-- Get the transaction details
EXECUTE format('
  SELECT * FROM %I WHERE id = $1
', transaction_type)
INTO transaction_record
USING transaction_id;

IF transaction_record IS NULL THEN
  RAISE EXCEPTION 'Transaction not found';
END IF;

-- Extract common fields
user_id := transaction_record.user_id;
amount := transaction_record.amount;

-- Get the payment method (could be in different columns)
payment_method := COALESCE(transaction_record.method, transaction_record.payment_method, 'unknown');

-- Get settings
SELECT COALESCE((SELECT value::text::numeric FROM settings WHERE key = 'activation_amount'), 50) INTO activation_amount;
SELECT COALESCE((SELECT value::text FROM settings WHERE key = 'currency_symbol'), '৳') INTO currency_symbol;

-- Check if this is a deposit and the status is being set to 'completed'
IF transaction_type = 'deposits' AND new_status = 'completed' THEN
 
  -- Check if the user account should be activated
  SELECT amount >= activation_amount INTO should_activate
  FROM profiles
  WHERE id = user_id AND is_active = false;
  
  -- If account needs to be activated, update the profile first
  IF should_activate THEN
    UPDATE profiles
    SET 
      is_active = TRUE,
      balance = COALESCE(balance, 0) + amount,
      total_earnings = COALESCE(total_earnings, 0) + amount,
      updated_at = NOW()
    WHERE id = user_id;
     -- Log the account activation
     INSERT INTO activity_log (
       user_id,
       activity_type,
       description,
       metadata
     ) VALUES (
       user_id,
       'account_activated',
       format('Account activated with deposit of %s%s', amount, currency_symbol),
       jsonb_build_object(
         'transaction_id', transaction_id,
         'amount', amount,
         'payment_method', payment_method
       )
     );

  ELSE
    UPDATE profiles
    SET 
      balance = COALESCE(balance, 0) + amount,
      total_earnings = COALESCE(total_earnings, 0) + amount,
      updated_at = NOW()
    WHERE id = user_id;
  END IF;
END IF;

-- Now update the transaction status 
EXECUTE format('
  UPDATE %I 
  SET status = $1, updated_at = NOW()
  WHERE id = $2
', transaction_type)
USING new_status, transaction_id;

-- Now do the activity log entry
IF transaction_type = 'deposits' THEN
  INSERT INTO activity_log (
    user_id,
    activity_type,
    description,
    metadata
  ) VALUES (
    user_id,
    new_status || '_deposit',
    CASE new_status
      WHEN 'completed' THEN format('Your deposit of %s%s has been approved', amount, currency_symbol)
      WHEN 'failed' THEN format('Your deposit of %s%s has been declined', amount, currency_symbol)
      ELSE 'Unknown status update'
    END,
    jsonb_build_object(
      'transaction_id', transaction_id,
      'amount', amount,
      'method', payment_method
    )
  );
END IF;

-- Handle other transaction types if required
IF transaction_type = 'withdrawals' THEN
    INSERT INTO activity_log (
      user_id,
      activity_type,
      description,
      metadata
    ) VALUES (
      user_id,
      new_status || '_withdrawal',
      CASE new_status
        WHEN 'completed' THEN format('Your withdrawal of %s%s has been approved', amount, currency_symbol)
        WHEN 'failed' THEN format('Your withdrawal of %s%s has been declined', amount, currency_symbol)
        ELSE 'Unknown status update'
      END,
      jsonb_build_object(
        'transaction_id', transaction_id,
        'amount', amount,
        'method', payment_method
      )
    );
 END IF;
RETURN TRUE;
EXCEPTION
WHEN OTHERS THEN
  RAISE NOTICE 'Error in update_transaction_status: %', SQLERRM;
  RETURN FALSE;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
