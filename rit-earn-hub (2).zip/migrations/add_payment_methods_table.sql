-- Create payment_methods table to store payment method configurations
CREATE TABLE IF NOT EXISTS payment_methods (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL,
  display_name TEXT NOT NULL,
  account_number TEXT NOT NULL,
  instructions TEXT,
  is_active BOOLEAN DEFAULT true,
  for_deposit BOOLEAN DEFAULT true,
  for_withdrawal BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Insert default payment methods
INSERT INTO payment_methods (name, display_name, account_number, instructions, is_active, for_deposit, for_withdrawal)
VALUES 
  ('nagad', 'Nagad', '01736392836', 'Send money to this Nagad number and provide the transaction ID.', true, true, true),
  ('bkash', 'bKash', '01833486175', 'Send money to this bKash number and provide the transaction ID.', true, true, true);

-- Add RLS policies
ALTER TABLE payment_methods ENABLE ROW LEVEL SECURITY;

-- Anyone can view active payment methods
CREATE POLICY "Anyone can view active payment methods" 
  ON payment_methods FOR SELECT 
  USING (is_active = true);

-- Only admins can modify payment methods
CREATE POLICY "Only admins can modify payment methods" 
  ON payment_methods FOR ALL 
  USING (
    (SELECT is_admin FROM profiles WHERE id = auth.uid())
  );
