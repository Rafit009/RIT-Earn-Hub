-- Update RLS policies for settings table

-- Drop existing policies
DROP POLICY IF EXISTS settings_admin_all ON settings;
DROP POLICY IF EXISTS settings_read_all ON settings;

-- Only allow admins to update settings
CREATE POLICY settings_admin_all ON settings
  FOR ALL
  USING (
    (SELECT is_admin FROM profiles WHERE id = auth.uid())
  );

-- Allow all authenticated users to read public settings
CREATE POLICY settings_public_read ON settings
  FOR SELECT
  USING (
    key IN ('platform_name', 'currency_symbol', 'min_deposit', 'min_withdrawal', 'maintenance_mode')
  );
