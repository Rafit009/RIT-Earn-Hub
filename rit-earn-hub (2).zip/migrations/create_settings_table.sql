-- Create settings table
CREATE TABLE IF NOT EXISTS settings (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  key TEXT NOT NULL UNIQUE,
  value JSONB NOT NULL,
  description TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Insert default settings
INSERT INTO settings (key, value, description) VALUES
('platform_name', '"RIT Earn Hub"', 'Name of the platform'),
('admin_email', '"admin@ritearnhub.com"', 'Admin email address'),
('deposit_fee', '0', 'Deposit fee percentage'),
('withdrawal_fee', '0', 'Withdrawal fee percentage'),
('min_deposit', '50', 'Minimum deposit amount'),
('min_withdrawal', '50', 'Minimum withdrawal amount'),
('referral_bonus', '35', 'Bonus amount for referrer'),
('referred_bonus', '10', 'Bonus amount for referred user'),
('activation_amount', '50', 'Minimum amount to activate account'),
('maintenance_mode', 'false', 'Whether the platform is in maintenance mode'),
('currency_symbol', '"৳"', 'Currency symbol used throughout the platform');

-- Add RLS policies
ALTER TABLE settings ENABLE ROW LEVEL SECURITY;

-- Only allow admins to update settings
CREATE POLICY settings_admin_all ON settings
  USING (
    (SELECT is_admin FROM profiles WHERE id = auth.uid())
  );

-- Allow all authenticated users to read settings
CREATE POLICY settings_read_all ON settings
  FOR SELECT
  USING (auth.role() = 'authenticated');
