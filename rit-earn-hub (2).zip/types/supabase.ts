export type Json = string | number | boolean | null | { [key: string]: Json | undefined } | Json[]

export interface Database {
  public: {
    Tables: {
      activity_log: {
        Row: {
          activity_type: string
          created_at: string
          description: string | null
          id: string
          metadata: Json | null
          user_id: string | null
        }
        Insert: {
          activity_type: string
          description?: string | null
          id?: string
          metadata?: Json | null
          user_id?: string | null
        }
        Update: {
          activity_type?: string
          created_at?: string
          description?: string | null
          id?: string
          metadata?: Json | null
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "activity_log_user_id_fkey"
            columns: ["user_id"]
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      deposits: {
        Row: {
          amount: number
          created_at: string
          id: string
          method: string | null
          mobile_number: string | null
          payment_method: string | null
          phone_number: string | null
          status: string | null
          transaction_id: string | null
          updated_at: string | null
          user_id: string | null
        }
        Insert: {
          amount: number
          created_at?: string
          id?: string
          method?: string | null
          mobile_number?: string | null
          payment_method?: string | null
          phone_number?: string | null
          status?: string | null
          transaction_id?: string | null
          updated_at?: string | null
          user_id?: string | null
        }
        Update: {
          amount?: number
          created_at?: string
          id?: string
          method?: string | null
          mobile_number?: string | null
          payment_method?: string | null
          phone_number?: string | null
          status?: string | null
          transaction_id?: string | null
          updated_at?: string | null
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "deposits_user_id_fkey"
            columns: ["user_id"]
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          balance: number | null
          completed_tasks: number | null
          created_at: string
          email: string | null
          full_name: string | null
          id: string
          is_active: boolean | null
          is_admin: boolean | null
          referral_code: string | null
          referral_count: number | null
          referral_earnings: number | null
          referred_by: string | null
          total_earnings: number | null
          updated_at: string
          used_vouchers: string[] | null
          username: string
        }
        Insert: {
          balance?: number | null
          completed_tasks?: number | null
          created_at?: string
          email?: string | null
          full_name?: string | null
          id: string
          is_active?: boolean | null
          is_admin?: boolean | null
          referral_code?: string | null
          referral_count?: number | null
          referral_earnings?: number | null
          referred_by?: string | null
          total_earnings?: number | null
          updated_at?: string
          used_vouchers?: string[] | null
          username: string
        }
        Update: {
          balance?: number | null
          completed_tasks?: number | null
          created_at?: string
          email?: string | null
          full_name?: string | null
          id?: string
          is_active?: boolean | null
          is_admin?: boolean | null
          referral_code?: string | null
          referral_count?: number | null
          referral_earnings?: number | null
          referred_by?: string | null
          total_earnings?: number | null
          updated_at?: string
          used_vouchers?: string[] | null
          username?: string
        }
        Relationships: [
          {
            foreignKeyName: "profiles_id_fkey"
            columns: ["id"]
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "profiles_referred_by_fkey"
            columns: ["referred_by"]
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      referrals: {
        Row: {
          created_at: string
          id: string
          referrer_id: string | null
          referred_id: string | null
          reward: number | null
          status: string | null
        }
        Insert: {
          created_at?: string
          id?: string
          referrer_id?: string | null
          referred_id?: string | null
          reward?: number | null
          status?: string | null
        }
        Update: {
          created_at?: string
          id?: string
          referrer_id?: string | null
          referred_id?: string | null
          reward?: number | null
          status?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "referrals_referred_id_fkey"
            columns: ["referred_id"]
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "referrals_referrer_id_fkey"
            columns: ["referrer_id"]
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      tasks: {
        Row: {
          completion_limit: number | null
          created_at: string
          description: string | null
          id: string
          is_closed: boolean | null
          reward: number
          title: string
          updated_at: string
        }
        Insert: {
          completion_limit?: number | null
          created_at?: string
          description?: string | null
          id?: string
          is_closed?: boolean | null
          reward: number
          title: string
          updated_at?: string
        }
        Update: {
          completion_limit?: number | null
          created_at?: string
          description?: string | null
          id?: string
          is_closed?: boolean | null
          reward?: number
          title?: string
          updated_at?: string
        }
        Relationships: []
      }
      user_tasks: {
        Row: {
          admin_approved: boolean | null
          completed_at: string | null
          created_at: string
          id: string
          started_at: string | null
          status: string | null
          submission_date: string | null
          submission_details: string | null
          task_id: string | null
          user_id: string | null
        }
        Insert: {
          admin_approved?: boolean | null
          completed_at?: string | null
          created_at?: string
          id?: string
          started_at?: string | null
          status?: string | null
          submission_date?: string | null
          submission_details?: string | null
          task_id?: string | null
          user_id?: string | null
        }
        Update: {
          admin_approved?: boolean | null
          completed_at?: string | null
          created_at?: string
          id?: string
          started_at?: string | null
          status?: string | null
          submission_date?: string | null
          submission_details?: string | null
          task_id?: string | null
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "user_tasks_task_id_fkey"
            columns: ["task_id"]
            referencedRelation: "tasks"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "user_tasks_user_id_fkey"
            columns: ["user_id"]
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      withdrawals: {
        Row: {
          amount: number
          created_at: string
          id: string
          method: string | null
          mobile_number: string | null
          payment_method: string | null
          phone_number: string | null
          status: string | null
          transaction_id: string | null
          updated_at: string | null
          user_id: string | null
        }
        Insert: {
          amount: number
          created_at?: string
          id?: string
          method?: string | null
          mobile_number?: string | null
          payment_method?: string | null
          phone_number?: string | null
          status?: string | null
          transaction_id?: string | null
          updated_at?: string | null
          user_id?: string | null
        }
        Update: {
          amount?: number
          created_at?: string
          id?: string
          method?: string | null
          mobile_number?: string | null
          payment_method?: string | null
          phone_number?: string | null
          status?: string | null
          transaction_id?: string | null
          updated_at?: string | null
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "withdrawals_user_id_fkey"
            columns: ["user_id"]
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      admin_task_stats: {
        Row: {
          completed_count: number | null
          id: string | null
          pending_count: number | null
          title: string | null
          total_attempts: number | null
        }
        Relationships: []
      }
      admin_user_stats: {
        Row: {
          new_users_last_week: number | null
          total_completed_tasks: number | null
          total_earnings_all_users: number | null
          total_referrals: number | null
          total_users: number | null
        }
        Relationships: []
      }
    }
    Functions: {
      add_amount: {
        Args: {
          row_id: string
          amount: number
        }
        Returns: number
      }
      approve_task: {
        Args: {
          task_id: string
          user_id: string
        }
        Returns: boolean
      }
      check_column_exists: {
        Args: {
          table_name: string
          column_name: string
        }
        Returns: {
          exists: boolean
        }[]
      }
      check_referral_permission: {
        Args: {
          referral_id: string
        }
        Returns: boolean
      }
      complete_task: {
        Args: {
          user_id: string
          reward_amount: number
        }
        Returns: undefined
      }
      create_add_column_function: {
        Args: Record<PropertyKey, never>
        Returns: boolean
      }
      create_check_column_exists_function: {
        Args: Record<PropertyKey, never>
        Returns: boolean
      }
      create_get_columns_function: {
        Args: Record<PropertyKey, never>
        Returns: boolean
      }
      create_get_tables_function: {
        Args: Record<PropertyKey, never>
        Returns: boolean
      }
      create_user_tasks_table_function: {
        Args: Record<PropertyKey, never>
        Returns: boolean
      }
      ensure_admin_access: {
        Args: {
          admin_email: string
        }
        Returns: boolean
      }
      ensure_profile_exists: {
        Args: Record<PropertyKey, never>
        Returns: unknown
      }
      fix_referral_counts: {
        Args: Record<PropertyKey, never>
        Returns: undefined
      }
      generate_referral_code: {
        Args: {
          user_id: string
        }
        Returns: string
      }
      get_tables: {
        Args: Record<PropertyKey, never>
        Returns: {
          table_name: string
        }[]
      }
      increment: {
        Args: {
          row_id: string
        }
        Returns: number
      }
      is_admin: {
        Args: {
          user_id: string
        }
        Returns: boolean
      }
      log_transaction_status_change: {
        Args: Record<PropertyKey, never>
        Returns: unknown
      }
      notify_transaction_webhook: {
        Args: Record<PropertyKey, never>
        Returns: unknown
      }
      remove_duplicate_profiles: {
        Args: Record<PropertyKey, never>
        Returns: undefined
      }
      safe_notify_transaction: {
        Args: {
          transaction_type: string
          user_id: string
          amount: number
          method: string
          mobile_number: string
          transaction_id: string
          status: string
        }
        Returns: undefined
      }
      update_referral_status: {
        Args: Record<PropertyKey, never>
        Returns: unknown
      }
      update_transaction_from_telegram: {
        Args: {
          transaction_type: string
          transaction_id: string
          new_status: string
        }
        Returns: boolean
      }
      update_transaction_status: {
        Args: {
          transaction_type: string
          transaction_id: string
          new_status: string
          updated_via: string
        }
        Returns: boolean
      }
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}
