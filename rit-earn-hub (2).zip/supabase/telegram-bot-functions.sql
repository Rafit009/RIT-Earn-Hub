-- Create a function to update transaction status and handle the associated actions
CREATE OR REPLACE FUNCTION update_transaction_status(
  transaction_type TEXT,
  transaction_id UUID,
  new_status TEXT,
  updated_via TEXT DEFAULT 'admin_panel'
)
RETURNS BOOLEAN AS $$
DECLARE
  transaction_record RECORD;
  user_id UUID;
  amount DECIMAL;
  should_activate BOOLEAN := FALSE;
BEGIN
  -- Get the transaction details
  EXECUTE format('
    SELECT * FROM %I WHERE id = $1
  ', transaction_type)
  INTO transaction_record
  USING transaction_id;
  
  IF transaction_record IS NULL THEN
    RAISE EXCEPTION 'Transaction not found';
  END IF;
  
  -- Extract common fields
  user_id := transaction_record.user_id;
  amount := transaction_record.amount;
  
  -- Update transaction status
  EXECUTE format('
    UPDATE %I 
    SET status = $1, updated_at = NOW()
    WHERE id = $2
  ', transaction_type)
  USING new_status, transaction_id;
  
  -- Handle specific actions based on transaction type and status
  IF transaction_type = 'deposits' AND new_status = 'completed' THEN
    -- Check if this deposit is enough to activate the account
    SELECT amount >= 50 AND NOT is_active INTO should_activate
    FROM profiles
    WHERE id = user_id;
    
    -- Update user balance and activate account if needed
    UPDATE profiles
    SET 
      balance = balance + amount,
      is_active = CASE WHEN should_activate THEN TRUE ELSE is_active END
    WHERE id = user_id;
    
    -- Log the activity
    INSERT INTO activity_log (
      user_id,
      activity_type,
      description,
      metadata
    ) VALUES (
      user_id,
      'deposit_approved',
      format('Your deposit of %s৳ has been approved', amount),
      jsonb_build_object(
        'transaction_id', transaction_id,
        'amount', amount,
        'method', COALESCE(transaction_record.method, transaction_record.payment_method, 'unknown'),
        'approved_via', updated_via
      )
    );
    
  ELSIF transaction_type = 'deposits' AND new_status = 'failed' THEN
    -- Log the declined deposit
    INSERT INTO activity_log (
      user_id,
      activity_type,
      description,
      metadata
    ) VALUES (
      user_id,
      'deposit_declined',
      format('Your deposit of %s৳ has been declined', amount),
      jsonb_build_object(
        'transaction_id', transaction_id,
        'amount', amount,
        'method', COALESCE(transaction_record.method, transaction_record.payment_method, 'unknown'),
        'declined_via', updated_via
      )
    );
    
  ELSIF transaction_type = 'withdrawals' AND new_status = 'completed' THEN
    -- For withdrawals, the balance has already been deducted when the request was made
    -- Just log the activity
    INSERT INTO activity_log (
      user_id,
      activity_type,
      description,
      metadata
    ) VALUES (
      user_id,
      'withdrawal_approved',
      format('Your withdrawal of %s৳ has been approved', amount),
      jsonb_build_object(
        'transaction_id', transaction_id,
        'amount', amount,
        'method', COALESCE(transaction_record.method, transaction_record.payment_method, 'unknown'),
        'approved_via', updated_via
      )
    );
    
  ELSIF transaction_type = 'withdrawals' AND new_status = 'failed' THEN
    -- If withdrawal is declined, refund the amount to user's balance
    UPDATE profiles
    SET balance = balance + amount
    WHERE id = user_id;
    
    -- Log the declined withdrawal
    INSERT INTO activity_log (
      user_id,
      activity_type,
      description,
      metadata
    ) VALUES (
      user_id,
      'withdrawal_declined',
      format('Your withdrawal of %s৳ has been declined. The amount has been refunded to your balance.', amount),
      jsonb_build_object(
        'transaction_id', transaction_id,
        'amount', amount,
        'method', COALESCE(transaction_record.method, transaction_record.payment_method, 'unknown'),
        'declined_via', updated_via
      )
    );
  END IF;
  
  RETURN TRUE;
EXCEPTION
  WHEN OTHERS THEN
    RAISE NOTICE 'Error in update_transaction_status: %', SQLERRM;
    RETURN FALSE;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Grant execute permission to authenticated users
GRANT EXECUTE ON FUNCTION update_transaction_status TO authenticated;
