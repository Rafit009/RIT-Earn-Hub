-- Check if used_vouchers column exists in profiles table, if not add it
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 
    FROM information_schema.columns 
    WHERE table_name = 'profiles' 
    AND column_name = 'used_vouchers'
  ) THEN
    -- Add used_vouchers column with default empty array
    ALTER TABLE profiles ADD COLUMN used_vouchers TEXT[] DEFAULT '{}';
    
    RAISE NOTICE 'Added used_vouchers column to profiles table';
  ELSE
    RAISE NOTICE 'used_vouchers column already exists in profiles table';
  END IF;
END $$;
