-- Add new columns to user_tasks table if they don't exist
DO $$
BEGIN
  -- Add admin_approved column to track admin approval status
  IF NOT EXISTS (
    SELECT 1 
    FROM information_schema.columns 
    WHERE table_name = 'user_tasks' 
    AND column_name = 'admin_approved'
  ) THEN
    ALTER TABLE user_tasks ADD COLUMN admin_approved BOOLEAN DEFAULT false;
  END IF;

  -- Add submission_details column to store user's task submission details
  IF NOT EXISTS (
    SELECT 1 
    FROM information_schema.columns 
    WHERE table_name = 'user_tasks' 
    AND column_name = 'submission_details'
  ) THEN
    ALTER TABLE user_tasks ADD COLUMN submission_details TEXT;
  END IF;

  -- Add submission_date column
  IF NOT EXISTS (
    SELECT 1 
    FROM information_schema.columns 
    WHERE table_name = 'user_tasks' 
    AND column_name = 'submission_date'
  ) THEN
    ALTER TABLE user_tasks ADD COLUMN submission_date TIMESTAMP WITH TIME ZONE;
  END IF;
END $$;

-- Create a function to handle task approval by admin
CREATE OR REPLACE FUNCTION approve_task(task_id UUID, user_id UUID)
RETURNS BOOLEAN AS $$
DECLARE
  task_reward DECIMAL;
  user_record RECORD;
BEGIN
  -- Get the task reward amount
  SELECT reward INTO task_reward
  FROM tasks t
  JOIN user_tasks ut ON t.id = ut.task_id
  WHERE ut.task_id = approve_task.task_id 
  AND ut.user_id = approve_task.user_id;
  
  -- Get user record
  SELECT * INTO user_record
  FROM profiles
  WHERE id = user_id;
  
  -- Update user_tasks to mark as completed and admin approved
  UPDATE user_tasks
  SET 
    status = 'completed',
    admin_approved = true,
    completed_at = NOW()
  WHERE 
    task_id = approve_task.task_id 
    AND user_id = approve_task.user_id;
  
  -- Update user balance and stats
  UPDATE profiles
  SET 
    balance = balance + task_reward,
    total_earnings = total_earnings + task_reward,
    completed_tasks = completed_tasks + 1
  WHERE id = user_id;
  
  -- Log the activity
  INSERT INTO activity_log (
    user_id, 
    activity_type, 
    description, 
    metadata
  )
  VALUES (
    user_id, 
    'task_approved', 
    'Your task has been approved and you earned ' || task_reward || '৳',
    jsonb_build_object(
      'task_id', task_id,
      'reward', task_reward
    )
  );
  
  -- Check if user was referred by someone and reward the referrer
  IF user_record.referred_by IS NOT NULL THEN
    -- Calculate referral bonus (5% of task reward)
    DECLARE
      referral_bonus DECIMAL := task_reward * 0.05;
    BEGIN
      -- Update referrer's balance and stats
      UPDATE profiles
      SET 
        balance = balance + referral_bonus,
        referral_earnings = referral_earnings + referral_bonus,
        total_earnings = total_earnings + referral_bonus
      WHERE id = user_record.referred_by;
      
      -- Log the referral bonus activity
      INSERT INTO activity_log (
        user_id, 
        activity_type, 
        description, 
        metadata
      )
      VALUES (
        user_record.referred_by, 
        'referral_task_bonus', 
        'You earned ' || referral_bonus || '৳ from your referral completing a task',
        jsonb_build_object(
          'referred_id', user_id,
          'task_id', task_id,
          'bonus_amount', referral_bonus
        )
      );
    END;
  END IF;
  
  RETURN TRUE;
EXCEPTION
  WHEN OTHERS THEN
    RAISE NOTICE 'Error in approve_task: %', SQLERRM;
    RETURN FALSE;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Grant execute permission to authenticated users
GRANT EXECUTE ON FUNCTION approve_task TO authenticated;
