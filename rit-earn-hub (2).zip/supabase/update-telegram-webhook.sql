-- Update the notify_transaction_webhook function to use the correct webhook URL
CREATE OR REPLACE FUNCTION notify_transaction_webhook()
RETURNS TRIGGER AS $$
DECLARE
  webhook_url TEXT := 'https://v0-rafit-it-zone-earn.vercel.app/api/telegram-notify';
  payload JSONB;
  record_data JSONB;
BEGIN
  -- Convert the record to JSON
  record_data := row_to_json(NEW)::jsonb;
  
  -- Create the payload with the transaction data
  payload := jsonb_build_object(
    'record', jsonb_build_object(
      'new', record_data
    )
  );
  
  -- Try to send the HTTP request
  BEGIN
    -- Send the HTTP request using the http extension
    PERFORM http_post(
      webhook_url,
      payload,
      'application/json'
    );
    
    -- Log successful notification
    INSERT INTO activity_log (
      user_id, 
      activity_type, 
      description, 
      metadata
    )
    VALUES (
      NEW.user_id,
      TG_TABLE_NAME || '_notification_sent',
      'Notification sent for ' || TG_TABLE_NAME || ' transaction',
      jsonb_build_object(
        'transaction_id', NEW.id,
        'amount', NEW.amount,
        'webhook_url', webhook_url
      )
    );
  EXCEPTION WHEN OTHERS THEN
    -- Log failed notification attempt
    INSERT INTO activity_log (
      user_id, 
      activity_type, 
      description, 
      metadata
    )
    VALUES (
      NEW.user_id,
      TG_TABLE_NAME || '_notification_failed',
      'Failed to send notification for ' || TG_TABLE_NAME || ' transaction',
      jsonb_build_object(
        'transaction_id', NEW.id,
        'amount', NEW.amount,
        'error', SQLERRM
      )
    );
  END;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Make sure triggers exist for both deposits and withdrawals
DROP TRIGGER IF EXISTS deposit_notification_trigger ON deposits;
CREATE TRIGGER deposit_notification_trigger
AFTER INSERT ON deposits
FOR EACH ROW
EXECUTE FUNCTION notify_transaction_webhook();

DROP TRIGGER IF EXISTS withdrawal_notification_trigger ON withdrawals;
CREATE TRIGGER withdrawal_notification_trigger
AFTER INSERT ON withdrawals
FOR EACH ROW
EXECUTE FUNCTION notify_transaction_webhook();

-- Create triggers for status updates
DROP TRIGGER IF EXISTS deposit_status_update_trigger ON deposits;
CREATE TRIGGER deposit_status_update_trigger
AFTER UPDATE OF status ON deposits
FOR EACH ROW
WHEN (OLD.status IS DISTINCT FROM NEW.status)
EXECUTE FUNCTION notify_transaction_webhook();

DROP TRIGGER IF EXISTS withdrawal_status_update_trigger ON withdrawals;
CREATE TRIGGER withdrawal_status_update_trigger
AFTER UPDATE OF status ON withdrawals
FOR EACH ROW
WHEN (OLD.status IS DISTINCT FROM NEW.status)
EXECUTE FUNCTION notify_transaction_webhook();
