-- Check if payment_method column exists in withdrawals table, if not add it
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 
    FROM information_schema.columns 
    WHERE table_name = 'withdrawals' 
    AND column_name = 'payment_method'
  ) THEN
    ALTER TABLE withdrawals ADD COLUMN payment_method TEXT;
  END IF;
END $$;

-- Ensure all required columns exist in the withdrawals table
ALTER TABLE withdrawals ADD COLUMN IF NOT EXISTS phone_number TEXT;
ALTER TABLE withdrawals ADD COLUMN IF NOT EXISTS status TEXT DEFAULT 'pending';
ALTER TABLE withdrawals ADD COLUMN IF NOT EXISTS transaction_id TEXT;

-- Update the notify_transaction_webhook function to handle missing columns
CREATE OR REPLACE FUNCTION notify_transaction_webhook()
RETURNS TRIGGER AS $$
DECLARE
  webhook_url TEXT := 'https://v0-rafit-it-zone-earn.vercel.app/api/telegram-notify';
  payload JSONB;
  record_data JSONB;
BEGIN
  -- Convert the record to JSON
  record_data := row_to_json(NEW)::jsonb;
  
  -- Ensure required fields exist to prevent errors
  IF record_data ? 'payment_method' IS NOT TRUE THEN
    record_data := record_data || '{"payment_method": "unknown"}'::jsonb;
  END IF;
  
  IF record_data ? 'phone_number' IS NOT TRUE THEN
    record_data := record_data || '{"phone_number": "N/A"}'::jsonb;
  END IF;
  
  IF record_data ? 'transaction_id' IS NOT TRUE THEN
    record_data := record_data || '{"transaction_id": "N/A"}'::jsonb;
  END IF;
  
  -- Create the payload with the transaction data
  payload := jsonb_build_object(
    'record', jsonb_build_object(
      'new', record_data
    )
  );
  
  -- Send the HTTP request
  PERFORM http_post(
    webhook_url,
    payload,
    'application/json'
  );
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
