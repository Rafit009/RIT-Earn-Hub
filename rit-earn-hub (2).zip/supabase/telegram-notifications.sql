-- Create a function to send notifications via HTTP request
CREATE OR REPLACE FUNCTION notify_transaction_webhook()
RETURNS TRIGGER AS $$
DECLARE
  webhook_url TEXT := 'https://your-vercel-app-url.vercel.app/api/telegram-notify';
  payload JSONB;
BEGIN
  -- Create the payload with the transaction data
  payload := jsonb_build_object(
    'record', jsonb_build_object(
      'new', row_to_json(NEW)
    )
  );
  
  -- Send the HTTP request
  PERFORM http_post(
    webhook_url,
    payload,
    'application/json'
  );
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create triggers for deposits
CREATE TRIGGER deposit_notification_trigger
AFTER INSERT ON deposits
FOR EACH ROW
EXECUTE FUNCTION notify_transaction_webhook();

-- Create triggers for withdrawals
CREATE TRIGGER withdrawal_notification_trigger
AFTER INSERT ON withdrawals
FOR EACH ROW
EXECUTE FUNCTION notify_transaction_webhook();

-- Create triggers for status updates
CREATE TRIGGER deposit_status_update_trigger
AFTER UPDATE OF status ON deposits
FOR EACH ROW
WHEN (OLD.status IS DISTINCT FROM NEW.status)
EXECUTE FUNCTION notify_transaction_webhook();

CREATE TRIGGER withdrawal_status_update_trigger
AFTER UPDATE OF status ON withdrawals
FOR EACH ROW
WHEN (OLD.status IS DISTINCT FROM NEW.status)
EXECUTE FUNCTION notify_transaction_webhook();
