-- Make the specific user an admin
UPDATE profiles
SET is_admin = true
WHERE id = '8bed079c-dc1e-47a3-bf31-034666029592';

-- Ensure all other users are not admins (optional, uncomment if needed)
-- UPDATE profiles
-- SET is_admin = false
-- WHERE id != '8bed079c-dc1e-47a3-bf31-034666029592';

-- Verify the change
SELECT id, username, is_admin 
FROM profiles 
WHERE id = '8bed079c-dc1e-47a3-bf31-034666029592';
