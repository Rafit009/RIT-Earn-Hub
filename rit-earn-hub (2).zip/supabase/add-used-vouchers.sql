-- Add used_vouchers column to profiles table if it doesn't exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 
    FROM information_schema.columns 
    WHERE table_name = 'profiles' 
    AND column_name = 'used_vouchers'
  ) THEN
    ALTER TABLE profiles ADD COLUMN used_vouchers TEXT[] DEFAULT '{}';
  END IF;
END $$;
