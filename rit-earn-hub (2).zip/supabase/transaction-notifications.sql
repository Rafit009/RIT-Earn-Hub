-- Create a function to log transaction status changes
CREATE OR REPLACE FUNCTION log_transaction_status_change()
RETURNS TRIGGER AS $$
DECLARE
  activity_type TEXT;
  description TEXT;
  metadata JSONB;
BEGIN
  -- Determine if this is a deposit or withdrawal
  IF TG_TABLE_NAME = 'deposits' THEN
    -- For deposits
    IF NEW.status = 'completed' AND OLD.status != 'completed' THEN
      activity_type := 'deposit_approved';
      description := 'Your deposit of ' || NEW.amount || '৳ has been approved';
    ELSIF NEW.status = 'failed' AND OLD.status != 'failed' THEN
      activity_type := 'deposit_declined';
      description := 'Your deposit of ' || NEW.amount || '৳ has been declined';
    ELSE
      -- No relevant status change
      RETURN NEW;
    END IF;
  ELSE
    -- For withdrawals
    IF NEW.status = 'completed' AND OLD.status != 'completed' THEN
      activity_type := 'withdrawal_approved';
      description := 'Your withdrawal of ' || NEW.amount || '৳ has been approved';
    ELSIF NEW.status = 'failed' AND OLD.status != 'failed' THEN
      activity_type := 'withdrawal_declined';
      description := 'Your withdrawal of ' || NEW.amount || '৳ has been declined. The amount has been refunded to your balance.';
    ELSE
      -- No relevant status change
      RETURN NEW;
    END IF;
  END IF;
  
  -- Create metadata
  metadata := jsonb_build_object(
    'transaction_id', NEW.id,
    'amount', NEW.amount,
    'method', COALESCE(NEW.method, NEW.payment_method, 'unknown')
  );
  
  -- Insert activity log
  INSERT INTO activity_log (
    user_id,
    activity_type,
    description,
    metadata,
    created_at
  ) VALUES (
    NEW.user_id,
    activity_type,
    description,
    metadata,
    NOW()
  );
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create or replace triggers for status changes
DROP TRIGGER IF EXISTS deposit_status_change_trigger ON deposits;
CREATE TRIGGER deposit_status_change_trigger
AFTER UPDATE OF status ON deposits
FOR EACH ROW
WHEN (OLD.status IS DISTINCT FROM NEW.status)
EXECUTE FUNCTION log_transaction_status_change();

DROP TRIGGER IF EXISTS withdrawal_status_change_trigger ON withdrawals;
CREATE TRIGGER withdrawal_status_change_trigger
AFTER UPDATE OF status ON withdrawals
FOR EACH ROW
WHEN (OLD.status IS DISTINCT FROM NEW.status)
EXECUTE FUNCTION log_transaction_status_change();
