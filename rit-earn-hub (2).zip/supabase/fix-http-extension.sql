-- Check if the HTTP extension exists before trying to create it
DO $$
BEGIN
  -- Check if the extension already exists
  IF NOT EXISTS (
    SELECT 1 FROM pg_extension WHERE extname = 'http'
  ) THEN
    -- Try to create the extension if it doesn't exist
    BEGIN
      CREATE EXTENSION IF NOT EXISTS http WITH SCHEMA public;
    EXCEPTION WHEN OTHERS THEN
      RAISE NOTICE 'Could not create HTTP extension. This may require admin privileges.';
    END;
  END IF;
END $$;

-- Create a fallback function that doesn't use HTTP if the extension isn't available
CREATE OR REPLACE FUNCTION safe_notify_transaction(
  transaction_type TEXT,
  user_id UUID,
  amount DECIMAL,
  method TEXT,
  mobile_number TEXT,
  transaction_id TEXT,
  status TEXT
) RETURNS void AS $$
BEGIN
  -- Insert a record in a notifications table instead of making HTTP request
  INSERT INTO activity_log (
    user_id,
    activity_type,
    description,
    metadata
  ) VALUES (
    user_id,
    transaction_type || '_notification',
    'Transaction notification for ' || transaction_type,
    jsonb_build_object(
      'amount', amount,
      'method', method,
      'mobile_number', mobile_number,
      'transaction_id', transaction_id,
      'status', status
    )
  );
  
  -- Log that we couldn't send the actual notification
  INSERT INTO activity_log (
    user_id,
    activity_type,
    description,
    metadata
  ) VALUES (
    user_id,
    'notification_fallback',
    'HTTP extension not available for webhook notification',
    jsonb_build_object(
      'transaction_type', transaction_type,
      'amount', amount
    )
  );
END;
$$ LANGUAGE plpgsql;

-- Update the notify_transaction_webhook function to use the safe function as fallback
CREATE OR REPLACE FUNCTION notify_transaction_webhook()
RETURNS TRIGGER AS $$
DECLARE
  webhook_url TEXT := 'https://v0-rafit-it-zone-earn.vercel.app/api/telegram-notify';
  payload JSONB;
  record_data JSONB;
  transaction_type TEXT;
BEGIN
  -- Determine if this is a deposit or withdrawal
  IF TG_TABLE_NAME = 'deposits' THEN
    transaction_type := 'deposit';
  ELSE
    transaction_type := 'withdrawal';
  END IF;

  -- Try to use HTTP extension if available
  BEGIN
    -- Convert the record to JSON
    record_data := row_to_json(NEW)::jsonb;
    
    -- Create the payload with the transaction data
    payload := jsonb_build_object(
      'record', jsonb_build_object(
        'new', record_data
      )
    );
    
    -- Send the HTTP request using the http extension
    PERFORM http_post(
      webhook_url,
      payload,
      'application/json'
    );
  EXCEPTION WHEN OTHERS THEN
    -- If HTTP extension fails, use the fallback function
    PERFORM safe_notify_transaction(
      transaction_type,
      NEW.user_id,
      NEW.amount,
      COALESCE(NEW.method, 'unknown'),
      COALESCE(NEW.mobile_number, 'unknown'),
      COALESCE(NEW.transaction_id, 'unknown'),
      COALESCE(NEW.status, 'pending')
    );
  END;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
