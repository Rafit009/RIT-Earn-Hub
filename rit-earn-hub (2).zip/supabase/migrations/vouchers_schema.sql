-- Create vouchers table if it doesn't exist
CREATE TABLE IF NOT EXISTS vouchers (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  code TEXT UNIQUE NOT NULL,
  amount DECIMAL(10, 2) NOT NULL,
  description TEXT,
  is_active BOOLEAN DEFAULT true,
  max_uses INTEGER DEFAULT NULL,
  used_count INTEGER DEFAULT 0,
  created_by UUID REFERENCES profiles(id),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  expires_at TIMESTAMP WITH TIME ZONE DEFAULT NULL
);

-- Add RLS policies for vouchers table
ALTER TABLE vouchers ENABLE ROW LEVEL SECURITY;

-- Only admins can view vouchers
CREATE POLICY "Admins can view vouchers" 
  ON vouchers FOR SELECT 
  USING (auth.uid() IN (SELECT id FROM profiles WHERE is_admin = true));

-- Only admins can insert vouchers
CREATE POLICY "Admins can insert vouchers" 
  ON vouchers FOR INSERT 
  WITH CHECK (auth.uid() IN (SELECT id FROM profiles WHERE is_admin = true));

-- Only admins can update vouchers
CREATE POLICY "Admins can update vouchers" 
  ON vouchers FOR UPDATE 
  USING (auth.uid() IN (SELECT id FROM profiles WHERE is_admin = true));

-- Only admins can delete vouchers
CREATE POLICY "Admins can delete vouchers" 
  ON vouchers FOR DELETE 
  USING (auth.uid() IN (SELECT id FROM profiles WHERE is_admin = true));

-- Create function to check if a voucher is valid and can be used
CREATE OR REPLACE FUNCTION check_voucher_validity(voucher_code TEXT, user_id UUID)
RETURNS TABLE (
  is_valid BOOLEAN,
  message TEXT,
  amount DECIMAL
) AS $$
DECLARE
  voucher_record RECORD;
BEGIN
  -- Check if voucher exists and is active
  SELECT * INTO voucher_record
  FROM vouchers
  WHERE code = voucher_code AND is_active = true;
  
  -- If voucher doesn't exist or is not active
  IF voucher_record IS NULL THEN
    RETURN QUERY SELECT false, 'Invalid voucher code', 0::DECIMAL;
    RETURN;
  END IF;
  
  -- Check if voucher has expired
  IF voucher_record.expires_at IS NOT NULL AND voucher_record.expires_at < NOW() THEN
    RETURN QUERY SELECT false, 'Voucher has expired', 0::DECIMAL;
    RETURN;
  END IF;
  
  -- Check if voucher has reached max uses
  IF voucher_record.max_uses IS NOT NULL AND voucher_record.used_count >= voucher_record.max_uses THEN
    RETURN QUERY SELECT false, 'Voucher has reached maximum uses', 0::DECIMAL;
    RETURN;
  END IF;
  
  -- Check if user has already used this voucher
  IF EXISTS (
    SELECT 1 FROM profiles 
    WHERE id = user_id 
    AND used_vouchers IS NOT NULL 
    AND voucher_code = ANY(used_vouchers)
  ) THEN
    RETURN QUERY SELECT false, 'You have already used this voucher', 0::DECIMAL;
    RETURN;
  END IF;
  
  -- Voucher is valid
  RETURN QUERY SELECT true, 'Voucher is valid', voucher_record.amount;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create function to apply a voucher
CREATE OR REPLACE FUNCTION apply_voucher(voucher_code TEXT, user_id UUID)
RETURNS TABLE (
  success BOOLEAN,
  message TEXT,
  amount DECIMAL
) AS $$
DECLARE
  voucher_record RECORD;
  validity_check RECORD;
BEGIN
  -- Check voucher validity first
  SELECT * INTO validity_check FROM check_voucher_validity(voucher_code, user_id);
  
  IF NOT validity_check.is_valid THEN
    RETURN QUERY SELECT false, validity_check.message, 0::DECIMAL;
    RETURN;
  END IF;
  
  -- Get voucher details
  SELECT * INTO voucher_record FROM vouchers WHERE code = voucher_code;
  
  -- Update user's balance and used_vouchers
  UPDATE profiles
  SET 
    balance = COALESCE(balance, 0) + voucher_record.amount,
    is_active = true, -- Also activate the account
    used_vouchers = array_append(COALESCE(used_vouchers, ARRAY[]::TEXT[]), voucher_code)
  WHERE id = user_id;
  
  -- Increment voucher used count
  UPDATE vouchers
  SET used_count = used_count + 1
  WHERE code = voucher_code;
  
  -- Log the activity
  INSERT INTO activity_log (
    user_id,
    activity_type,
    description,
    metadata
  ) VALUES (
    user_id,
    'voucher_redemption',
    'Redeemed voucher code for ' || voucher_record.amount || '৳',
    jsonb_build_object(
      'voucher_code', voucher_code,
      'amount', voucher_record.amount,
      'description', voucher_record.description
    )
  );
  
  -- Return success
  RETURN QUERY SELECT true, 'Voucher applied successfully', voucher_record.amount;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Grant execute permissions
GRANT EXECUTE ON FUNCTION check_voucher_validity TO authenticated;
GRANT EXECUTE ON FUNCTION apply_voucher TO authenticated;
