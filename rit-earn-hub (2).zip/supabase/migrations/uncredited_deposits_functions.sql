-- Function to find deposits that might not have been credited for inactive users
CREATE OR REPLACE FUNCTION find_uncredited_deposits()
RETURNS TABLE (
  id UUID,
  user_id UUID,
  amount DECIMAL,
  status TEXT,
  created_at TIMESTAMPTZ
) AS $$
BEGIN
  RETURN QUERY
  SELECT 
    d.id,
    d.user_id,
    d.amount,
    d.status,
    d.created_at
  FROM 
    deposits d
  JOIN 
    profiles p ON d.user_id = p.id
  WHERE 
    d.status = 'completed' AND
    p.balance < 10 AND
    NOT EXISTS (
      SELECT 1 
      FROM activity_log 
      WHERE user_id = d.user_id 
      AND metadata->>'transaction_id' = d.id::text
      AND activity_type = 'deposit_approved'
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to apply a missed deposit
CREATE OR REPLACE FUNCTION apply_missed_deposit(deposit_id UUID)
RETURNS BOOLEAN AS $$
DECLARE
  deposit_record RECORD;
  user_record RECORD;
  payment_method TEXT;
  should_activate BOOLEAN;
BEGIN
  -- Get the deposit details
  SELECT * INTO deposit_record
  FROM deposits
  WHERE id = deposit_id;
  
  IF deposit_record IS NULL THEN
    RAISE EXCEPTION 'Deposit not found';
  END IF;
  
  -- Get the user details
  SELECT * INTO user_record
  FROM profiles
  WHERE id = deposit_record.user_id;
  
  IF user_record IS NULL THEN
    RAISE EXCEPTION 'User not found';
  END IF;
  
  -- Get payment method safely
  payment_method := COALESCE(deposit_record.method, deposit_record.payment_method, 'unknown');
  
  -- Check if this deposit is enough to activate the account
  should_activate := deposit_record.amount >= 50 AND NOT COALESCE(user_record.is_active, FALSE);
  
  -- Update user balance and activate if needed
  IF should_activate THEN
    UPDATE profiles
    SET 
      balance = COALESCE(balance, 0) + deposit_record.amount,
      is_active = TRUE,
      updated_at = NOW()
    WHERE id = deposit_record.user_id;
    
    -- Log the activity
    INSERT INTO activity_log (
      user_id,
      activity_type,
      description,
      metadata
    )
    VALUES (
      deposit_record.user_id, 
      'deposit_approved', 
      format('Your deposit of %s৳ has been approved and your account has been activated (fixed)', deposit_record.amount),
      jsonb_build_object(
        'transaction_id', deposit_id,
        'amount', deposit_record.amount,
        'method', payment_method,
        'approved_via', 'fix_script',
        'account_activated', TRUE,
        'was_previously_missed', TRUE
      )
    );
  ELSE
    -- Just update balance
    UPDATE profiles
    SET 
      balance = COALESCE(balance, 0) + deposit_record.amount,
      updated_at = NOW()
    WHERE id = deposit_record.user_id;
    
    -- Log the activity
    INSERT INTO activity_log (
      user_id,
      activity_type,
      description,
      metadata
    )
    VALUES (
      deposit_record.user_id, 
      'deposit_approved', 
      format('Your deposit of %s৳ has been applied to your account (fixed)', deposit_record.amount),
      jsonb_build_object(
        'transaction_id', deposit_id,
        'amount', deposit_record.amount,
        'method', payment_method,
        'approved_via', 'fix_script',
        'account_activated', FALSE,
        'was_previously_missed', TRUE
      )
    );
  END IF;
  
  RETURN TRUE;
EXCEPTION
  WHEN OTHERS THEN
    RAISE NOTICE 'Error applying missed deposit: %', SQLERRM;
    RETURN FALSE;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Grant permissions
GRANT EXECUTE ON FUNCTION find_uncredited_deposits TO authenticated;
GRANT EXECUTE ON FUNCTION apply_missed_deposit TO authenticated;
