-- Function to immediately apply referral bonuses when a user signs up with a referral code
CREATE OR REPLACE FUNCTION apply_immediate_referral_bonus(
  referred_user_id UUID,
  referrer_id UUID
)
RETURNS BOOLEAN AS $$
DECLARE
  referred_bonus DECIMAL := 10.0; -- 10 Taka for the new user
  referrer_bonus DECIMAL := 35.0; -- 35 Taka for the referrer
BEGIN
  -- Add bonus to the referred user (new user)
  UPDATE profiles
  SET 
    balance = COALESCE(balance, 0) + referred_bonus,
    total_earnings = COALESCE(total_earnings, 0) + referred_bonus
  WHERE id = referred_user_id;
  
  -- Log the bonus for the referred user
  INSERT INTO activity_log (
    user_id,
    activity_type,
    description,
    metadata
  ) VALUES (
    referred_user_id,
    'signup_bonus',
    'You received 10৳ signup bonus for using a referral code',
    jsonb_build_object(
      'referrer_id', referrer_id,
      'bonus_amount', referred_bonus,
      'reason', 'referral_signup'
    )
  );
  
  -- Add bonus to the referrer
  UPDATE profiles
  SET 
    balance = COALESCE(balance, 0) + referrer_bonus,
    referral_earnings = COALESCE(referral_earnings, 0) + referrer_bonus,
    total_earnings = COALESCE(total_earnings, 0) + referrer_bonus
  WHERE id = referrer_id;
  
  -- Log the bonus for the referrer
  INSERT INTO activity_log (
    user_id,
    activity_type,
    description,
    metadata
  ) VALUES (
    referrer_id,
    'referral_bonus',
    'You received 35৳ for referring a new user',
    jsonb_build_object(
      'referred_id', referred_user_id,
      'bonus_amount', referrer_bonus,
      'reason', 'new_referral'
    )
  );
  
  -- Update the referral record status
  UPDATE referrals
  SET 
    status = 'active'
  WHERE 
    referrer_id = referrer_id AND
    referred_id = referred_user_id;
    
  RETURN TRUE;
EXCEPTION
  WHEN OTHERS THEN
    RAISE NOTICE 'Error in apply_immediate_referral_bonus: %', SQLERRM;
    RETURN FALSE;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Grant execute permission to authenticated users
GRANT EXECUTE ON FUNCTION apply_immediate_referral_bonus TO authenticated;
