-- Create a function to properly handle referral bonuses
CREATE OR REPLACE FUNCTION process_referral_bonus(referred_user_id UUID)
RETURNS BOOLEAN AS $$
DECLARE
  referrer_id UUID;
  referral_record RECORD;
  referrer_bonus DECIMAL := 35.0; -- 35 Taka for referrer
  referred_bonus DECIMAL := 10.0; -- 10 Taka for referred user
BEGIN
  -- Check if this user was referred by someone
  SELECT referred_by INTO referrer_id 
  FROM profiles 
  WHERE id = referred_user_id;
  
  -- If user wasn't referred, exit early
  IF referrer_id IS NULL THEN
    RETURN FALSE;
  END IF;
  
  -- Find the referral record
  SELECT * INTO referral_record
  FROM referrals
  WHERE referrer_id = referrer_id 
  AND referred_id = referred_user_id;
  
  -- If no referral record exists, create one
  IF referral_record IS NULL THEN
    INSERT INTO referrals (
      referrer_id,
      referred_id,
      status,
      reward,
      created_at
    ) VALUES (
      referrer_id,
      referred_user_id,
      'active',
      referrer_bonus,
      NOW()
    );
  ELSE
    -- Update existing referral to active status
    UPDATE referrals
    SET status = 'active'
    WHERE referrer_id = referrer_id 
    AND referred_id = referred_user_id;
  END IF;
  
  -- Add bonus to the referrer
  UPDATE profiles
  SET 
    balance = COALESCE(balance, 0) + referrer_bonus,
    referral_earnings = COALESCE(referral_earnings, 0) + referrer_bonus,
    total_earnings = COALESCE(total_earnings, 0) + referrer_bonus,
    referral_count = COALESCE(referral_count, 0) + 1
  WHERE id = referrer_id;
  
  -- Add bonus to the referred user
  UPDATE profiles
  SET 
    balance = COALESCE(balance, 0) + referred_bonus,
    total_earnings = COALESCE(total_earnings, 0) + referred_bonus
  WHERE id = referred_user_id;
  
  -- Log activity for referrer
  INSERT INTO activity_log (
    user_id,
    activity_type,
    description,
    metadata
  ) VALUES (
    referrer_id,
    'referral_bonus',
    'You received 35৳ for referring a new user',
    jsonb_build_object(
      'referred_id', referred_user_id,
      'bonus_amount', referrer_bonus
    )
  );
  
  -- Log activity for referred user
  INSERT INTO activity_log (
    user_id,
    activity_type,
    description,
    metadata
  ) VALUES (
    referred_user_id,
    'signup_bonus',
    'You received 10৳ signup bonus for using a referral code',
    jsonb_build_object(
      'referrer_id', referrer_id,
      'bonus_amount', referred_bonus
    )
  );
  
  RETURN TRUE;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Grant execute permission to authenticated users
GRANT EXECUTE ON FUNCTION process_referral_bonus TO authenticated;

-- Update the account activation function to process referral bonuses
CREATE OR REPLACE FUNCTION activate_user_account(user_id_param UUID)
RETURNS BOOLEAN AS $$
BEGIN
  -- Activate the user account
  UPDATE profiles
  SET is_active = true
  WHERE id = user_id_param;
  
  -- Process referral bonus if applicable
  PERFORM process_referral_bonus(user_id_param);
  
  RETURN TRUE;
EXCEPTION
  WHEN OTHERS THEN
    RAISE NOTICE 'Error in activate_user_account: %', SQLERRM;
    RETURN FALSE;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Grant execute permission to authenticated users
GRANT EXECUTE ON FUNCTION activate_user_account TO authenticated;
