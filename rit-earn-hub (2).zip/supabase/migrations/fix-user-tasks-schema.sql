-- Add missing columns to user_tasks table
DO $$
BEGIN
  -- Add started_at column if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 
    FROM information_schema.columns 
    WHERE table_name = 'user_tasks' 
    AND column_name = 'started_at'
  ) THEN
    ALTER TABLE user_tasks ADD COLUMN started_at TIMESTAMP WITH TIME ZONE;
  END IF;

  -- Add submission_date column if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 
    FROM information_schema.columns 
    WHERE table_name = 'user_tasks' 
    AND column_name = 'submission_date'
  ) THEN
    ALTER TABLE user_tasks ADD COLUMN submission_date TIMESTAMP WITH TIME ZONE;
  END IF;

  -- Add submission_details column if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 
    FROM information_schema.columns 
    WHERE table_name = 'user_tasks' 
    AND column_name = 'submission_details'
  ) THEN
    ALTER TABLE user_tasks ADD COLUMN submission_details TEXT;
  END IF;
END $$;
