-- Add completion_limit column to tasks table
ALTER TABLE tasks ADD COLUMN IF NOT EXISTS completion_limit INTEGER DEFAULT NULL;

-- Add is_closed column to tasks table to explicitly mark tasks as closed
ALTER TABLE tasks ADD COLUMN IF NOT EXISTS is_closed BOOLEAN DEFAULT FALSE;

-- Create a function to check and update task status based on completion count
CREATE OR REPLACE FUNCTION check_task_completion_limit() 
RETURNS TRIGGER AS $$
DECLARE
  completed_count INTEGER;
BEGIN
  -- Only proceed if the task has a completion limit
  IF (SELECT completion_limit FROM tasks WHERE id = NEW.task_id) IS NOT NULL THEN
    -- Count how many users have completed this task
    SELECT COUNT(*) INTO completed_count 
    FROM user_tasks 
    WHERE task_id = NEW.task_id AND status = 'completed';
    
    -- If completion count has reached or exceeded the limit, close the task
    IF completed_count >= (SELECT completion_limit FROM tasks WHERE id = NEW.task_id) THEN
      UPDATE tasks SET is_closed = TRUE WHERE id = NEW.task_id;
    END IF;
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create a trigger to run the function after a user_task is updated to 'completed'
DROP TRIGGER IF EXISTS task_completion_limit_check ON user_tasks;
CREATE TRIGGER task_completion_limit_check
AFTER UPDATE OF status ON user_tasks
FOR EACH ROW
WHEN (NEW.status = 'completed')
EXECUTE FUNCTION check_task_completion_limit();
