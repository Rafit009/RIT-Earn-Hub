-- Create a function to handle user activation and referral bonuses
CREATE OR REPLACE FUNCTION activate_user_with_referral_bonus(user_id_param UUID)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    referrer_id UUID;
    referral_record RECORD;
BEGIN
    -- Activate the user
    UPDATE users
    SET is_activated = true
    WHERE id = user_id_param;
    
    -- Add initial bonus to the new user (10 Taka)
    UPDATE users
    SET balance = balance + 10
    WHERE id = user_id_param;
    
    -- Insert transaction record for the new user's bonus
    INSERT INTO transactions (user_id, amount, type, status, description)
    VALUES (user_id_param, 10, 'bonus', 'completed', 'Account activation bonus');
    
    -- Check if this user was referred by someone
    SELECT * INTO referral_record
    FROM referrals
    WHERE referred_id = user_id_param AND status = 'pending' AND bonus_paid = false;
    
    -- If there's a valid referral, process the referrer's bonus
    IF FOUND THEN
        -- Update referral status
        UPDATE referrals
        SET status = 'completed', bonus_paid = true
        WHERE id = referral_record.id;
        
        -- Add bonus to the referrer (35 Taka)
        UPDATE users
        SET balance = balance + 35
        WHERE id = referral_record.referrer_id;
        
        -- Insert transaction record for the referrer's bonus
        INSERT INTO transactions (user_id, amount, type, status, description)
        VALUES (
            referral_record.referrer_id, 
            35, 
            'bonus', 
            'completed', 
            'Referral bonus for user activation'
        );
    END IF;
END;
$$;
