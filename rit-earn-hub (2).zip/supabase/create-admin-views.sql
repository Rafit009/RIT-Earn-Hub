-- Create admin_user_stats view if it doesn't exist
CREATE OR REPLACE VIEW admin_user_stats AS
SELECT 
  COUNT(*) as total_users,
  COUNT(CASE WHEN created_at > NOW() - INTERVAL '7 days' THEN 1 END) as new_users_last_week,
  SUM(referral_count) as total_referrals,
  SUM(completed_tasks) as total_completed_tasks,
  SUM(total_earnings) as total_earnings_all_users
FROM profiles;

-- Create admin_task_stats view if it doesn't exist
CREATE OR REPLACE VIEW admin_task_stats AS
SELECT 
  t.id,
  t.title,
  COUNT(ut.id) as total_attempts,
  COUNT(CASE WHEN ut.status = 'completed' THEN 1 END) as completed_count,
  COUNT(CASE WHEN ut.status = 'pending' THEN 1 END) as pending_count
FROM tasks t
LEFT JOIN user_tasks ut ON t.id = ut.task_id
GROUP BY t.id, t.title;

-- Grant access to the views
GRANT SELECT ON admin_user_stats TO authenticated;
GRANT SELECT ON admin_task_stats TO authenticated;
