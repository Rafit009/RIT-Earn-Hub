-- Add admin flag to profiles table
ALTER TABLE profiles ADD COLUMN is_admin BOOLEAN DEFAULT false;

-- Create admin-specific RLS policies
CREATE POLICY "Admins can view all profiles" 
  ON profiles FOR SELECT 
  USING (auth.uid() IN (SELECT id FROM profiles WHERE is_admin = true));

CREATE POLICY "Admins can update all profiles" 
  ON profiles FOR UPDATE 
  USING (auth.uid() IN (SELECT id FROM profiles WHERE is_admin = true));

-- Create admin-specific task management policies
CREATE POLICY "Only admins can insert tasks" 
  ON tasks FOR INSERT 
  WITH CHECK (auth.uid() IN (SELECT id FROM profiles WHERE is_admin = true));

CREATE POLICY "Only admins can update tasks" 
  ON tasks FOR UPDATE 
  USING (auth.uid() IN (SELECT id FROM profiles WHERE is_admin = true));

CREATE POLICY "Only admins can delete tasks" 
  ON tasks FOR DELETE 
  USING (auth.uid() IN (SELECT id FROM profiles WHERE is_admin = true));

-- Create admin dashboard views
CREATE VIEW admin_user_stats AS
SELECT 
  COUNT(*) as total_users,
  COUNT(CASE WHEN created_at > NOW() - INTERVAL '7 days' THEN 1 END) as new_users_last_week,
  SUM(referral_count) as total_referrals,
  SUM(completed_tasks) as total_completed_tasks,
  SUM(total_earnings) as total_earnings_all_users
FROM profiles;

CREATE VIEW admin_task_stats AS
SELECT 
  t.id,
  t.title,
  COUNT(ut.id) as total_attempts,
  COUNT(CASE WHEN ut.status = 'completed' THEN 1 END) as completed_count,
  COUNT(CASE WHEN ut.status = 'pending' THEN 1 END) as pending_count
FROM tasks t
LEFT JOIN user_tasks ut ON t.id = ut.task_id
GROUP BY t.id, t.title;

-- Create RLS policies for admin views
ALTER TABLE admin_user_stats ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Only admins can view admin stats" 
  ON admin_user_stats FOR SELECT 
  USING (auth.uid() IN (SELECT id FROM profiles WHERE is_admin = true));

ALTER TABLE admin_task_stats ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Only admins can view task stats" 
  ON admin_task_stats FOR SELECT 
  USING (auth.uid() IN (SELECT id FROM profiles WHERE is_admin = true));
