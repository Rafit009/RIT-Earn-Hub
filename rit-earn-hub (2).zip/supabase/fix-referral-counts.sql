-- Function to fix referral counts for all users
CREATE OR REPLACE FUNCTION fix_referral_counts()
RETURNS void AS $$
DECLARE
  user_record RECORD;
  actual_count INTEGER;
BEGIN
  -- Loop through all users
  FOR user_record IN SELECT id FROM profiles
  LOOP
    -- Count actual referrals for this user
    SELECT COUNT(*) INTO actual_count 
    FROM referrals 
    WHERE referrer_id = user_record.id;
    
    -- Update the user's referral_count to match the actual count
    UPDATE profiles
    SET referral_count = actual_count
    WHERE id = user_record.id;
    
    RAISE NOTICE 'Updated referral count for user %: %', user_record.id, actual_count;
  END LOOP;
END;
$$ LANGUAGE plpgsql;

-- Execute the function to fix all referral counts
SELECT fix_referral_counts();

-- Create a trigger to keep referral counts in sync
CREATE OR REPLACE FUNCTION update_referrer_count()
RETURNS TRIGGER AS $$
BEGIN
  -- When a new referral is added
  IF TG_OP = 'INSERT' THEN
    -- Increment the referrer's count
    UPDATE profiles
    SET referral_count = COALESCE(referral_count, 0) + 1
    WHERE id = NEW.referrer_id;
  
  -- When a referral is deleted
  ELSIF TG_OP = 'DELETE' THEN
    -- Decrement the referrer's count
    UPDATE profiles
    SET referral_count = GREATEST(COALESCE(referral_count, 0) - 1, 0)
    WHERE id = OLD.referrer_id;
  END IF;
  
  RETURN NULL;
END;
$$ LANGUAGE plpgsql;

-- Drop the trigger if it exists
DROP TRIGGER IF EXISTS referral_count_trigger ON referrals;

-- Create the trigger
CREATE TRIGGER referral_count_trigger
AFTER INSERT OR DELETE ON referrals
FOR EACH ROW
EXECUTE FUNCTION update_referrer_count();
