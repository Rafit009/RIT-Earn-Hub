-- Create a function to check if a user has permission to view a referral
CREATE OR REPLACE FUNCTION check_referral_permission(referral_id UUID)
RETURNS BOOLEAN AS $$
DECLARE
  is_permitted BOOLEAN;
BEGIN
  SELECT EXISTS (
    SELECT 1
    FROM referrals
    WHERE id = referral_id
    AND referrer_id = auth.uid()
  ) INTO is_permitted;
  
  RETURN is_permitted;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Grant execute permission to authenticated users
GRANT EXECUTE ON FUNCTION check_referral_permission TO authenticated;
