-- Fix the deposits table to ensure both method and payment_method fields exist
DO $$
BEGIN
  -- Check if method column exists in deposits table
  IF NOT EXISTS (
    SELECT 1 
    FROM information_schema.columns 
    WHERE table_name = 'deposits' 
    AND column_name = 'method'
  ) THEN
    -- Add method column if it doesn't exist
    ALTER TABLE deposits ADD COLUMN method TEXT;
    
    -- Copy values from payment_method to method if payment_method exists
    IF EXISTS (
      SELECT 1 
      FROM information_schema.columns 
      WHERE table_name = 'deposits' 
      AND column_name = 'payment_method'
    ) THEN
      UPDATE deposits 
      SET method = payment_method 
      WHERE payment_method IS NOT NULL;
    END IF;
  END IF;

  -- Check if payment_method column exists in deposits table
  IF NOT EXISTS (
    SELECT 1 
    FROM information_schema.columns 
    WHERE table_name = 'deposits' 
    AND column_name = 'payment_method'
  ) THEN
    -- Add payment_method column if it doesn't exist
    ALTER TABLE deposits ADD COLUMN payment_method TEXT;
    
    -- Copy values from method to payment_method if method exists
    IF EXISTS (
      SELECT 1 
      FROM information_schema.columns 
      WHERE table_name = 'deposits' 
      AND column_name = 'method'
    ) THEN
      UPDATE deposits 
      SET payment_method = method 
      WHERE method IS NOT NULL;
    END IF;
  END IF;

  -- Ensure all existing records have both fields populated
  UPDATE deposits 
  SET method = payment_method 
  WHERE method IS NULL AND payment_method IS NOT NULL;
  
  UPDATE deposits 
  SET payment_method = method 
  WHERE payment_method IS NULL AND method IS NOT NULL;
  
  -- If both are NULL, set a default value
  UPDATE deposits 
  SET method = 'unknown', payment_method = 'unknown' 
  WHERE method IS NULL AND payment_method IS NULL;
END $$;
