-- Create a function to check if a column exists in a table if it doesn't already exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 
    FROM pg_proc 
    WHERE proname = 'check_column_exists'
  ) THEN
    -- Create the function
    CREATE OR REPLACE FUNCTION check_column_exists(
      table_name TEXT,
      column_name TEXT
    ) RETURNS TABLE (exists BOOLEAN) AS $$
    BEGIN
      RETURN QUERY
      SELECT EXISTS (
        SELECT 1
        FROM information_schema.columns
        WHERE table_name = check_column_exists.table_name
        AND column_name = check_column_exists.column_name
      );
    END;
    $$ LANGUAGE plpgsql;

    -- Grant execute permission to authenticated users
    GRANT EXECUTE ON FUNCTION check_column_exists TO authenticated;
    
    RAISE NOTICE 'Created check_column_exists function';
  ELSE
    RAISE NOTICE 'check_column_exists function already exists';
  END IF;
END $$;
