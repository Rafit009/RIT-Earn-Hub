-- Check if the withdrawals table has the correct schema
DO $$
BEGIN
  -- Check if the 'method' column exists, if not add it
  IF NOT EXISTS (
    SELECT 1 
    FROM information_schema.columns 
    WHERE table_name = 'withdrawals' 
    AND column_name = 'method'
  ) THEN
    ALTER TABLE withdrawals ADD COLUMN method TEXT NOT NULL DEFAULT 'bkash';
  END IF;

  -- Ensure other required columns exist
  ALTER TABLE withdrawals ADD COLUMN IF NOT EXISTS phone_number TEXT;
  ALTER TABLE withdrawals ADD COLUMN IF NOT EXISTS status TEXT DEFAULT 'pending';
  ALTER TABLE withdrawals ADD COLUMN IF NOT EXISTS transaction_id TEXT;
  
  -- If payment_method exists but method doesn't, copy values
  IF EXISTS (
    SELECT 1 
    FROM information_schema.columns 
    WHERE table_name = 'withdrawals' 
    AND column_name = 'payment_method'
  ) AND EXISTS (
    SELECT 1 
    FROM information_schema.columns 
    WHERE table_name = 'withdrawals' 
    AND column_name = 'method'
  ) THEN
    -- Update method with payment_method values where method is null
    UPDATE withdrawals 
    SET method = payment_method 
    WHERE method IS NULL AND payment_method IS NOT NULL;
  END IF;
END $$;

-- Update the notify_transaction_webhook function to handle both column names
CREATE OR REPLACE FUNCTION notify_transaction_webhook()
RETURNS TRIGGER AS $$
DECLARE
  webhook_url TEXT := 'https://v0-rafit-it-zone-earn.vercel.app/api/telegram-notify';
  payload JSONB;
  record_data JSONB;
BEGIN
  -- Convert the record to JSON
  record_data := row_to_json(NEW)::jsonb;
  
  -- Ensure required fields exist to prevent errors
  IF record_data ? 'method' IS NOT TRUE AND record_data ? 'payment_method' IS NOT TRUE THEN
    record_data := record_data || '{"method": "unknown"}'::jsonb;
  END IF;
  
  IF record_data ? 'phone_number' IS NOT TRUE THEN
    record_data := record_data || '{"phone_number": "N/A"}'::jsonb;
  END IF;
  
  IF record_data ? 'transaction_id' IS NOT TRUE THEN
    record_data := record_data || '{"transaction_id": "N/A"}'::jsonb;
  END IF;
  
  -- Create the payload with the transaction data
  payload := jsonb_build_object(
    'record', jsonb_build_object(
      'new', record_data
    )
  );
  
  -- Send the HTTP request
  PERFORM http_post(
    webhook_url,
    payload,
    'application/json'
  );
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
