-- Set admin status for the specified user (rafitbd23@gmail.com)
DO $$
DECLARE
  user_id UUID;
BEGIN
  -- Get the user ID from the auth.users table
  SELECT id INTO user_id
  FROM auth.users
  WHERE email = 'rafitbd23@gmail.com';
  
  -- If user exists, set admin status
  IF user_id IS NOT NULL THEN
    -- Update the is_admin flag in the profiles table
    UPDATE profiles
    SET is_admin = true
    WHERE id = user_id;
    
    RAISE NOTICE 'Admin status set for user with email rafitbd23@gmail.com';
  ELSE
    RAISE NOTICE 'User with email rafitbd23@gmail.com not found';
  END IF;
END $$;
