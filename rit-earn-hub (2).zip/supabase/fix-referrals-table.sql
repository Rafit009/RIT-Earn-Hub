-- Add missing columns to referrals table if they don't exist
DO $$
BEGIN
  -- Check if reward column exists in referrals table
  IF NOT EXISTS (
    SELECT 1 
    FROM information_schema.columns 
    WHERE table_name = 'referrals' 
    AND column_name = 'reward'
  ) THEN
    -- Add reward column with default value
    ALTER TABLE referrals ADD COLUMN reward DECIMAL(10, 2) DEFAULT 5.00;
    
    -- Update existing referrals with default reward value
    UPDATE referrals SET reward = 5.00 WHERE reward IS NULL;
  END IF;

  -- Check if status column exists in referrals table
  IF NOT EXISTS (
    SELECT 1 
    FROM information_schema.columns 
    WHERE table_name = 'referrals' 
    AND column_name = 'status'
  ) THEN
    -- Add status column with default value
    ALTER TABLE referrals ADD COLUMN status TEXT DEFAULT 'pending';
    
    -- Update status based on referred user's activation status
    UPDATE referrals r
    SET status = CASE 
      WHEN EXISTS (
        SELECT 1 FROM profiles p 
        WHERE p.id = r.referred_id 
        AND p.is_active = true
      ) THEN 'active'
      ELSE 'pending'
    END;
  END IF;
END $$;
