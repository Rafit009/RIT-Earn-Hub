-- Add status field to referrals table if it doesn't exist
ALTER TABLE referrals ADD COLUMN IF NOT EXISTS status TEXT DEFAULT 'pending';

-- Create a function to update referral status when a user activates their account
CREATE OR REPLACE FUNCTION update_referral_status()
RETURNS TRIGGER AS $$
BEGIN
  -- If account is being activated
  IF NEW.is_active = true AND OLD.is_active = false THEN
    -- Update any referrals where this user is the referred user
    UPDATE referrals
    SET status = 'active'
    WHERE referred_id = NEW.id AND status = 'pending';
    
    -- If this user was referred, give the referrer their bonus
    IF NEW.referred_by IS NOT NULL THEN
      -- Add the signup bonus to the referrer's balance and earnings
      UPDATE profiles
      SET 
        balance = balance + 10.0,
        referral_earnings = referral_earnings + 10.0,
        total_earnings = total_earnings + 10.0
      WHERE id = NEW.referred_by;
      
      -- Log the activity
      INSERT INTO activity_log (
        user_id, 
        activity_type, 
        description, 
        metadata
      )
      VALUES (
        NEW.referred_by,
        'referral_bonus',
        'Received bonus for referral activation',
        jsonb_build_object(
          'referred_id', NEW.id,
          'referred_username', NEW.username,
          'bonus_amount', 10.0
        )
      );
    END IF;
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create a trigger to run the function when a profile is updated
DROP TRIGGER IF EXISTS on_account_activation ON profiles;
CREATE TRIGGER on_account_activation
  AFTER UPDATE OF is_active ON profiles
  FOR EACH ROW
  WHEN (OLD.is_active = false AND NEW.is_active = true)
  EXECUTE FUNCTION update_referral_status();

-- Update the complete_task function to properly track referral earnings
CREATE OR REPLACE FUNCTION complete_task(user_id UUID, reward_amount DECIMAL)
RETURNS void AS $$
DECLARE
  referrer_id UUID;
  referral_reward DECIMAL := reward_amount * 0.05; -- 5% of task reward goes to referrer
  referred_username TEXT;
BEGIN
  -- Get the username for logging
  SELECT username INTO referred_username FROM profiles WHERE id = user_id;
  
  -- Update user balance and stats
  UPDATE profiles
  SET 
    balance = balance + reward_amount,
    total_earnings = total_earnings + reward_amount,
    completed_tasks = completed_tasks + 1
  WHERE id = user_id;
  
  -- Log the activity
  INSERT INTO activity_log (user_id, activity_type, description, metadata)
  VALUES (
    user_id, 
    'task_completed', 
    'Completed a task and earned reward', 
    jsonb_build_object('reward', reward_amount)
  );
  
  -- Check if user was referred by someone
  SELECT referred_by INTO referrer_id FROM profiles WHERE id = user_id;
  
  -- If user was referred, reward the referrer
  IF referrer_id IS NOT NULL THEN
    UPDATE profiles
    SET 
      balance = balance + referral_reward,
      referral_earnings = referral_earnings + referral_reward,
      total_earnings = total_earnings + referral_reward
    WHERE id = referrer_id;
    
    -- Log the referral reward activity with more details
    INSERT INTO activity_log (user_id, activity_type, description, metadata)
    VALUES (
      referrer_id, 
      'referral_reward', 
      'Earned 5% bonus from referred user completing a task', 
      jsonb_build_object(
        'referred_id', user_id, 
        'referred_username', referred_username,
        'reward', referral_reward,
        'task_reward', reward_amount
      )
    );
  END IF;
END;
$$ LANGUAGE plpgsql;
