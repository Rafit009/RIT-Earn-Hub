-- Check for duplicate profiles and remove them
CREATE OR REPLACE FUNCTION remove_duplicate_profiles()
RETURNS void AS $$
DECLARE
  duplicate_user RECORD;
BEGIN
  -- Find users with multiple profiles
  FOR duplicate_user IN 
    SELECT id, COUNT(*) 
    FROM profiles 
    GROUP BY id 
    HAVING COUNT(*) > 1
  LOOP
    -- Keep the most recently updated profile and delete others
    DELETE FROM profiles 
    WHERE id = duplicate_user.id 
    AND ctid NOT IN (
      SELECT ctid 
      FROM profiles 
      WHERE id = duplicate_user.id 
      ORDER BY updated_at DESC NULLS LAST 
      LIMIT 1
    );
    
    RAISE NOTICE 'Removed duplicate profiles for user %', duplicate_user.id;
  END LOOP;
END;
$$ LANGUAGE plpgsql;

-- Execute the function
SELECT remove_duplicate_profiles();

-- Create a function to ensure all users have profiles
CREATE OR REPLACE FUNCTION ensure_user_profiles()
RETURNS void AS $$
DECLARE
  user_without_profile RECORD;
BEGIN
  -- Find auth users without profiles
  FOR user_without_profile IN 
    SELECT au.id, au.email
    FROM auth.users au
    LEFT JOIN profiles p ON au.id = p.id
    WHERE p.id IS NULL
  LOOP
    -- Create a profile for the user
    INSERT INTO profiles (
      id, 
      username, 
      email, 
      balance, 
      referral_code, 
      is_active,
      created_at,
      updated_at
    ) VALUES (
      user_without_profile.id,
      'user_' || SUBSTRING(user_without_profile.id::text, 1, 8),
      user_without_profile.email,
      0,
      'RAFIT' || SUBSTRING(user_without_profile.id::text, 1, 8) || UPPER(SUBSTRING(MD5(random()::text), 1, 4)),
      false,
      NOW(),
      NOW()
    );
    
    RAISE NOTICE 'Created profile for user %', user_without_profile.id;
  END LOOP;
END;
$$ LANGUAGE plpgsql;

-- Execute the function
SELECT ensure_user_profiles();

-- Add a trigger to automatically create profiles for new users if the existing trigger fails
CREATE OR REPLACE FUNCTION public.ensure_profile_exists() 
RETURNS TRIGGER AS $$
BEGIN
  -- Check if a profile already exists
  IF NOT EXISTS (SELECT 1 FROM public.profiles WHERE id = NEW.id) THEN
    -- Create a basic profile
    INSERT INTO public.profiles (
      id, 
      username, 
      email, 
      balance, 
      referral_code, 
      is_active,
      created_at,
      updated_at
    ) VALUES (
      NEW.id,
      'user_' || SUBSTRING(NEW.id::text, 1, 8),
      NEW.email,
      0,
      'RAFIT' || SUBSTRING(NEW.id::text, 1, 8) || UPPER(SUBSTRING(MD5(random()::text), 1, 4)),
      false,
      NOW(),
      NOW()
    );
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create a trigger that runs after the main handle_new_user trigger
DROP TRIGGER IF EXISTS ensure_profile_exists_trigger ON auth.users;
CREATE TRIGGER ensure_profile_exists_trigger
AFTER INSERT ON auth.users
FOR EACH ROW
EXECUTE PROCEDURE public.ensure_profile_exists();
