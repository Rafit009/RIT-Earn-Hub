-- Ensure the admin user has admin privileges
DO $$
DECLARE
  admin_email TEXT := 'rafitbd23@gmail.com';
  admin_id UUID;
BEGIN
  -- Get the user ID from the auth.users table
  SELECT id INTO admin_id
  FROM auth.users
  WHERE email = admin_email;
  
  -- If user exists, set admin status
  IF admin_id IS NOT NULL THEN
    -- Update the is_admin flag in the profiles table
    UPDATE profiles
    SET is_admin = true
    WHERE id = admin_id;
    
    -- Make sure the row exists in profiles
    IF NOT FOUND THEN
      -- Create the profile if it doesn't exist
      INSERT INTO profiles (
        id, 
        username, 
        email,
        is_admin,
        balance,
        referral_code,
        created_at,
        updated_at
      ) VALUES (
        admin_id,
        'admin_user',
        admin_email,
        true,
        0,
        'ADMIN' || SUBSTRING(admin_id::text, 1, 8),
        NOW(),
        NOW()
      );
    END IF;
    
    RAISE NOTICE 'Admin status set for user with email % (ID: %)', admin_email, admin_id;
  ELSE
    RAISE NOTICE 'User with email % not found', admin_email;
  END IF;
END $$;

-- Create a function to check and fix admin access
CREATE OR REPLACE FUNCTION ensure_admin_access(admin_email TEXT)
RETURNS BOOLEAN AS $$
DECLARE
  admin_id UUID;
  success BOOLEAN := false;
BEGIN
  -- Get the user ID from the auth.users table
  SELECT id INTO admin_id
  FROM auth.users
  WHERE email = admin_email;
  
  -- If user exists, set admin status
  IF admin_id IS NOT NULL THEN
    -- Update the is_admin flag in the profiles table
    UPDATE profiles
    SET is_admin = true
    WHERE id = admin_id;
    
    -- Make sure the row exists in profiles
    IF NOT FOUND THEN
      -- Create the profile if it doesn't exist
      INSERT INTO profiles (
        id, 
        username, 
        email,
        is_admin,
        balance,
        referral_code,
        created_at,
        updated_at
      ) VALUES (
        admin_id,
        'admin_user',
        admin_email,
        true,
        0,
        'ADMIN' || SUBSTRING(admin_id::text, 1, 8),
        NOW(),
        NOW()
      );
    END IF;
    
    success := true;
  END IF;
  
  RETURN success;
END;
$$ LANGUAGE plpgsql;

-- Execute the function for the admin user
SELECT ensure_admin_access('rafitbd23@gmail.com');
