-- Create or replace function to update transaction status and handle the associated actions
CREATE OR REPLACE FUNCTION update_transaction_status(
  transaction_type TEXT,
  transaction_id UUID,
  new_status TEXT,
  updated_via TEXT DEFAULT 'admin_panel'
)
RETURNS BOOLEAN AS $$
DECLARE
  transaction_record RECORD;
  user_id UUID;
  amount DECIMAL;
  should_activate BOOLEAN := FALSE;
  user_record RECORD;
BEGIN
  -- Get the transaction details
  EXECUTE format('
    SELECT * FROM %I WHERE id = $1
  ', transaction_type)
  INTO transaction_record
  USING transaction_id;
  
  IF transaction_record IS NULL THEN
    RAISE EXCEPTION 'Transaction not found';
  END IF;
  
  -- Extract common fields
  user_id := transaction_record.user_id;
  amount := transaction_record.amount;
  
  -- Get the user record to check current status
  SELECT * INTO user_record 
  FROM profiles 
  WHERE id = user_id;
  
  -- Update transaction status
  EXECUTE format('
    UPDATE %I 
    SET status = $1, updated_at = NOW()
    WHERE id = $2
  ', transaction_type)
  USING new_status, transaction_id;
  
  -- Handle deposits that are completed
  IF transaction_type = 'deposits' AND new_status = 'completed' THEN
    -- Check if this deposit is enough to activate the account
    should_activate := amount >= 50 AND NOT user_record.is_active;
    
    -- Always update the balance regardless of activation status
    IF should_activate THEN
      -- Update balance and activate account
      UPDATE profiles
      SET 
        balance = COALESCE(balance, 0) + amount,
        is_active = TRUE
      WHERE id = user_id;
      
      -- Log activation in activity log
      INSERT INTO activity_log (
        user_id,
        activity_type,
        description,
        metadata
      )
      VALUES (
        user_id, 
        'account_activated', 
        'Your account has been activated with your deposit',
        jsonb_build_object(
          'transaction_id', transaction_id,
          'amount', amount,
          'updated_via', updated_via
        )
      );
    ELSE
      -- Just update balance
      UPDATE profiles
      SET balance = COALESCE(balance, 0) + amount
      WHERE id = user_id;
    END IF;
    
    -- Log the activity
    INSERT INTO activity_log (
      user_id,
      activity_type,
      description,
      metadata
    )
    VALUES (
      user_id, 
      'deposit_approved', 
      format('Your deposit of %s৳ has been approved', amount),
      jsonb_build_object(
        'transaction_id', transaction_id,
        'amount', amount,
        'approved_via', updated_via,
        'account_activated', should_activate
      )
    );
    
  ELSIF transaction_type = 'deposits' AND new_status = 'failed' THEN
    -- Log the declined deposit
    INSERT INTO activity_log (
      user_id,
      activity_type,
      description,
      metadata
    )
    VALUES (
      user_id, 
      'deposit_declined', 
      format('Your deposit of %s৳ has been declined', amount),
      jsonb_build_object(
        'transaction_id', transaction_id,
        'amount', amount,
        'declined_via', updated_via
      )
    );
    
  ELSIF transaction_type = 'withdrawals' AND new_status = 'completed' THEN
    -- Just log the activity (amount already deducted when creating withdrawal request)
    INSERT INTO activity_log (
      user_id,
      activity_type,
      description,
      metadata
    )
    VALUES (
      user_id, 
      'withdrawal_approved', 
      format('Your withdrawal of %s৳ has been approved', amount),
      jsonb_build_object(
        'transaction_id', transaction_id,
        'amount', amount,
        'approved_via', updated_via
      )
    );
    
  ELSIF transaction_type = 'withdrawals' AND new_status = 'failed' THEN
    -- If withdrawal is declined, refund the amount to user's balance
    UPDATE profiles
    SET balance = COALESCE(balance, 0) + amount
    WHERE id = user_id;
    
    -- Log the declined withdrawal
    INSERT INTO activity_log (
      user_id,
      activity_type,
      description,
      metadata
    )
    VALUES (
      user_id, 
      'withdrawal_declined', 
      format('Your withdrawal of %s৳ has been declined. The amount has been refunded to your balance.', amount),
      jsonb_build_object(
        'transaction_id', transaction_id,
        'amount', amount,
        'declined_via', updated_via
      )
    );
  END IF;
  
  RETURN TRUE;
EXCEPTION
  WHEN OTHERS THEN
    RAISE NOTICE 'Error in update_transaction_status: %', SQLERRM;
    RETURN FALSE;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
