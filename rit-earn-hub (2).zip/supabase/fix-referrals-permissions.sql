-- Fix permissions for referrals table
DO $$
BEGIN
  -- Check if the policy exists
  IF NOT EXISTS (
    SELECT 1 
    FROM pg_policies 
    WHERE tablename = 'referrals' 
    AND policyname = 'Users can view their own referrals'
  ) THEN
    -- Create the policy if it doesn't exist
    CREATE POLICY "Users can view their own referrals" 
      ON referrals FOR SELECT 
      USING (auth.uid() = referrer_id);
    
    RAISE NOTICE 'Created policy for users to view their own referrals';
  ELSE
    RAISE NOTICE 'Policy for users to view their own referrals already exists';
  END IF;
  
  -- Make sure RLS is enabled on the referrals table
  ALTER TABLE referrals ENABLE ROW LEVEL SECURITY;
  
  -- Grant necessary permissions to authenticated users
  GRANT SELECT ON referrals TO authenticated;
  GRANT SELECT ON profiles TO authenticated;
END $$;
