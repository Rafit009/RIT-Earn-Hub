-- Create a function to execute arbitrary SQL safely (admin use only)
CREATE OR REPLACE FUNCTION exec_sql(sql text)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  result jsonb;
BEGIN
  -- Check if the function is being called by an authenticated user
  IF auth.uid() IS NULL THEN
    RAISE EXCEPTION 'Unauthorized';
  END IF;
  
  -- Check if user is admin
  DECLARE
    is_admin_user BOOLEAN;
  BEGIN
    SELECT is_admin INTO is_admin_user
    FROM profiles
    WHERE id = auth.uid();
    
    IF NOT COALESCE(is_admin_user, FALSE) THEN
      RAISE EXCEPTION 'Only admin users can execute SQL';
    END IF;
  END;
  
  -- Execute the SQL
  EXECUTE sql;
  
  -- Return success
  result := jsonb_build_object('success', true);
  
  RETURN result;
EXCEPTION
  WHEN OTHERS THEN
    RETURN jsonb_build_object(
      'success', false,
      'error', SQLERRM,
      'detail', SQLSTATE
    );
END;
$$;

-- Grant execute permission to authenticated users (who will be verified as admins inside the function)
GRANT EXECUTE ON FUNCTION exec_sql TO authenticated;
