-- Fix admin user function
DO $$
DECLARE
  user_id UUID;
BEGIN
  -- Get the user ID from the auth.users table
  SELECT id INTO user_id
  FROM auth.users
  WHERE email = 'rafitbd23@gmail.com';
  
  -- If user exists, set admin status
  IF user_id IS NOT NULL THEN
    -- Update the is_admin flag in the profiles table
    UPDATE profiles
    SET is_admin = true
    WHERE id = user_id;
    
    -- Make sure the row exists in profiles
    IF NOT FOUND THEN
      -- Create the profile if it doesn't exist
      INSERT INTO profiles (
        id, 
        username, 
        email,
        is_admin,
        balance,
        referral_code,
        created_at,
        updated_at
      ) VALUES (
        user_id,
        'admin_user',
        'rafitbd23@gmail.com',
        true,
        0,
        'ADMIN' || SUBSTRING(user_id::text, 1, 8),
        NOW(),
        NOW()
      );
    END IF;
    
    RAISE NOTICE 'Admin status set for user with email rafitbd23@gmail.com (ID: %)', user_id;
  ELSE
    RAISE NOTICE 'User with email rafitbd23@gmail.com not found';
  END IF;
END $$;
