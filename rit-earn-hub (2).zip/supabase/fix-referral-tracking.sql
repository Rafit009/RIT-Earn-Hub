-- Create a function to ensure referrals are properly tracked
CREATE OR REPLACE FUNCTION ensure_referral_tracking()
RETURNS TRIGGER AS $$
BEGIN
  -- If a user is being activated (is_active changed from false to true)
  IF NEW.is_active = true AND OLD.is_active = false THEN
    -- Update any referrals where this user is the referred user
    UPDATE referrals
    SET status = 'active'
    WHERE referred_id = NEW.id AND status = 'pending';
    
    -- If this user was referred, give the referrer their bonus
    IF NEW.referred_by IS NOT NULL THEN
      -- Add the signup bonus to the referrer's balance and earnings
      UPDATE profiles
      SET 
        balance = balance + 10.0,
        referral_earnings = referral_earnings + 10.0,
        total_earnings = total_earnings + 10.0
      WHERE id = NEW.referred_by;
      
      -- Log the activity
      INSERT INTO activity_log (
        user_id, 
        activity_type, 
        description, 
        metadata
      )
      VALUES (
        NEW.referred_by,
        'referral_bonus',
        'Received bonus for referral activation',
        jsonb_build_object(
          'referred_id', NEW.id,
          'referred_username', NEW.username,
          'bonus_amount', 10.0
        )
      );
    END IF;
  END IF;  NEW.username,
          'bonus_amount', 10.0
        )
      );
    END IF;
  END IF;

  -- When a task is completed by a referred user, reward the referrer
  IF TG_TABLE_NAME = 'user_tasks' AND NEW.status = 'completed' AND OLD.status != 'completed' THEN
    -- Get the user who completed the task
    DECLARE
      task_user_id UUID := NEW.user_id;
      referrer_id UUID;
      task_reward DECIMAL;
      referral_bonus DECIMAL;
    BEGIN
      -- Check if this user was referred by someone
      SELECT referred_by INTO referrer_id 
      FROM profiles 
      WHERE id = task_user_id;
      
      -- If user was referred, calculate and award the bonus
      IF referrer_id IS NOT NULL THEN
        -- Get the task reward
        SELECT reward INTO task_reward
        FROM tasks
        WHERE id = NEW.task_id;
        
        -- Calculate 5% bonus
        referral_bonus := task_reward * 0.05;
        
        -- Update referrer's balance and earnings
        UPDATE profiles
        SET 
          balance = balance + referral_bonus,
          referral_earnings = referral_earnings + referral_bonus,
          total_earnings = total_earnings + referral_bonus
        WHERE id = referrer_id;
        
        -- Log the activity
        INSERT INTO activity_log (
          user_id, 
          activity_type, 
          description, 
          metadata
        )
        VALUES (
          referrer_id,
          'referral_task_bonus',
          'Earned bonus from referred user completing a task',
          jsonb_build_object(
            'referred_id', task_user_id,
            'task_id', NEW.task_id,
            'bonus_amount', referral_bonus
          )
        );
      END IF;
    END;
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create or replace the trigger for profile updates
DROP TRIGGER IF EXISTS on_profile_update ON profiles;
CREATE TRIGGER on_profile_update
  AFTER UPDATE ON profiles
  FOR EACH ROW
  EXECUTE FUNCTION ensure_referral_tracking();

-- Create or replace the trigger for task completions
DROP TRIGGER IF EXISTS on_task_completion ON user_tasks;
CREATE TRIGGER on_task_completion
  AFTER UPDATE ON user_tasks
  FOR EACH ROW
  EXECUTE FUNCTION ensure_referral_tracking();

-- Function to fix any missing referral counts
CREATE OR REPLACE FUNCTION fix_referral_counts()
RETURNS void AS $$
DECLARE
  user_record RECORD;
BEGIN
  -- Loop through all users
  FOR user_record IN SELECT id FROM profiles
  LOOP
    -- Update referral count based on actual referrals
    UPDATE profiles p
    SET referral_count = (
      SELECT COUNT(*) 
      FROM referrals 
      WHERE referrer_id = p.id
    )
    WHERE id = user_record.id;
    
    -- Update referral earnings based on actual referral earnings
    UPDATE profiles p
    SET referral_earnings = COALESCE((
      SELECT SUM(reward) 
      FROM referrals 
      WHERE referrer_id = p.id
    ), 0)
    WHERE id = user_record.id;
  END LOOP;
END;
$$ LANGUAGE plpgsql;

-- Execute the function to fix all referral counts
SELECT fix_referral_counts();
