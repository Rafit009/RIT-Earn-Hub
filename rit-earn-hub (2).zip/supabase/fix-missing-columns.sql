-- Add missing columns to profiles table if they don't exist
DO $$
BEGIN
  -- Check if referral_earnings column exists
  IF NOT EXISTS (
    SELECT 1 
    FROM information_schema.columns 
    WHERE table_name = 'profiles' 
    AND column_name = 'referral_earnings'
  ) THEN
    -- Add referral_earnings column
    ALTER TABLE profiles ADD COLUMN referral_earnings DECIMAL(10, 2) DEFAULT 0;
    
    -- Update existing profiles to calculate referral_earnings from referrals table
    UPDATE profiles p
    SET referral_earnings = COALESCE(
      (SELECT SUM(reward) FROM referrals WHERE referrer_id = p.id),
      0
    );
  END IF;

  -- Check for other potentially missing columns and add them if needed
  IF NOT EXISTS (
    SELECT 1 
    FROM information_schema.columns 
    WHERE table_name = 'profiles' 
    AND column_name = 'total_earnings'
  ) THEN
    ALTER TABLE profiles ADD COLUMN total_earnings DECIMAL(10, 2) DEFAULT 0;
  END IF;

  IF NOT EXISTS (
    SELECT 1 
    FROM information_schema.columns 
    WHERE table_name = 'profiles' 
    AND column_name = 'completed_tasks'
  ) THEN
    ALTER TABLE profiles ADD COLUMN completed_tasks INTEGER DEFAULT 0;
  END IF;

  IF NOT EXISTS (
    SELECT 1 
    FROM information_schema.columns 
    WHERE table_name = 'profiles' 
    AND column_name = 'referral_count'
  ) THEN
    ALTER TABLE profiles ADD COLUMN referral_count INTEGER DEFAULT 0;
    
    -- Update existing profiles to calculate referral_count from referrals table
    UPDATE profiles p
    SET referral_count = COALESCE(
      (SELECT COUNT(*) FROM referrals WHERE referrer_id = p.id),
      0
    );
  END IF;

  IF NOT EXISTS (
    SELECT 1 
    FROM information_schema.columns 
    WHERE table_name = 'profiles' 
    AND column_name = 'is_active'
  ) THEN
    ALTER TABLE profiles ADD COLUMN is_active BOOLEAN DEFAULT false;
  END IF;

  IF NOT EXISTS (
    SELECT 1 
    FROM information_schema.columns 
    WHERE table_name = 'profiles' 
    AND column_name = 'is_admin'
  ) THEN
    ALTER TABLE profiles ADD COLUMN is_admin BOOLEAN DEFAULT false;
  END IF;
END $$;
