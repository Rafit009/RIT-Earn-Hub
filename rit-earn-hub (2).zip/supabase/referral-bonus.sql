-- Update the complete_task function to give referrers a 5% bonus
CREATE OR REPLACE FUNCTION complete_task(user_id UUID, reward_amount DECIMAL)
RETURNS void AS $$
DECLARE
  referrer_id UUID;
  referral_reward DECIMAL := reward_amount * 0.05; -- 5% of task reward goes to referrer
BEGIN
  -- Update user balance and stats
  UPDATE profiles
  SET 
    balance = balance + reward_amount,
    total_earnings = total_earnings + reward_amount,
    completed_tasks = completed_tasks + 1
  WHERE id = user_id;
  
  -- Log the activity
  INSERT INTO activity_log (user_id, activity_type, description, metadata)
  VALUES (
    user_id, 
    'task_completed', 
    'Completed a task and earned reward', 
    jsonb_build_object('reward', reward_amount)
  );
  
  -- Check if user was referred by someone
  SELECT referred_by INTO referrer_id FROM profiles WHERE id = user_id;
  
  -- If user was referred, reward the referrer
  IF referrer_id IS NOT NULL THEN
    UPDATE profiles
    SET 
      balance = balance + referral_reward,
      referral_earnings = referral_earnings + referral_reward,
      total_earnings = total_earnings + referral_reward
    WHERE id = referrer_id;
    
    -- Log the referral reward activity
    INSERT INTO activity_log (user_id, activity_type, description, metadata)
    VALUES (
      referrer_id, 
      'referral_reward', 
      'Earned 5% bonus from referred user completing a task', 
      jsonb_build_object('referred_user_id', user_id, 'reward', referral_reward)
    );
  END IF;
END;
$$ LANGUAGE plpgsql;
