-- Create tables for RIT Earn Hub

-- Profiles table to store user information
CREATE TABLE profiles (
  id UUID REFERENCES auth.users ON DELETE CASCADE PRIMARY KEY,
  username TEXT UNIQUE NOT NULL,
  full_name TEXT,
  email TEXT UNIQUE,
  balance DECIMAL(10, 2) DEFAULT 0,
  referral_code TEXT UNIQUE,
  referred_by UUID REFERENCES profiles(id),
  referral_count INTEGER DEFAULT 0,
  referral_earnings DECIMAL(10, 2) DEFAULT 0,
  total_earnings DECIMAL(10, 2) DEFAULT 0,
  completed_tasks INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Tasks table to store available tasks
CREATE TABLE tasks (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  title TEXT NOT NULL,
  description TEXT,
  reward DECIMAL(10, 2) NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- User tasks table to track task completion
CREATE TABLE user_tasks (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
  task_id UUID REFERENCES tasks(id) ON DELETE CASCADE,
  status TEXT DEFAULT 'available', -- available, pending, completed
  started_at TIMESTAMP WITH TIME ZONE,
  completed_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(user_id, task_id)
);

-- Referrals table to track referrals
CREATE TABLE referrals (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  referrer_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
  referred_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
  reward DECIMAL(10, 2) DEFAULT 5.00,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(referred_id)
);

-- Deposits table to track deposits
CREATE TABLE deposits (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
  amount DECIMAL(10, 2) NOT NULL,
  payment_method TEXT NOT NULL,
  transaction_id TEXT NOT NULL,
  phone_number TEXT NOT NULL,
  status TEXT DEFAULT 'pending', -- pending, completed, failed
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Withdrawals table to track withdrawals
CREATE TABLE withdrawals (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
  amount DECIMAL(10, 2) NOT NULL,
  payment_method TEXT NOT NULL,
  phone_number TEXT NOT NULL,
  status TEXT DEFAULT 'pending', -- pending, completed, failed
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- User activity log table
CREATE TABLE activity_log (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
  activity_type TEXT NOT NULL, -- login, signup, task_completed, referral, deposit, withdrawal
  description TEXT,
  metadata JSONB,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Function to handle task completion and update user balance
CREATE OR REPLACE FUNCTION complete_task(user_id UUID, reward_amount DECIMAL)
RETURNS void AS $$
DECLARE
  referrer_id UUID;
  referral_reward DECIMAL := reward_amount * 0.1; -- 10% of task reward goes to referrer
BEGIN
  -- Update user balance and stats
  UPDATE profiles
  SET 
    balance = balance + reward_amount,
    total_earnings = total_earnings + reward_amount,
    completed_tasks = completed_tasks + 1
  WHERE id = user_id;
  
  -- Log the activity
  INSERT INTO activity_log (user_id, activity_type, description, metadata)
  VALUES (
    user_id, 
    'task_completed', 
    'Completed a task and earned reward', 
    jsonb_build_object('reward', reward_amount)
  );
  
  -- Check if user was referred by someone
  SELECT referred_by INTO referrer_id FROM profiles WHERE id = user_id;
  
  -- If user was referred, reward the referrer
  IF referrer_id IS NOT NULL THEN
    UPDATE profiles
    SET 
      balance = balance + referral_reward,
      referral_earnings = referral_earnings + referral_reward,
      total_earnings = total_earnings + referral_reward
    WHERE id = referrer_id;
    
    -- Log the referral reward activity
    INSERT INTO activity_log (user_id, activity_type, description, metadata)
    VALUES (
      referrer_id, 
      'referral_reward', 
      'Earned reward from referred user completing a task', 
      jsonb_build_object('referred_user_id', user_id, 'reward', referral_reward)
    );
  END IF;
END;
$$ LANGUAGE plpgsql;

-- Function to generate a unique referral code
CREATE OR REPLACE FUNCTION generate_referral_code(user_id UUID)
RETURNS TEXT AS $$
DECLARE
  new_code TEXT;
  code_exists BOOLEAN;
BEGIN
  LOOP
    -- Generate a referral code with format RAFIT + first 8 chars of user_id + 4 random chars
    new_code := 'RAFIT' || SUBSTRING(user_id::TEXT, 1, 8) || UPPER(SUBSTRING(MD5(random()::TEXT) FROM 1 FOR 4));
    
    -- Check if code already exists
    SELECT EXISTS(SELECT 1 FROM profiles WHERE referral_code = new_code) INTO code_exists;
    
    -- Exit loop if code is unique
    EXIT WHEN NOT code_exists;
  END LOOP;
  
  RETURN new_code;
END;
$$ LANGUAGE plpgsql;

-- Create a secure RLS policy
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_tasks ENABLE ROW LEVEL SECURITY;
ALTER TABLE referrals ENABLE ROW LEVEL SECURITY;
ALTER TABLE deposits ENABLE ROW LEVEL SECURITY;
ALTER TABLE withdrawals ENABLE ROW LEVEL SECURITY;
ALTER TABLE activity_log ENABLE ROW LEVEL SECURITY;

-- Profiles policies
CREATE POLICY "Users can view their own profile" 
  ON profiles FOR SELECT 
  USING (auth.uid() = id);

CREATE POLICY "Users can update their own profile" 
  ON profiles FOR UPDATE 
  USING (auth.uid() = id);

-- User tasks policies
CREATE POLICY "Users can view their own tasks" 
  ON user_tasks FOR SELECT 
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own tasks" 
  ON user_tasks FOR INSERT 
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own tasks" 
  ON user_tasks FOR UPDATE 
  USING (auth.uid() = user_id);

-- Referrals policies
CREATE POLICY "Users can view their own referrals" 
  ON referrals FOR SELECT 
  USING (auth.uid() = referrer_id);

-- Deposits policies
CREATE POLICY "Users can view their own deposits" 
  ON deposits FOR SELECT 
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own deposits" 
  ON deposits FOR INSERT 
  WITH CHECK (auth.uid() = user_id);

-- Withdrawals policies
CREATE POLICY "Users can view their own withdrawals" 
  ON withdrawals FOR SELECT 
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own withdrawals" 
  ON withdrawals FOR INSERT 
  WITH CHECK (auth.uid() = user_id);

-- Activity log policies
CREATE POLICY "Users can view their own activity" 
  ON activity_log FOR SELECT 
  USING (auth.uid() = user_id);

-- Allow public access to tasks table
ALTER TABLE tasks ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Anyone can view tasks" 
  ON tasks FOR SELECT 
  USING (true);

-- Create some sample tasks
INSERT INTO tasks (title, description, reward) VALUES
('Complete your profile', 'Fill out all your profile information including a profile picture.', 5.00),
('Share on Facebook', 'Share our platform on your Facebook profile and provide a screenshot.', 10.00),
('Watch a tutorial video', 'Watch our complete tutorial video about how to use the platform.', 3.00),
('Complete a survey', 'Fill out a short survey about your experience with our platform.', 7.50),
('Invite 5 friends', 'Get 5 friends to sign up using your referral link.', 15.00);

-- Create trigger for new user signup
CREATE OR REPLACE FUNCTION public.handle_new_user() 
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles (id, username, full_name, email, referral_code)
  VALUES (
    new.id, 
    new.raw_user_meta_data->>'username', 
    new.raw_user_meta_data->>'full_name', 
    new.email, 
    generate_referral_code(new.id)
  );
  
  -- Log the signup activity
  INSERT INTO activity_log (user_id, activity_type, description)
  VALUES (new.id, 'signup', 'User signed up');
  
  RETURN new;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE PROCEDURE public.handle_new_user();

-- Create trigger for logging user login
CREATE OR REPLACE FUNCTION public.handle_user_login() 
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO activity_log (user_id, activity_type, description)
  VALUES (new.id, 'login', 'User logged in');
  
  RETURN new;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE TRIGGER on_auth_user_login
  AFTER UPDATE OF last_sign_in_at ON auth.users
  FOR EACH ROW EXECUTE PROCEDURE public.handle_user_login();
