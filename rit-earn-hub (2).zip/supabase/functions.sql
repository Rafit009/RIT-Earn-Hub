-- Function to increment a numeric field by 1
CREATE OR REPLACE FUNCTION increment(row_id UUID)
RETURNS INTEGER AS $$
DECLARE
  current_value INTEGER;
BEGIN
  SELECT referral_count INTO current_value FROM profiles WHERE id = row_id;
  RETURN current_value + 1;
END;
$$ LANGUAGE plpgsql;

-- Function to add an amount to a numeric field
CREATE OR REPLACE FUNCTION add_amount(row_id UUID, amount DECIMAL)
RETURNS DECIMAL AS $$
DECLARE
  current_value DECIMAL;
  field_name TEXT := TG_ARGV[0];
BEGIN
  EXECUTE format('SELECT %I FROM profiles WHERE id = $1', field_name)
  INTO current_value
  USING row_id;
  
  RETURN current_value + amount;
END;
$$ LANGUAGE plpgsql;
