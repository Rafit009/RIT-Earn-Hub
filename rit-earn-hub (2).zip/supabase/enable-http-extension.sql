-- Enable the http extension for webhook functionality
CREATE EXTENSION IF NOT EXISTS http;

-- Grant usage to authenticated users
GRANT USAGE ON SCHEMA http TO authenticated;
GRANT EXECUTE ON ALL FUNCTIONS IN SCHEMA http TO authenticated;

-- Create a secure function to send HTTP requests
CREATE OR REPLACE FUNCTION http_post(url text, payload jsonb, content_type text DEFAULT 'application/json')
RETURNS text
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  result text;
BEGIN
  SELECT INTO result
    content::text
  FROM
    http.post(
      url,
      payload::text,
      ARRAY[http.header('Content-Type', content_type)]
    );
  
  RETURN result;
END;
$$;
