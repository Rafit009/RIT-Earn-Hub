-- Add is_active field to profiles table
ALTER TABLE profiles ADD COLUMN is_active BOOLEAN DEFAULT false;

-- Create a function to activate an account
CREATE OR REPLACE FUNCTION activate_account(user_id UUID)
RETURNS void AS $$
BEGIN
  UPDATE profiles
  SET is_active = true
  WHERE id = user_id;
END;
$$ LANGUAGE plpgsql;
