-- Check if the profiles table has the correct schema
DO $$
BEGIN
  -- Check if the full_name column exists in profiles table
  IF NOT EXISTS (
    SELECT 1 
    FROM information_schema.columns 
    WHERE table_name = 'profiles' 
    AND column_name = 'full_name'
  ) THEN
    -- Add full_name column if it doesn't exist
    ALTER TABLE profiles ADD COLUMN full_name TEXT;
    
    -- Update existing profiles with full_name from auth.users metadata if available
    UPDATE profiles p
    SET full_name = (
      SELECT (raw_user_meta_data->>'full_name')
      FROM auth.users
      WHERE id = p.id
    )
    WHERE p.id IN (
      SELECT id FROM auth.users WHERE raw_user_meta_data->>'full_name' IS NOT NULL
    );
  END IF;
END $$;

-- Update the handle_new_user function to properly handle full_name
CREATE OR REPLACE FUNCTION public.handle_new_user() 
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles (
    id, 
    username, 
    full_name, 
    email, 
    referral_code,
    balance,
    is_active,
    referral_count,
    referral_earnings,
    total_earnings,
    completed_tasks,
    created_at,
    updated_at
  )
  VALUES (
    new.id, 
    COALESCE(new.raw_user_meta_data->>'username', 'user_' || SUBSTRING(new.id::text, 1, 8)), 
    COALESCE(new.raw_user_meta_data->>'full_name', ''),
    new.email, 
    'RAFIT' || SUBSTRING(new.id::text, 1, 8) || UPPER(SUBSTRING(MD5(random()::text), 1, 4)),
    0,
    false,
    0,
    0,
    0,
    0,
    NOW(),
    NOW()
  );
  
  -- Log the signup activity
  INSERT INTO activity_log (user_id, activity_type, description)
  VALUES (new.id, 'signup', 'User signed up');
  
  RETURN new;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
