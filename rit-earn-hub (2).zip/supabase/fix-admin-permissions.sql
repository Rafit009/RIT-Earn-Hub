-- Ensure admin users have proper permissions for all tables
CREATE OR REPLACE FUNCTION ensure_admin_permissions()
RETURNS void AS $$
BEGIN
  -- Grant admin users access to all relevant tables
  GRANT SELECT, INSERT, UPDATE, DELETE ON tasks TO authenticated;
  GRANT SELECT, INSERT, UPDATE, DELETE ON deposits TO authenticated;
  GRANT SELECT, INSERT, UPDATE, DELETE ON withdrawals TO authenticated;
  GRANT SELECT, INSERT, UPDATE, DELETE ON profiles TO authenticated;
  GRANT SELECT, INSERT, UPDATE, DELETE ON user_tasks TO authenticated;
  GRANT SELECT, INSERT, UPDATE, DELETE ON referrals TO authenticated;
  GRANT SELECT, INSERT, UPDATE, DELETE ON activity_log TO authenticated;
  
  -- Grant access to sequences
  GRANT USAGE ON ALL SEQUENCES IN SCHEMA public TO authenticated;
  
  RAISE NOTICE 'Admin permissions updated successfully';
END;
$$ LANGUAGE plpgsql;

-- Execute the function
SELECT ensure_admin_permissions();

-- Create a function to check if a user is an admin
CREATE OR REPLACE FUNCTION is_admin(user_id UUID)
RETURNS BOOLEAN AS $$
DECLARE
  is_admin_user BOOLEAN;
BEGIN
  SELECT p.is_admin INTO is_admin_user
  FROM profiles p
  WHERE p.id = user_id;
  
  RETURN COALESCE(is_admin_user, false);
END;
$$ LANGUAGE plpgsql;

-- Grant execute permission on the function
GRANT EXECUTE ON FUNCTION is_admin TO authenticated;

-- Create RLS policy for tasks table that allows admins to manage tasks
DO $$
BEGIN
  -- Drop existing policies if they exist
  DROP POLICY IF EXISTS "Only admins can insert tasks" ON tasks;
  DROP POLICY IF EXISTS "Only admins can update tasks" ON tasks;
  DROP POLICY IF EXISTS "Only admins can delete tasks" ON tasks;
  
  -- Create new policies
  CREATE POLICY "Only admins can insert tasks" 
    ON tasks FOR INSERT 
    WITH CHECK (is_admin(auth.uid()));
  
  CREATE POLICY "Only admins can update tasks" 
    ON tasks FOR UPDATE 
    USING (is_admin(auth.uid()));
  
  CREATE POLICY "Only admins can delete tasks" 
    ON tasks FOR DELETE 
    USING (is_admin(auth.uid()));
    
  RAISE NOTICE 'Task management policies updated successfully';
END $$;
