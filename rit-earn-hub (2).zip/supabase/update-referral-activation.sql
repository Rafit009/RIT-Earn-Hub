-- Update the function that handles account activation to ensure referral counts are accurate
CREATE OR REPLACE FUNCTION update_referral_status()
RETURNS TRIGGER AS $$
BEGIN
  -- If account is being activated
  IF NEW.is_active = true AND OLD.is_active = false THEN
    -- Update any referrals where this user is the referred user
    UPDATE referrals
    SET status = 'active'
    WHERE referred_id = NEW.id AND status = 'pending';
    
    -- If this user was referred, give the referrer their bonus
    IF NEW.referred_by IS NOT NULL THEN
      -- Add the signup bonus to the referrer's balance and earnings
      UPDATE profiles
      SET 
        balance = balance + 10.0,
        referral_earnings = referral_earnings + 10.0,
        total_earnings = total_earnings + 10.0
      WHERE id = NEW.referred_by;
      
      -- Log the activity
      INSERT INTO activity_log (
        user_id, 
        activity_type, 
        description, 
        metadata
      )
      VALUES (
        NEW.referred_by,
        'referral_bonus',
        'Received bonus for referral activation',
        jsonb_build_object(
          'referred_id', NEW.id,
          'referred_username', NEW.username,
          'bonus_amount', 10.0
        )
      );
    END IF;
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Make sure the trigger exists
DROP TRIGGER IF EXISTS on_account_activation ON profiles;
CREATE TRIGGER on_account_activation
  AFTER UPDATE OF is_active ON profiles
  FOR EACH ROW
  WHEN (OLD.is_active = false AND NEW.is_active = true)
  EXECUTE FUNCTION update_referral_status();
