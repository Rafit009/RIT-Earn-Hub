-- Check if activity_log table exists, if not create it
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT FROM information_schema.tables 
    WHERE table_schema = 'public' 
    AND table_name = 'activity_log'
  ) THEN
    CREATE TABLE activity_log (
      id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
      user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
      activity_type TEXT NOT NULL,
      description TEXT,
      metadata JSONB,
      created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
    );

    -- Add RLS policy for activity_log
    ALTER TABLE activity_log ENABLE ROW LEVEL SECURITY;
    
    CREATE POLICY "Users can view their own activity" 
      ON activity_log FOR SELECT 
      USING (auth.uid() = user_id);
    
    CREATE POLICY "Users can insert their own activity" 
      ON activity_log FOR INSERT 
      WITH CHECK (auth.uid() = user_id);
  END IF;
END $$;
