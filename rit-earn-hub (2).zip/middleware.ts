import { NextResponse } from "next/server"
import type { NextRequest } from "next/server"
import { createMiddlewareClient } from "@supabase/auth-helpers-nextjs"

export async function middleware(req: NextRequest) {
  const res = NextResponse.next()
  const supabase = createMiddlewareClient({ req, res })

  // Check if user is authenticated
  const {
    data: { session },
  } = await supabase.auth.getSession()

  // Skip maintenance check for admin routes and API routes
  const path = req.nextUrl.pathname
  if (path.startsWith("/admin") || path.startsWith("/api/admin") || path === "/admin-login") {
    return res
  }

  try {
    // Check if maintenance mode is enabled
    const { data: maintenanceData } = await supabase
      .from("settings")
      .select("value")
      .eq("key", "maintenance_mode")
      .single()

    const maintenanceMode = maintenanceData?.value === true || maintenanceData?.value === "true"

    if (maintenanceMode) {
      // If in maintenance mode, check if user is admin
      if (session) {
        const { data: profile } = await supabase.from("profiles").select("is_admin").eq("id", session.user.id).single()

        // Allow access if user is admin
        if (profile?.is_admin) {
          return res
        }
      }

      // Redirect to maintenance page
      return NextResponse.redirect(new URL("/maintenance", req.url))
    }
  } catch (error) {
    console.error("Error checking maintenance mode:", error)
  }

  return res
}

export const config = {
  matcher: ["/((?!_next/static|_next/image|favicon.ico|images|maintenance).*)"],
}
