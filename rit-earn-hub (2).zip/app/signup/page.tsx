"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import AuthLayout from "@/components/auth-layout"

export default function SignUp() {
  const [fullName, setFullName] = useState("")
  const [username, setUsername] = useState("")
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [confirmPassword, setConfirmPassword] = useState("")
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [referralCode, setReferralCode] = useState("")
  const router = useRouter()
  const searchParams = useSearchParams()

  useEffect(() => {
    // Check for referral code in URL
    const refCode = searchParams.get("ref")
    if (refCode) {
      setReferralCode(refCode)
    }
  }, [searchParams])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError(null)

    // Validate passwords match
    if (password !== confirmPassword) {
      setError("Passwords do not match")
      setLoading(false)
      return
    }

    // Validate username
    if (username.includes(" ")) {
      setError("Username cannot contain spaces")
      setLoading(false)
      return
    }

    try {
      // Call the server-side signup API endpoint
      const response = await fetch("/api/auth/signup", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          email,
          password,
          name: fullName,
          username: username.toLowerCase(),
          referralCode,
        }),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || "Failed to create account")
      }

      // Show success message and redirect to login
      const successMessage = referralCode
        ? "Account created successfully! You've received a 10৳ signup bonus for using a referral code."
        : "Account created successfully! Please check your email to verify your account."

      router.push(`/login?message=${encodeURIComponent(successMessage)}`)
    } catch (error: any) {
      console.error("Signup error:", error)
      setError(error.message || "Failed to create account")
    } finally {
      setLoading(false)
    }
  }

  return (
    <AuthLayout
      title="Create your account"
      subtitle="Join our platform and start earning today"
      alternateLink={{
        text: "Already have an account?",
        href: "/login",
        label: "Sign in",
      }}
    >
      <form className="space-y-6" onSubmit={handleSubmit}>
        {error && <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-md">{error}</div>}

        <div>
          <label htmlFor="fullName" className="block text-sm font-medium text-gray-700">
            Full Name
          </label>
          <input
            id="fullName"
            name="fullName"
            type="text"
            required
            className="mt-1 block w-full rounded-md border border-gray-300 px-3 py-2 shadow-sm focus:border-[#5E4FDB] focus:outline-none focus:ring-[#5E4FDB]"
            value={fullName}
            onChange={(e) => setFullName(e.target.value)}
          />
        </div>

        <div>
          <label htmlFor="username" className="block text-sm font-medium text-gray-700">
            Username
          </label>
          <input
            id="username"
            name="username"
            type="text"
            required
            className="mt-1 block w-full rounded-md border border-gray-300 px-3 py-2 shadow-sm focus:border-[#5E4FDB] focus:outline-none focus:ring-[#5E4FDB]"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
          />
          <p className="text-xs text-gray-500 mt-1">Username cannot contain spaces.</p>
        </div>

        <div>
          <label htmlFor="email" className="block text-sm font-medium text-gray-700">
            Email address
          </label>
          <input
            id="email"
            name="email"
            type="email"
            required
            className="mt-1 block w-full rounded-md border border-gray-300 px-3 py-2 shadow-sm focus:border-[#5E4FDB] focus:outline-none focus:ring-[#5E4FDB]"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
        </div>

        <div>
          <label htmlFor="password" className="block text-sm font-medium text-gray-700">
            Password
          </label>
          <input
            id="password"
            name="password"
            type="password"
            required
            className="mt-1 block w-full rounded-md border border-gray-300 px-3 py-2 shadow-sm focus:border-[#5E4FDB] focus:outline-none focus:ring-[#5E4FDB]"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </div>

        <div>
          <label htmlFor="confirmPassword" className="block text-sm font-medium text-gray-700">
            Confirm Password
          </label>
          <input
            id="confirmPassword"
            name="confirmPassword"
            type="password"
            required
            className="mt-1 block w-full rounded-md border border-gray-300 px-3 py-2 shadow-sm focus:border-[#5E4FDB] focus:outline-none focus:ring-[#5E4FDB]"
            value={confirmPassword}
            onChange={(e) => setConfirmPassword(e.target.value)}
          />
        </div>

        <div>
          <label htmlFor="referralCode" className="block text-sm font-medium text-gray-700">
            Referral Code (Optional)
          </label>
          <input
            id="referralCode"
            name="referralCode"
            type="text"
            className="mt-1 block w-full rounded-md border border-gray-300 px-3 py-2 shadow-sm focus:border-[#5E4FDB] focus:outline-none focus:ring-[#5E4FDB]"
            placeholder="Enter referral code if you have one"
            value={referralCode}
            onChange={(e) => setReferralCode(e.target.value)}
          />
          {referralCode && (
            <p className="text-xs text-green-600 mt-1">
              You'll receive a 10৳ signup bonus when you register with this referral code!
            </p>
          )}
        </div>

        <div>
          <button
            type="submit"
            disabled={loading}
            className="flex w-full justify-center rounded-md border border-transparent bg-[#5E4FDB] py-2 px-4 text-sm font-medium text-white shadow-sm hover:bg-[#4E3FCB] focus:outline-none focus:ring-2 focus:ring-[#5E4FDB] focus:ring-offset-2 disabled:opacity-75"
          >
            {loading ? "Creating account..." : "Create account"}
          </button>
        </div>
      </form>
    </AuthLayout>
  )
}
