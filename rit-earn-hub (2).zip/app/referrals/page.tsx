"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { supabase } from "@/lib/supabase"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Users, Copy, Share2, Award, DollarSign } from "lucide-react"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
import { LoadingSpinner } from "@/components/loading-spinner"

interface Referral {
  id: string
  referred_id: string
  referred_username: string
  referred_fullname: string
  referred_email: string
  created_at: string
  reward: number
  status: string
}

interface ReferralStats {
  total_count: number
  total_earnings: number
  active_referrals: number
  pending_referrals: number
  referral_code: string
  username: string
}

export default function Referrals() {
  const router = useRouter()
  const [referrals, setReferrals] = useState<Referral[]>([])
  const [loading, setLoading] = useState(true)
  const [username, setUsername] = useState("")
  const [referralLink, setReferralLink] = useState("")
  const [stats, setStats] = useState<ReferralStats>({
    total_count: 0,
    total_earnings: 0,
    active_referrals: 0,
    pending_referrals: 0,
    referral_code: "",
    username: "",
  })
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const checkUser = async () => {
      try {
        const {
          data: { session },
        } = await supabase.auth.getSession()

        if (!session) {
          router.push("/login")
          return
        }

        // Use the API route to fetch referral data
        const response = await fetch(`/api/user/referrals?userId=${session.user.id}`)

        if (!response.ok) {
          const errorData = await response.json()
          throw new Error(errorData.error || "Failed to fetch referral data")
        }

        const data = await response.json()

        setUsername(data.stats.username || "")
        setReferralLink(
          `${typeof window !== "undefined" ? window.location.origin : ""}/signup?ref=${data.stats.username}`,
        )
        setReferrals(data.referrals || [])
        setStats(
          data.stats || {
            total_count: 0,
            total_earnings: 0,
            active_referrals: 0,
            pending_referrals: 0,
            referral_code: "",
            username: "",
          },
        )

        setLoading(false)
      } catch (error: any) {
        console.error("Error in referrals page:", error)
        setError(error.message || "An error occurred while fetching referral data")
        setLoading(false)
      }
    }

    checkUser()
  }, [router])

  const copyReferralLink = () => {
    navigator.clipboard.writeText(referralLink)
    alert("Referral link copied to clipboard!")
  }

  const shareReferralLink = () => {
    if (navigator.share) {
      navigator
        .share({
          title: "Join RIT Earn Hub",
          text: "Sign up using my referral link and earn rewards!",
          url: referralLink,
        })
        .catch((error) => console.log("Error sharing", error))
    } else {
      copyReferralLink()
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <LoadingSpinner size="lg" />
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8 animate-fade-in">
        <h1 className="text-3xl font-bold text-gradient">Referrals</h1>
        <p className="text-muted-foreground">Invite friends and earn rewards</p>
      </div>

      {error && (
        <Alert variant="destructive" className="mb-6 animate-fade-in">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <Card className="md:col-span-2 hover-lift animate-slide-in-left">
          <CardHeader>
            <CardTitle className="text-gradient">Your Referral Link</CardTitle>
            <CardDescription>Share this link with friends to earn rewards</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center space-x-2 mb-4">
              <input
                type="text"
                readOnly
                value={referralLink}
                className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
              />
              <Button onClick={copyReferralLink} size="icon" className="hover-scale">
                <Copy className="h-4 w-4" />
              </Button>
            </div>
            <Button onClick={shareReferralLink} className="w-full hover-scale" variant="outline">
              <Share2 className="h-4 w-4 mr-2" />
              Share Referral Link
            </Button>

            <div className="mt-6 p-4 bg-blue-50 border border-blue-200 rounded-md animate-pulse-subtle">
              <h3 className="text-sm font-medium text-blue-800 mb-2">How Referrals Work:</h3>
              <ul className="text-xs text-blue-700 space-y-1 list-disc list-inside">
                <li>Share your unique referral link with friends</li>
                <li>When they sign up using your link, they get 10 Taka bonus</li>
                <li>You earn 5% bonus on every task they complete</li>
                <li>The more active referrals you have, the more you earn!</li>
              </ul>
            </div>
          </CardContent>
        </Card>

        <Card className="hover-lift animate-slide-in-right">
          <CardHeader>
            <CardTitle className="text-gradient">Referral Stats</CardTitle>
            <CardDescription>Your referral performance</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground flex items-center">
                  <Users className="h-4 w-4 mr-2 text-primary" />
                  Total Referrals
                </span>
                <span className="font-bold text-gradient">{stats.total_count}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground flex items-center">
                  <Award className="h-4 w-4 mr-2 text-green-500" />
                  Active Referrals
                </span>
                <span className="font-bold text-gradient-success">{stats.active_referrals}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground flex items-center">
                  <Users className="h-4 w-4 mr-2 text-yellow-500" />
                  Pending Activation
                </span>
                <span className="font-bold text-gradient-warning">{stats.pending_referrals}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground flex items-center">
                  <DollarSign className="h-4 w-4 mr-2 text-primary" />
                  Total Earnings
                </span>
                <span className="font-bold text-gradient">{stats.total_earnings.toFixed(2)} Taka</span>
              </div>
              <div className="mt-4 pt-4 border-t border-border">
                <div className="text-xs text-muted-foreground">
                  <p className="mb-1">Referral Rewards:</p>
                  <p>• 10 Taka signup bonus for your friend</p>
                  <p>• 5% of each task they complete</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="hover-lift animate-slide-up">
        <CardHeader>
          <CardTitle className="text-gradient">Your Referrals</CardTitle>
          <CardDescription>People who signed up using your referral link</CardDescription>
        </CardHeader>
        <CardContent>
          {referrals.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Username</TableHead>
                  <TableHead>Name</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Date Joined</TableHead>
                  <TableHead className="text-right">Earnings</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {referrals.map((referral, index) => (
                  <TableRow key={referral.id} className={`animate-fade-in delay-${(index % 5) * 100}`}>
                    <TableCell className="font-medium">@{referral.referred_username}</TableCell>
                    <TableCell>{referral.referred_fullname}</TableCell>
                    <TableCell>
                      {referral.status === "active" ? (
                        <Badge className="bg-green-500">Active</Badge>
                      ) : (
                        <Badge className="bg-yellow-500">Pending</Badge>
                      )}
                    </TableCell>
                    <TableCell>{new Date(referral.created_at).toLocaleDateString()}</TableCell>
                    <TableCell className="text-right font-semibold text-gradient">
                      {referral.reward.toFixed(2)} Taka
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <div className="text-center py-8 animate-fade-in">
              <Users className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
              <h3 className="text-xl font-semibold mb-2">No referrals yet</h3>
              <p className="text-muted-foreground mb-4">Share your referral link to start earning rewards</p>
              <Button onClick={shareReferralLink} variant="outline" className="hover-scale">
                <Share2 className="h-4 w-4 mr-2" />
                Share Referral Link
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
