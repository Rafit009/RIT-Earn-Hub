"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { supabase } from "@/lib/supabase"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { DollarSign, AlertCircle } from "lucide-react"
import Link from "next/link"
import { useSettings } from "@/contexts/settings-context"

interface UserProfile {
  id: string
  balance: number
  is_active: boolean
}

interface PaymentMethod {
  id: string
  name: string
  display_name: string
  account_number: string
  instructions: string
  is_active: boolean
  for_deposit: boolean
  for_withdrawal: boolean
}

// Update the sendTelegramNotification function at the top of the file
async function sendTelegramNotification(transaction) {
  try {
    const response = await fetch("/api/telegram-notify", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        table: "withdrawals", // Explicitly specify this is from the withdrawals table
        record: {
          new: transaction,
        },
      }),
    })

    const data = await response.json()
    console.log("Telegram notification response:", data)
    return data.success
  } catch (error) {
    console.error("Error sending Telegram notification:", error)
    return false
  }
}

export default function Withdraw() {
  const router = useRouter()
  const [loading, setLoading] = useState(true)
  const [submitting, setSubmitting] = useState(false)
  const [amount, setAmount] = useState("")
  const [paymentMethod, setPaymentMethod] = useState("nagad") // Changed default to nagad
  const [mobileNumber, setMobileNumber] = useState("")
  const [message, setMessage] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [userId, setUserId] = useState<string | null>(null)
  const [profile, setProfile] = useState<UserProfile | null>(null)
  const [paymentMethods, setPaymentMethods] = useState<PaymentMethod[]>([])
  const { getSetting } = useSettings()

  useEffect(() => {
    const checkUser = async () => {
      const {
        data: { session },
      } = await supabase.auth.getSession()

      if (!session) {
        router.push("/login")
        return
      }

      setUserId(session.user.id)

      // Get user profile
      const { data: profileData, error } = await supabase
        .from("profiles")
        .select("id, balance, is_active")
        .eq("id", session.user.id)
        .single()

      if (error) {
        console.error("Error fetching profile:", error)
        return
      }

      setProfile(profileData)

      // Fetch payment methods
      const { data: methodsData, error: methodsError } = await supabase
        .from("payment_methods")
        .select("*")
        .eq("is_active", true)
        .eq("for_withdrawal", true)
        .order("display_name")

      if (methodsError) {
        console.error("Error fetching payment methods:", methodsError)
      } else {
        setPaymentMethods(methodsData || [])

        // Set default payment method if available
        if (methodsData && methodsData.length > 0) {
          setPaymentMethod(methodsData[0].name)
        }
      }

      setLoading(false)
    }

    checkUser()
  }, [router])

  // Then modify the handleSubmit function to include this call:
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!userId || !profile) return

    // Check if account is active
    if (!profile.is_active) {
      setError("Your account is not activated yet. You need to deposit at least 50৳ to activate your account.")
      return
    }

    setSubmitting(true)
    setMessage(null)
    setError(null)

    try {
      // Validate amount
      const withdrawAmount = Number.parseFloat(amount)
      if (isNaN(withdrawAmount) || withdrawAmount <= 0) {
        throw new Error("Please enter a valid amount")
      }

      // Check if user has enough balance
      if (withdrawAmount > profile.balance) {
        throw new Error("Insufficient balance")
      }

      // Minimum withdrawal amount
      const minWithdrawal = getSetting("min_withdrawal", 50)
      if (withdrawAmount < minWithdrawal) {
        throw new Error(`Minimum withdrawal amount is ${minWithdrawal}৳`)
      }

      // Validate mobile number
      if (!mobileNumber.trim()) {
        throw new Error("Please enter a mobile number")
      }

      // Create withdrawal request with all required fields
      const withdrawalData = {
        user_id: userId,
        amount: withdrawAmount,
        method: paymentMethod,
        mobile_number: mobileNumber,
        status: "pending",
        transaction_id: "PENDING", // Add a placeholder transaction ID
        created_at: new Date().toISOString(),
      }

      // First, update user balance (deduct the withdrawal amount)
      const { error: balanceError } = await supabase
        .from("profiles")
        .update({ balance: profile.balance - withdrawAmount })
        .eq("id", userId)

      if (balanceError) throw balanceError

      // Then create the withdrawal request
      const { error: withdrawalError, data: withdrawalResult } = await supabase
        .from("withdrawals")
        .insert([withdrawalData])
        .select()

      if (withdrawalError) {
        // If there was an error creating the withdrawal, revert the balance change
        await supabase.from("profiles").update({ balance: profile.balance }).eq("id", userId)

        throw new Error(`Failed to submit withdrawal request: ${withdrawalError.message}`)
      }

      // Send Telegram notification directly
      if (withdrawalResult && withdrawalResult.length > 0) {
        await sendTelegramNotification({
          ...withdrawalResult[0],
          // Add an explicit flag to identify this as a withdrawal
          is_withdrawal: true,
        })
      }

      // Log the activity
      await supabase.from("activity_log").insert([
        {
          user_id: userId,
          activity_type: "withdrawal",
          description: `Withdrawal request of ${withdrawAmount}৳ submitted`,
          metadata: {
            amount: withdrawAmount,
            method: paymentMethod,
            mobile_number: mobileNumber,
          },
        },
      ])

      // Update local state
      setProfile({
        ...profile,
        balance: profile.balance - withdrawAmount,
      })

      setMessage(
        "Withdrawal request submitted successfully! We'll process it shortly. Our admin has been notified and will review your request.",
      )
      setAmount("")
      setMobileNumber("")
    } catch (error: any) {
      setError(error.message || "An error occurred while submitting your withdrawal request")
    } finally {
      setSubmitting(false)
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold">Withdraw Funds</h1>
        <p className="text-muted-foreground">Withdraw your earnings</p>
      </div>

      {!profile?.is_active && (
        <Alert className="mb-6 bg-yellow-50 border-yellow-200">
          <AlertCircle className="h-4 w-4 text-yellow-600" />
          <AlertDescription className="text-yellow-700">
            Your account is not activated yet. You need to deposit at least 50৳ to activate your account.
            <Link href="/deposit" className="ml-2 text-primary underline">
              Deposit now
            </Link>
          </AlertDescription>
        </Alert>
      )}

      {message && (
        <Alert className="mb-6">
          <AlertDescription>{message}</AlertDescription>
        </Alert>
      )}

      {error && (
        <Alert variant="destructive" className="mb-6">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Withdrawal Information</CardTitle>
            <CardDescription>Enter your withdrawal details</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="bg-muted p-4 rounded-md mb-4">
              <p className="font-medium">
                Available Balance: <span className="font-bold">{profile?.balance.toFixed(2)}৳</span>
              </p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="amount">Amount (৳)</Label>
                <div className="flex">
                  <div className="bg-muted p-2 rounded-l-md">
                    <DollarSign className="h-5 w-5 text-muted-foreground" />
                  </div>
                  <Input
                    id="amount"
                    type="number"
                    placeholder="500"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    className="rounded-l-none"
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label>Payment Method</Label>
                <RadioGroup value={paymentMethod} onValueChange={setPaymentMethod} className="flex flex-col space-y-1">
                  {paymentMethods.length > 0 ? (
                    paymentMethods.map((method) => (
                      <div key={method.id} className="flex items-center space-x-2">
                        <RadioGroupItem value={method.name} id={`${method.name}-withdraw`} />
                        <Label htmlFor={`${method.name}-withdraw`} className="cursor-pointer">
                          {method.display_name}
                        </Label>
                      </div>
                    ))
                  ) : (
                    <>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="nagad" id="nagad-withdraw" />
                        <Label htmlFor="nagad-withdraw" className="cursor-pointer">
                          Nagad
                        </Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="bkash" id="bkash-withdraw" />
                        <Label htmlFor="bkash-withdraw" className="cursor-pointer">
                          bKash
                        </Label>
                      </div>
                    </>
                  )}
                </RadioGroup>
              </div>

              <div className="space-y-2">
                <Label htmlFor="mobileNumber">Your Mobile Number</Label>
                <Input
                  id="mobileNumber"
                  placeholder="01XXXXXXXXX"
                  value={mobileNumber}
                  onChange={(e) => setMobileNumber(e.target.value)}
                  required
                />
                <p className="text-xs text-muted-foreground">We'll send the money to this number</p>
              </div>

              <Button
                type="submit"
                className="w-full"
                disabled={submitting || (profile?.balance || 0) <= 0 || !profile?.is_active}
              >
                {submitting ? "Processing..." : "Submit Withdrawal"}
              </Button>
            </form>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Withdrawal Policy</CardTitle>
            <CardDescription>Important information about withdrawals</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-4">
              <div className="space-y-2">
                <h3 className="font-semibold">English Instructions:</h3>
                <ul className="list-disc list-inside space-y-1 text-sm">
                  <li>Minimum withdrawal amount is {getSetting("min_withdrawal", 50)}৳</li>
                  <li>Withdrawals are processed within 24-48 hours</li>
                  <li>Make sure to enter the correct mobile number</li>
                  <li>Withdrawal fees may apply depending on the payment method</li>
                  <li>Your account must be activated to withdraw funds</li>
                </ul>
              </div>

              <div className="space-y-2">
                <h3 className="font-semibold">বাংলা নির্দেশনা:</h3>
                <ul className="list-disc list-inside space-y-1 text-sm">
                  <li>সর্বনিম্ন উত্তোলনের পরিমাণ {getSetting("min_withdrawal", 50)}৳</li>
                  <li>উত্তোলন ২৪-৪৮ ঘন্টার মধ্যে প্রক্রিয়া করা হয়</li>
                  <li>সঠিক মোবাইল নম্বর লিখতে ভুলবেন না</li>
                  <li>পেমেন্ট পদ্ধতির উপর নির্ভর করে উত্তোলন ফি প্রযোজ্য হতে পারে</li>
                  <li>অর্থ উত্তোলন করতে আপনার অ্যাকাউন্ট অবশ্যই সক্রিয় থাকতে হবে</li>
                </ul>
              </div>
            </div>

            <div className="space-y-2">
              <h3 className="font-semibold">Processing Times / প্রক্রিয়াকরণের সময়:</h3>
              <ul className="list-disc list-inside space-y-1 text-sm">
                {paymentMethods.length > 0 ? (
                  paymentMethods.map((method) => (
                    <li key={method.id}>
                      <span className="font-medium">{method.display_name}:</span> 24-48 hours / ২৪-৪৮ ঘন্টা
                    </li>
                  ))
                ) : (
                  <>
                    <li>
                      <span className="font-medium">Nagad / নগদ:</span> 24 hours / ২৪ ঘন্টা
                    </li>
                    <li>
                      <span className="font-medium">bKash / বিকাশ:</span> 24-48 hours / ২৪-৪৮ ঘন্টা
                    </li>
                  </>
                )}
              </ul>

              {paymentMethods
                .filter((m) => m.name === paymentMethod && m.instructions)
                .map((method) => (
                  <div key={method.id} className="bg-muted p-4 rounded-md mt-2">
                    <p className="text-sm">{method.instructions}</p>
                  </div>
                ))}
            </div>

            <div className="bg-muted p-4 rounded-md mt-4">
              <p className="text-sm font-medium">Need Help? / সাহায্য দরকার?</p>
              <p className="text-sm mt-2">
                If you have any issues with your withdrawal, please contact our support team at support@ritearnhub.com
              </p>
              <p className="text-sm mt-1">
                উত্তোলন সম্পর্কিত কোন সমস্যা হলে, অনুগ্রহ করে আমাদের সাপোর্ট টিমের সাথে যোগাযোগ করুন: support@ritearnhub.com
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
