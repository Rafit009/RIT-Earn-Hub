"use client"

import { AlertDescription } from "@/components/ui/alert"

import { Alert } from "@/components/ui/alert"

import { Button } from "@/components/ui/button"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { supabase } from "@/lib/supabase"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Activity, AlertCircle, CheckCircle, Clock, XCircle, DollarSign } from "lucide-react"
import { LoadingSpinner } from "@/components/loading-spinner"
import Link from "next/link"

interface ActivityLog {
  id: string
  activity_type: string
  description: string
  created_at: string
  metadata: any
}

export default function ActivityPage() {
  const router = useRouter()
  const [loading, setLoading] = useState(true)
  const [activityLogs, setActivityLogs] = useState<ActivityLog[]>([])
  const [userId, setUserId] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const checkUser = async () => {
      try {
        const {
          data: { session },
        } = await supabase.auth.getSession()

        if (!session) {
          router.push("/login")
          return
        }

        setUserId(session.user.id)

        // Fetch activity logs
        const { data: logsData, error: logsError } = await supabase
          .from("activity_log")
          .select("*")
          .eq("user_id", session.user.id)
          .order("created_at", { ascending: false })
          .limit(100)

        if (logsError) {
          console.error("Error fetching activity logs:", logsError)
          setError("Failed to load activity logs. Please try again.")
        } else {
          setActivityLogs(logsData || [])
        }
      } catch (error: any) {
        console.error("Error in activity page:", error)
        setError(error.message || "An error occurred while loading activity logs")
      } finally {
        setLoading(false)
      }
    }

    checkUser()
  }, [router])

  const formatActivityType = (type: string) => {
    switch (type) {
      case "signup":
        return "Sign Up"
      case "login":
        return "Login"
      case "profile_update":
        return "Profile Update"
      case "password_update":
        return "Password Change"
      case "task_completed":
        return "Task Completed"
      case "referral_signup":
        return "Referral Sign Up"
      case "referred_signup":
        return "Signed Up via Referral"
      case "referral_reward":
        return "Referral Reward"
      case "deposit":
        return "Deposit"
      case "withdrawal":
        return "Withdrawal"
      case "deposit_approved":
        return "Deposit Approved"
      case "deposit_declined":
        return "Deposit Declined"
      case "withdrawal_approved":
        return "Withdrawal Approved"
      case "withdrawal_declined":
        return "Withdrawal Declined"
      case "voucher_redemption":
        return "Voucher Redeemed"
      default:
        return type.replace(/_/g, " ").replace(/\b\w/g, (l) => l.toUpperCase())
    }
  }

  const getActivityIcon = (type: string) => {
    if (type.includes("approved")) {
      return <CheckCircle className="h-4 w-4 text-green-500" />
    } else if (type.includes("declined")) {
      return <XCircle className="h-4 w-4 text-red-500" />
    } else if (type.includes("pending")) {
      return <Clock className="h-4 w-4 text-yellow-500" />
    } else if (type.includes("deposit") || type.includes("withdrawal")) {
      return <DollarSign className="h-4 w-4 text-primary" />
    } else {
      return <Activity className="h-4 w-4 text-primary" />
    }
  }

  const getActivityBadge = (type: string) => {
    if (type.includes("approved")) {
      return <Badge className="bg-green-500">Approved</Badge>
    } else if (type.includes("declined")) {
      return <Badge className="bg-red-500">Declined</Badge>
    } else if (type.includes("pending")) {
      return <Badge className="bg-yellow-500">Pending</Badge>
    } else if (type.includes("deposit")) {
      return <Badge className="bg-blue-500">Deposit</Badge>
    } else if (type.includes("withdrawal")) {
      return <Badge className="bg-purple-500">Withdrawal</Badge>
    } else if (type.includes("referral")) {
      return <Badge className="bg-indigo-500">Referral</Badge>
    } else if (type.includes("task")) {
      return <Badge className="bg-amber-500">Task</Badge>
    } else {
      return <Badge>Activity</Badge>
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <LoadingSpinner size="lg" />
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8 animate-fade-in">
        <h1 className="text-3xl font-bold text-gradient">Activity Log</h1>
        <p className="text-muted-foreground">Track your account activity and transaction status</p>
      </div>

      {error && (
        <Alert variant="destructive" className="mb-6 animate-fade-in">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      <Card className="hover-lift animate-slide-up">
        <CardHeader>
          <CardTitle className="text-gradient">Recent Activity</CardTitle>
          <CardDescription>Your recent account activity and notifications</CardDescription>
        </CardHeader>
        <CardContent>
          {activityLogs.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Date</TableHead>
                  <TableHead>Activity</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Details</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {activityLogs.map((log) => (
                  <TableRow
                    key={log.id}
                    className={
                      log.activity_type.includes("declined")
                        ? "bg-red-50"
                        : log.activity_type.includes("approved")
                          ? "bg-green-50"
                          : ""
                    }
                  >
                    <TableCell>{new Date(log.created_at).toLocaleString()}</TableCell>
                    <TableCell>
                      <div className="flex items-center">
                        {getActivityIcon(log.activity_type)}
                        <span className="ml-2">{formatActivityType(log.activity_type)}</span>
                      </div>
                    </TableCell>
                    <TableCell>{getActivityBadge(log.activity_type)}</TableCell>
                    <TableCell>{log.description}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <div className="text-center py-8 animate-fade-in">
              <Activity className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
              <h3 className="text-xl font-semibold mb-2">No activity yet</h3>
              <p className="text-muted-foreground">Your account activity will be shown here</p>
            </div>
          )}
        </CardContent>
      </Card>

      <div className="mt-6 bg-blue-50 border border-blue-200 rounded-lg p-4 animate-slide-up delay-200">
        <div className="flex items-start">
          <AlertCircle className="h-5 w-5 text-blue-600 mt-0.5 mr-3" />
          <div>
            <h3 className="font-medium text-blue-800">Transaction Notifications</h3>
            <p className="text-sm text-blue-700 mt-1">
              When you make a deposit or withdrawal request, our admin team will review it promptly. You'll receive a
              notification here when your transaction is approved or declined.
            </p>
            <div className="mt-3 flex flex-wrap gap-2">
              <Link href="/deposit">
                <Button variant="outline" size="sm" className="bg-white hover:bg-blue-50">
                  Make a Deposit
                </Button>
              </Link>
              <Link href="/withdraw">
                <Button variant="outline" size="sm" className="bg-white hover:bg-blue-50">
                  Request Withdrawal
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
