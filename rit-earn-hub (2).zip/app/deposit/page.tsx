"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { supabase } from "@/lib/supabase"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { DollarSign, Gift, AlertCircle, ExternalLink } from "lucide-react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { LoadingSpinner } from "@/components/loading-spinner"
import { useSettings } from "@/contexts/settings-context"

// Add this interface after the other interfaces
interface PaymentMethod {
  id: string
  name: string
  display_name: string
  account_number: string
  instructions: string
  is_active: boolean
  for_deposit: boolean
  for_withdrawal: boolean
}

// Add this function at the top of the file, after the imports
async function sendTelegramNotification(transaction) {
  try {
    const response = await fetch("/api/telegram-notify", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        table: "deposits", // Explicitly specify this is from the deposits table
        record: {
          new: transaction,
        },
      }),
    })

    const data = await response.json()
    console.log("Telegram notification response:", data)
    return data.success
  } catch (error) {
    console.error("Error sending Telegram notification:", error)
    return false
  }
}

export default function Deposit() {
  const router = useRouter()
  const [loading, setLoading] = useState(true)
  const [submitting, setSubmitting] = useState(false)
  const [amount, setAmount] = useState("")
  const [paymentMethod, setPaymentMethod] = useState("nagad") // Changed default to nagad
  const [transactionId, setTransactionId] = useState("")
  const [mobileNumber, setMobileNumber] = useState("")
  const [message, setMessage] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [userId, setUserId] = useState<string | null>(null)
  const [isActive, setIsActive] = useState(false)
  const [voucherCode, setVoucherCode] = useState("")
  const [applyingVoucher, setApplyingVoucher] = useState(false)
  const [voucherMessage, setVoucherMessage] = useState<string | null>(null)
  const [voucherError, setVoucherError] = useState<string | null>(null)
  const [balance, setBalance] = useState(0)
  const [wasReferred, setWasReferred] = useState(false)
  const [referrerUsername, setReferrerUsername] = useState<string | null>(null)
  const [usedVouchers, setUsedVouchers] = useState<string[]>([])
  const [validatingVoucher, setValidatingVoucher] = useState(false)
  const [voucherAmount, setVoucherAmount] = useState<number | null>(null)

  // Add this state after the other state declarations in the component
  const [paymentMethods, setPaymentMethods] = useState<PaymentMethod[]>([])
  const { getSetting } = useSettings()

  useEffect(() => {
    const checkUser = async () => {
      const {
        data: { session },
      } = await supabase.auth.getSession()

      if (!session) {
        router.push("/login")
        return
      }

      setUserId(session.user.id)

      try {
        // First check if the used_vouchers column exists
        const { data: columnExists } = await supabase.rpc("check_column_exists", {
          table_name: "profiles",
          column_name: "used_vouchers",
        })

        // Select appropriate columns based on whether used_vouchers exists
        const selectColumns =
          columnExists && columnExists.exists
            ? "is_active, balance, referred_by, used_vouchers"
            : "is_active, balance, referred_by"

        // Get user profile to check if account is active
        const { data: profileData, error } = await supabase
          .from("profiles")
          .select(selectColumns)
          .eq("id", session.user.id)
          .single()

        if (error) {
          console.error("Error fetching profile:", error)
          return
        }

        setIsActive(profileData.is_active || false)
        setBalance(profileData.balance || 0)

        // Handle used_vouchers safely
        if (columnExists && columnExists.exists) {
          setUsedVouchers(profileData.used_vouchers || [])
        } else {
          setUsedVouchers([])
        }

        // Check if user was referred
        if (profileData.referred_by) {
          setWasReferred(true)

          // Get referrer's username
          const { data: referrerData } = await supabase
            .from("profiles")
            .select("username")
            .eq("id", profileData.referred_by)
            .single()

          if (referrerData) {
            setReferrerUsername(referrerData.username)
          }
        }

        // Fetch payment methods
        const { data: methodsData, error: methodsError } = await supabase
          .from("payment_methods")
          .select("*")
          .eq("is_active", true)
          .eq("for_deposit", true)
          .order("display_name")

        if (methodsError) {
          console.error("Error fetching payment methods:", methodsError)
        } else {
          setPaymentMethods(methodsData || [])

          // Set default payment method if available
          if (methodsData && methodsData.length > 0) {
            setPaymentMethod(methodsData[0].name)
          }
        }

        setLoading(false)
      } catch (error) {
        console.error("Error in deposit page:", error)
        setLoading(false)
        // Set default values in case of error
        setIsActive(false)
        setBalance(0)
        setUsedVouchers([])
      }
    }

    checkUser()
  }, [router])

  // Then modify the handleSubmit function to include this call:
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!userId) return

    setSubmitting(true)
    setMessage(null)
    setError(null)

    try {
      // Validate amount
      const depositAmount = Number.parseFloat(amount)
      if (isNaN(depositAmount) || depositAmount <= 0) {
        throw new Error("Please enter a valid amount")
      }

      // Minimum deposit amount
      if (depositAmount < 50) {
        throw new Error("Minimum deposit amount is 50৳")
      }

      // Validate transaction ID
      if (!transactionId.trim()) {
        throw new Error("Please enter a transaction ID")
      }

      // Validate mobile number
      if (!mobileNumber.trim()) {
        throw new Error("Please enter a mobile number")
      }

      // Create deposit request with correct column names
      const depositData = {
        user_id: userId,
        amount: depositAmount,
        method: paymentMethod,
        transaction_id: transactionId,
        mobile_number: mobileNumber,
        status: "pending",
        created_at: new Date().toISOString(),
      }

      const { error: depositError, data: depositResult } = await supabase
        .from("deposits")
        .insert([depositData])
        .select()

      if (depositError) {
        console.error("Deposit error details:", depositError)
        throw depositError
      }

      // Send Telegram notification directly
      if (depositResult && depositResult.length > 0) {
        await sendTelegramNotification(depositResult[0])
      }

      // Check if this deposit is enough to activate the account (50 Taka)
      if (!isActive && depositAmount >= 50) {
        let message =
          "Deposit request submitted successfully! Once approved, your account will be activated. Our admin has been notified and will review your request."

        if (wasReferred && referrerUsername) {
          message += ` Your referrer @${referrerUsername} will receive a 10৳ bonus when your account is activated.`
        }

        setMessage(message)
      } else {
        setMessage(
          "Deposit request submitted successfully! We'll process it shortly. Our admin has been notified and will review your request.",
        )
      }

      setAmount("")
      setTransactionId("")
      setMobileNumber("")
    } catch (error: any) {
      setError(error.message || "An error occurred while submitting your deposit request")
    } finally {
      setSubmitting(false)
    }
  }

  const validateVoucher = async () => {
    if (!voucherCode.trim() || !userId) return

    setValidatingVoucher(true)
    setVoucherError(null)
    setVoucherAmount(null)

    try {
      const response = await fetch("/api/vouchers/validate", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ voucherCode: voucherCode.trim() }),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || "Failed to validate voucher")
      }

      if (!data.valid) {
        setVoucherError(data.message || "Invalid voucher code")
        return
      }

      setVoucherAmount(data.amount)
    } catch (error: any) {
      setVoucherError(error.message || "An error occurred while validating the voucher code")
    } finally {
      setValidatingVoucher(false)
    }
  }

  const applyVoucher = async () => {
    if (!voucherCode.trim() || !userId) return

    setApplyingVoucher(true)
    setVoucherMessage(null)
    setVoucherError(null)

    try {
      const response = await fetch("/api/vouchers/apply", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ voucherCode: voucherCode.trim() }),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || "Failed to apply voucher")
      }

      if (!data.success) {
        throw new Error(data.message || "Failed to apply voucher")
      }

      let message = `Voucher code applied successfully! ${data.amount}৳ has been added to your account and your account is now activated.`

      if (wasReferred && referrerUsername) {
        message += ` Your referrer @${referrerUsername} has received a 10৳ bonus.`
      }

      setVoucherMessage(message)
      setVoucherCode("")
      setBalance(balance + data.amount)
      setIsActive(true)

      // Update used vouchers in state
      setUsedVouchers([...usedVouchers, voucherCode.trim()])

      // Reset voucher amount
      setVoucherAmount(null)
    } catch (error: any) {
      setVoucherError(error.message || "An error occurred while applying the voucher code")
    } finally {
      setApplyingVoucher(false)
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <LoadingSpinner size="lg" />
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold">Deposit Funds</h1>
        <p className="text-muted-foreground">Add money to your account</p>
      </div>

      {!isActive && (
        <Alert className="mb-6 bg-yellow-50 border-yellow-200">
          <AlertCircle className="h-4 w-4 text-yellow-600" />
          <AlertDescription className="text-yellow-700">
            Your account is not activated yet. You need to deposit at least 50৳ to activate your account.
            {wasReferred && referrerUsername && (
              <span className="block mt-1">
                You were referred by <strong>@{referrerUsername}</strong>. They will receive a 10৳ bonus when you
                activate your account.
              </span>
            )}
          </AlertDescription>
        </Alert>
      )}

      {message && (
        <Alert className="mb-6">
          <AlertDescription>{message}</AlertDescription>
        </Alert>
      )}

      {error && (
        <Alert variant="destructive" className="mb-6">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      <Tabs defaultValue="deposit" className="mb-6">
        <TabsList>
          <TabsTrigger value="deposit">Deposit</TabsTrigger>
          <TabsTrigger value="voucher">Redeem Voucher</TabsTrigger>
        </TabsList>

        <TabsContent value="deposit">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Deposit Information</CardTitle>
                <CardDescription>Enter your deposit details</CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="amount">Amount (৳)</Label>
                    <div className="flex">
                      <div className="bg-muted p-2 rounded-l-md">
                        <DollarSign className="h-5 w-5 text-muted-foreground" />
                      </div>
                      <Input
                        id="amount"
                        type="number"
                        placeholder="500"
                        value={amount}
                        onChange={(e) => setAmount(e.target.value)}
                        className="rounded-l-none"
                        required
                      />
                    </div>
                    {!isActive && (
                      <p className="text-xs text-amber-600">Deposit at least 50৳ to activate your account.</p>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label>Payment Method</Label>
                    <RadioGroup
                      value={paymentMethod}
                      onValueChange={setPaymentMethod}
                      className="flex flex-col space-y-1"
                    >
                      {paymentMethods.length > 0 ? (
                        paymentMethods.map((method) => (
                          <div key={method.id} className="flex items-center space-x-2">
                            <RadioGroupItem value={method.name} id={method.name} />
                            <Label htmlFor={method.name} className="cursor-pointer">
                              {method.display_name}
                            </Label>
                          </div>
                        ))
                      ) : (
                        <>
                          <div className="flex items-center space-x-2">
                            <RadioGroupItem value="nagad" id="nagad" />
                            <Label htmlFor="nagad" className="cursor-pointer">
                              Nagad
                            </Label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <RadioGroupItem value="bkash" id="bkash" />
                            <Label htmlFor="bkash" className="cursor-pointer">
                              bKash
                            </Label>
                          </div>
                        </>
                      )}
                    </RadioGroup>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="mobileNumber">Your Mobile Number</Label>
                    <Input
                      id="mobileNumber"
                      placeholder="01XXXXXXXXX"
                      value={mobileNumber}
                      onChange={(e) => setMobileNumber(e.target.value)}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="transactionId">Transaction ID</Label>
                    <Input
                      id="transactionId"
                      placeholder="TrxID12345"
                      value={transactionId}
                      onChange={(e) => setTransactionId(e.target.value)}
                      required
                    />
                  </div>

                  <Button type="submit" className="w-full" disabled={submitting}>
                    {submitting ? (
                      <>
                        <LoadingSpinner size="sm" className="mr-2" /> Processing...
                      </>
                    ) : (
                      "Submit Deposit"
                    )}
                  </Button>
                </form>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Deposit Instructions</CardTitle>
                <CardDescription>Follow these steps to deposit funds</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {paymentMethods.length > 0 ? (
                  paymentMethods
                    .filter((method) => method.name === paymentMethod)
                    .map((method) => (
                      <div key={method.id} className="space-y-4">
                        <h3 className="font-semibold">{method.display_name} Instructions:</h3>
                        <div className="space-y-2">
                          <p className="text-sm font-medium">English Instructions:</p>
                          <ol className="list-decimal list-inside space-y-1 text-sm">
                            <li>Open your {method.display_name} app</li>
                            <li>Select "Send Money"</li>
                            <li>
                              Enter our {method.display_name} number:{" "}
                              <span className="font-semibold">{method.account_number}</span>
                            </li>
                            <li>Enter the amount you want to deposit (minimum {getSetting("min_deposit", 50)}৳)</li>
                            <li>Complete the transaction and note the Transaction ID</li>
                            <li>Enter the Transaction ID in the form</li>
                          </ol>
                        </div>
                        <div className="space-y-2">
                          <p className="text-sm font-medium">বাংলা নির্দেশনা:</p>
                          <ol className="list-decimal list-inside space-y-1 text-sm">
                            <li>আপনার {method.display_name} অ্যাপ খুলুন</li>
                            <li>"সেন্ড মানি" নির্বাচন করুন</li>
                            <li>
                              আমাদের {method.display_name} নম্বর লিখুন:{" "}
                              <span className="font-semibold">{method.account_number}</span>
                            </li>
                            <li>আপনি যে পরিমাণ জমা করতে চান তা লিখুন (ন্যূনতম {getSetting("min_deposit", 50)}৳)</li>
                            <li>লেনদেন সম্পূর্ণ করুন এবং ট্রানজেকশন আইডি নোট করুন</li>
                            <li>ফর্মে ট্রানজেকশন আইডি লিখুন</li>
                          </ol>
                        </div>
                        {method.instructions && (
                          <div className="bg-muted p-4 rounded-md">
                            <p className="text-sm">{method.instructions}</p>
                          </div>
                        )}
                      </div>
                    ))
                ) : (
                  <>
                    <div className="space-y-4">
                      <h3 className="font-semibold">For Nagad:</h3>
                      <div className="space-y-2">
                        <p className="text-sm font-medium">English Instructions:</p>
                        <ol className="list-decimal list-inside space-y-1 text-sm">
                          <li>Open your Nagad app</li>
                          <li>Select "Send Money"</li>
                          <li>
                            Enter our Nagad number: <span className="font-semibold">01736392836</span>
                          </li>
                          <li>Enter the amount you want to deposit (minimum {getSetting("min_deposit", 50)}৳)</li>
                          <li>Complete the transaction and note the Transaction ID</li>
                          <li>Enter the Transaction ID in the form</li>
                        </ol>
                      </div>
                      <div className="space-y-2">
                        <p className="text-sm font-medium">বাংলা নির্দেশনা:</p>
                        <ol className="list-decimal list-inside space-y-1 text-sm">
                          <li>আপনার নগদ অ্যাপ খুলুন</li>
                          <li>"সেন্ড মানি" নির্বাচন করুন</li>
                          <li>
                            আমাদের নগদ নম্বর লিখুন: <span className="font-semibold">01736392836</span>
                          </li>
                          <li>আপনি যে পরিমাণ জমা করতে চান তা লিখুন (ন্যূনতম {getSetting("min_deposit", 50)}৳)</li>
                          <li>লেনদেন সম্পূর্ণ করুন এবং ট্রানজেকশন আইডি নোট করুন</li>
                          <li>ফর্মে ট্রানজেকশন আইডি লিখুন</li>
                        </ol>
                      </div>
                    </div>

                    <div className="space-y-4">
                      <h3 className="font-semibold">For bKash:</h3>
                      <div className="space-y-2">
                        <p className="text-sm font-medium">English Instructions:</p>
                        <ol className="list-decimal list-inside space-y-1 text-sm">
                          <li>Open your bKash app</li>
                          <li>Select "Send Money"</li>
                          <li>
                            Enter our bKash number: <span className="font-semibold">01833486175</span>
                          </li>
                          <li>Enter the amount you want to deposit (minimum {getSetting("min_deposit", 50)}৳)</li>
                          <li>Complete the transaction and note the Transaction ID</li>
                          <li>Enter the Transaction ID in the form</li>
                        </ol>
                      </div>
                      <div className="space-y-2">
                        <p className="text-sm font-medium">বাংলা নির্দেশনা:</p>
                        <ol className="list-decimal list-inside space-y-1 text-sm">
                          <li>আপনার বিকাশ অ্যাপ খুলুন</li>
                          <li>"সেন্ড মানি" নির্বাচন করুন</li>
                          <li>
                            আমাদের বিকাশ নম্বর লিখুন: <span className="font-semibold">01833486175</span>
                          </li>
                          <li>আপনি যে পরিমাণ জমা করতে চান তা লিখুন (ন্যূনতম {getSetting("min_deposit", 50)}৳)</li>
                          <li>লেনদেন সম্পূর্ণ করুন এবং ট্রানজেকশন আইডি নোট করুন</li>
                          <li>ফর্মে ট্রানজেকশন আইডি লিখুন</li>
                        </ol>
                      </div>
                    </div>
                  </>
                )}

                <div className="bg-muted p-4 rounded-md mt-4">
                  <p className="text-sm font-medium">Important Notes / গুরুত্বপূর্ণ তথ্য:</p>
                  <ul className="list-disc list-inside text-sm space-y-1 mt-2">
                    <li>
                      Minimum deposit amount is {getSetting("min_deposit", 50)}৳ / ন্যূনতম জমার পরিমাণ{" "}
                      {getSetting("min_deposit", 50)}৳
                    </li>
                    <li>Deposits are typically processed within 30 minutes / জমা সাধারণত ৩০ মিনিটের মধ্যে প্রক্রিয়া করা হয়</li>
                    <li>Make sure to enter the correct Transaction ID / সঠিক ট্রানজেকশন আইডি লিখতে ভুলবেন না</li>
                    <li>Contact support if you face any issues / কোন সমস্যা হলে সাপোর্টে যোগাযোগ করুন</li>
                  </ul>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="voucher">
          <Card>
            <CardHeader>
              <CardTitle>Redeem Voucher Code</CardTitle>
              <CardDescription>Enter your voucher code to receive bonus funds</CardDescription>
            </CardHeader>
            <CardContent>
              {voucherMessage && (
                <Alert className="mb-4">
                  <AlertDescription>{voucherMessage}</AlertDescription>
                </Alert>
              )}

              {voucherError && (
                <Alert variant="destructive" className="mb-4">
                  <AlertDescription>{voucherError}</AlertDescription>
                </Alert>
              )}

              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="voucherCode">Voucher Code</Label>
                  <div className="flex">
                    <div className="bg-muted p-2 rounded-l-md">
                      <Gift className="h-5 w-5 text-muted-foreground" />
                    </div>
                    <Input
                      id="voucherCode"
                      placeholder="Enter voucher code"
                      value={voucherCode}
                      onChange={(e) => setVoucherCode(e.target.value)}
                      className="rounded-l-none"
                    />
                  </div>
                </div>

                {voucherAmount === null && (
                  <Button
                    onClick={validateVoucher}
                    className="w-full"
                    disabled={validatingVoucher || !voucherCode.trim()}
                  >
                    {validatingVoucher ? (
                      <>
                        <LoadingSpinner size="sm" className="mr-2" /> Validating...
                      </>
                    ) : (
                      "Validate Voucher"
                    )}
                  </Button>
                )}

                {voucherAmount !== null && (
                  <Button onClick={applyVoucher} className="w-full" disabled={applyingVoucher || !voucherCode.trim()}>
                    {applyingVoucher ? (
                      <>
                        <LoadingSpinner size="sm" className="mr-2" /> Applying...
                      </>
                    ) : (
                      `Apply Voucher (${voucherAmount}৳)`
                    )}
                  </Button>
                )}

                <div className="bg-muted p-4 rounded-md mt-4">
                  <p className="text-sm font-medium">How to get voucher codes / ভাউচার কোড পাওয়ার উপায়:</p>
                  <ul className="list-disc list-inside text-sm space-y-1 mt-2">
                    <li>
                      Join our Telegram channel for exclusive vouchers / এক্সক্লুসিভ ভাউচার পেতে আমাদের টেলিগ্রাম চ্যানেলে যোগ
                      দিন:
                      <a
                        href="https://t.me/ritzoneofficial"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-primary ml-1 inline-flex items-center hover:underline"
                      >
                        t.me/ritzoneofficial <ExternalLink className="h-3 w-3 ml-1" />
                      </a>
                    </li>
                    <li>Participate in our events and contests / আমাদের ইভেন্ট এবং প্রতিযোগিতায় অংশগ্রহণ করুন</li>
                    <li>Refer friends to earn special vouchers / বিশেষ ভাউচার পেতে বন্ধুদের রেফার করুন</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
