"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import AuthLayout from "@/components/auth-layout"
import { supabase } from "@/lib/supabase"

export default function Login() {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const router = useRouter()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError(null)

    try {
      // Sign in with Supabase directly
      const { data, error: signInError } = await supabase.auth.signInWithPassword({
        email,
        password,
      })

      if (signInError) {
        throw signInError
      }

      // Check if user is admin
      const { data: profileData } = await supabase.from("profiles").select("is_admin").eq("id", data.user.id).single()

      if (profileData?.is_admin) {
        // Redirect to admin dashboard
        router.push("/admin")
      } else {
        // Redirect to user dashboard
        router.push("/dashboard")
      }
    } catch (error: any) {
      console.error("Login error:", error)
      setError(error.message || "Failed to sign in")
    } finally {
      setLoading(false)
    }
  }

  return (
    <AuthLayout
      title="Sign in to your account"
      subtitle="Enter your credentials to access your account"
      alternateLink={{
        text: "Don't have an account?",
        href: "/signup",
        label: "Sign up",
      }}
    >
      <form className="space-y-6" onSubmit={handleSubmit}>
        {error && <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-md">{error}</div>}

        <div>
          <label htmlFor="email" className="block text-sm font-medium text-gray-700">
            Email address
          </label>
          <input
            id="email"
            name="email"
            type="email"
            autoComplete="email"
            required
            className="mt-1 block w-full rounded-md border border-gray-300 px-3 py-2 shadow-sm focus:border-[#5E4FDB] focus:outline-none focus:ring-[#5E4FDB]"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
        </div>

        <div>
          <label htmlFor="password" className="block text-sm font-medium text-gray-700">
            Password
          </label>
          <input
            id="password"
            name="password"
            type="password"
            autoComplete="current-password"
            required
            className="mt-1 block w-full rounded-md border border-gray-300 px-3 py-2 shadow-sm focus:border-[#5E4FDB] focus:outline-none focus:ring-[#5E4FDB]"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </div>

        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <input
              id="remember-me"
              name="remember-me"
              type="checkbox"
              className="h-4 w-4 rounded border-gray-300 text-[#5E4FDB] focus:ring-[#5E4FDB]"
            />
            <label htmlFor="remember-me" className="ml-2 block text-sm text-gray-900">
              Remember me
            </label>
          </div>

          <div className="text-sm">
            <Link href="/forgot-password" className="font-medium text-[#5E4FDB] hover:text-[#4E3FCB]">
              Forgot your password?
            </Link>
          </div>
        </div>

        <div className="space-y-4">
          <button
            type="submit"
            disabled={loading}
            className="flex w-full justify-center rounded-md border border-transparent bg-[#5E4FDB] py-2 px-4 text-sm font-medium text-white shadow-sm hover:bg-[#4E3FCB] focus:outline-none focus:ring-2 focus:ring-[#5E4FDB] focus:ring-offset-2 disabled:opacity-75"
          >
            {loading ? "Signing in..." : "Sign in"}
          </button>

          <div className="text-center">
            <Link href="/admin-login" className="text-sm font-medium text-[#5E4FDB] hover:text-[#4E3FCB]">
              Admin panel login
            </Link>
          </div>
        </div>
      </form>
    </AuthLayout>
  )
}
