"use client"

import { useState, useEffect } from "react"
import { createClientComponentClient } from "@supabase/auth-helpers-nextjs"
import { toast } from "react-hot-toast"
import { useRouter } from "next/navigation"
import { Copy, CheckCircle } from "lucide-react"

export default function ProfilePage() {
  const [user, setUser] = useState<any>(null)
  const [referrals, setReferrals] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [copied, setCopied] = useState(false)
  const supabase = createClientComponentClient()
  const router = useRouter()

  useEffect(() => {
    fetchUserData()
  }, [])

  const fetchUserData = async () => {
    try {
      const {
        data: { session },
      } = await supabase.auth.getSession()

      if (!session) {
        router.push("/login")
        return
      }

      const { data: userData, error: userError } = await supabase
        .from("users")
        .select("*")
        .eq("id", session.user.id)
        .single()

      if (userError) throw userError
      setUser(userData)

      // Fetch referrals
      const { data: referralsData, error: referralsError } = await supabase
        .from("referrals")
        .select(`
          id,
          status,
          bonus_paid,
          created_at,
          referred:users!referred_id(id, name, email, is_activated)
        `)
        .eq("referrer_id", session.user.id)

      if (referralsError) throw referralsError
      setReferrals(referralsData || [])
    } catch (error: any) {
      toast.error(`Error fetching profile: ${error.message}`)
    } finally {
      setLoading(false)
    }
  }

  const copyReferralLink = () => {
    if (!user) return

    const referralLink = `${window.location.origin}/signup?ref=${user.referral_code}`
    navigator.clipboard.writeText(referralLink)
    setCopied(true)
    toast.success("Referral link copied to clipboard!")

    setTimeout(() => {
      setCopied(false)
    }, 3000)
  }

  if (loading) {
    return <div className="p-4">Loading profile...</div>
  }

  if (!user) {
    return <div className="p-4">Please log in to view your profile.</div>
  }

  return (
    <div className="container mx-auto p-4">
      <div className="mb-8 rounded-lg bg-white p-6 shadow-md">
        <h1 className="mb-4 text-2xl font-bold">Your Profile</h1>

        <div className="grid gap-4 md:grid-cols-2">
          <div>
            <p className="text-gray-600">
              Name: <span className="font-semibold">{user.name}</span>
            </p>
            <p className="text-gray-600">
              Email: <span className="font-semibold">{user.email}</span>
            </p>
            <p className="text-gray-600">
              Phone: <span className="font-semibold">{user.phone}</span>
            </p>
            <p className="text-gray-600">
              Balance: <span className="font-semibold">{user.balance} Taka</span>
            </p>
            <p className="text-gray-600">
              Status:
              <span
                className={`ml-2 rounded-full px-2 py-1 text-xs font-semibold ${
                  user.is_activated ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"
                }`}
              >
                {user.is_activated ? "Activated" : "Not Activated"}
              </span>
            </p>
          </div>

          <div className="rounded-lg bg-gray-50 p-4">
            <h2 className="mb-2 text-lg font-semibold">Your Referral Code</h2>
            <p className="mb-2 font-mono text-lg">{user.referral_code}</p>

            <div className="mb-4">
              <button
                onClick={copyReferralLink}
                className="flex items-center rounded-md bg-blue-500 px-4 py-2 text-white hover:bg-blue-600"
              >
                {copied ? (
                  <>
                    <CheckCircle className="mr-2 h-4 w-4" />
                    Copied!
                  </>
                ) : (
                  <>
                    <Copy className="mr-2 h-4 w-4" />
                    Copy Referral Link
                  </>
                )}
              </button>
            </div>

            <div className="text-sm text-gray-600">
              <p>Share your referral link with friends!</p>
              <p>You'll earn 35 Taka for each friend who joins and activates their account.</p>
              <p>Your friend will also receive 10 Taka upon activation.</p>
            </div>
          </div>
        </div>
      </div>

      <div className="rounded-lg bg-white p-6 shadow-md">
        <h2 className="mb-4 text-xl font-bold">Your Referrals</h2>

        {referrals.length === 0 ? (
          <p className="text-gray-500">You haven't referred anyone yet.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider text-gray-500">
                    Name
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider text-gray-500">
                    Email
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider text-gray-500">
                    Status
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider text-gray-500">
                    Bonus
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider text-gray-500">
                    Date
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200 bg-white">
                {referrals.map((referral) => (
                  <tr key={referral.id}>
                    <td className="whitespace-nowrap px-6 py-4">{referral.referred.name}</td>
                    <td className="whitespace-nowrap px-6 py-4">{referral.referred.email}</td>
                    <td className="whitespace-nowrap px-6 py-4">
                      <span
                        className={`inline-flex rounded-full px-2 text-xs font-semibold leading-5 ${
                          referral.referred.is_activated
                            ? "bg-green-100 text-green-800"
                            : "bg-yellow-100 text-yellow-800"
                        }`}
                      >
                        {referral.referred.is_activated ? "Activated" : "Pending"}
                      </span>
                    </td>
                    <td className="whitespace-nowrap px-6 py-4">
                      <span
                        className={`inline-flex rounded-full px-2 text-xs font-semibold leading-5 ${
                          referral.bonus_paid ? "bg-green-100 text-green-800" : "bg-gray-100 text-gray-800"
                        }`}
                      >
                        {referral.bonus_paid ? "Paid (35 Taka)" : "Pending"}
                      </span>
                    </td>
                    <td className="whitespace-nowrap px-6 py-4">
                      {new Date(referral.created_at).toLocaleDateString()}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  )
}
