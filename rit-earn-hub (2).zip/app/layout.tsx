import type React from "react"
import "./globals.css"
import { Inter } from "next/font/google"
import { ThemeProvider } from "@/components/theme-provider"
import { Toaster } from "@/components/ui/toaster"
import { ensureDatabaseSchema } from "@/lib/database-schema"
import { SettingsProvider } from "@/contexts/settings-context"

const inter = Inter({ subsets: ["latin"] })

// Run database schema check on server startup
ensureDatabaseSchema().catch((error) => {
  console.error("Failed to ensure database schema:", error)
})

export const metadata = {
  title: "Rafit IT Zone Earn",
  description: "Earn money by completing tasks and referring friends",
    generator: 'v0.dev'
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <SettingsProvider>
          <ThemeProvider attribute="class" defaultTheme="light" enableSystem>
            {children}
            <Toaster />
          </ThemeProvider>
        </SettingsProvider>
      </body>
    </html>
  )
}


import './globals.css'