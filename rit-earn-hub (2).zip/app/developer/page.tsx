import Link from "next/link"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ArrowLeft, Mail, Send, Facebook, Instagram, Twitter, Code, Globe, Calendar } from "lucide-react"

export default function DeveloperPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <Link href="/dashboard" className="inline-flex items-center text-primary hover:underline">
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Dashboard
        </Link>
        <h1 className="text-3xl font-bold mt-2 text-gradient">Developer Contact</h1>
        <p className="text-muted-foreground">Get in touch with the developer for technical assistance</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-1">
          <Card className="hover-lift h-full">
            <CardHeader>
              <CardTitle>Sheikh Rafit Hasan</CardTitle>
              <CardDescription>Full Stack Developer & Founder</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex justify-center">
                <div className="w-32 h-32 bg-primary/10 rounded-full flex items-center justify-center">
                  <span className="text-3xl font-bold text-primary">SRH</span>
                </div>
              </div>

              <div className="space-y-2 pt-4">
                <div className="flex items-center">
                  <Code className="h-4 w-4 text-primary mr-2" />
                  <span className="text-sm">Full Stack Developer</span>
                </div>
                <div className="flex items-center">
                  <Globe className="h-4 w-4 text-primary mr-2" />
                  <span className="text-sm">Bangladesh</span>
                </div>
                <div className="flex items-center">
                  <Calendar className="h-4 w-4 text-primary mr-2" />
                  <span className="text-sm">Available for freelance work</span>
                </div>
              </div>

              <div className="pt-4">
                <p className="text-sm text-muted-foreground">
                  Specialized in web development, mobile applications, and blockchain technology. Creator of RIT Earn
                  Hub and several other successful platforms.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="lg:col-span-2">
          <Card className="hover-lift h-full">
            <CardHeader>
              <CardTitle>Contact Information</CardTitle>
              <CardDescription>Multiple ways to reach out</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <a
                  href="mailto:sheikhrafithasan@gmail.com"
                  className="flex items-center p-4 border border-gray-200 rounded-lg hover:bg-primary/5 transition-colors"
                >
                  <Mail className="h-5 w-5 text-primary mr-3" />
                  <span>sheikhrafithasan@gmail.com</span>
                </a>

                <a
                  href="https://t.me/Knock_rafit_bot"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center p-4 border border-gray-200 rounded-lg hover:bg-primary/5 transition-colors"
                >
                  <Send className="h-5 w-5 text-primary mr-3" />
                  <span>t.me/Knock_rafit_bot</span>
                </a>

                <a
                  href="https://www.facebook.com/sheikh.rafit.hasan.official/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center p-4 border border-gray-200 rounded-lg hover:bg-primary/5 transition-colors"
                >
                  <Facebook className="h-5 w-5 text-primary mr-3" />
                  <span>Facebook Profile</span>
                </a>

                <a
                  href="https://www.instagram.com/rafit_official/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center p-4 border border-gray-200 rounded-lg hover:bg-primary/5 transition-colors"
                >
                  <Instagram className="h-5 w-5 text-primary mr-3" />
                  <span>Instagram Profile</span>
                </a>

                <a
                  href="https://x.com/rafit_official"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center p-4 border border-gray-200 rounded-lg hover:bg-primary/5 transition-colors"
                >
                  <Twitter className="h-5 w-5 text-primary mr-3" />
                  <span>Twitter Profile</span>
                </a>
              </div>

              <div className="mt-8 p-5 bg-primary/5 rounded-lg">
                <h3 className="font-medium mb-2">Technical Support</h3>
                <p className="text-sm mb-4">
                  For technical issues, bug reports, or feature requests, please include the following information when
                  contacting:
                </p>
                <ul className="list-disc list-inside text-sm space-y-1">
                  <li>Detailed description of the issue</li>
                  <li>Steps to reproduce the problem</li>
                  <li>Screenshots if applicable</li>
                  <li>Your device and browser information</li>
                </ul>
                <Button className="mt-4" asChild>
                  <a href="mailto:sheikhrafithasan@gmail.com?subject=RIT%20Earn%20Hub%20-%20Technical%20Support">
                    Contact for Technical Support
                  </a>
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
