import type React from "react"
import Navbar from "@/components/navbar"

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-1 bg-muted/20">{children}</main>
      <footer className="bg-muted py-4">
        <div className="container mx-auto px-4 text-center">
          <p className="text-muted-foreground text-sm">
            © {new Date().getFullYear()} RIT Earn Hub. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  )
}
