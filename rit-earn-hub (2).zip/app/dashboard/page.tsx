"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { supabase } from "@/lib/supabase"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { BarChart2, DollarSign, Users, Award, AlertCircle } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { LoadingSpinner } from "@/components/loading-spinner"
import Link from "next/link"

interface UserProfile {
  id: string
  username: string
  email: string
  balance: number
  referral_code: string
  completed_tasks: number
  total_earnings: number
  referral_count: number
  is_active: boolean
}

export default function Dashboard() {
  const router = useRouter()
  const [profile, setProfile] = useState<UserProfile | null>(null)
  const [loading, setLoading] = useState(true)
  const [userName, setUserName] = useState("")
  const [referralLink, setReferralLink] = useState("")

  useEffect(() => {
    const checkUser = async () => {
      const {
        data: { session },
      } = await supabase.auth.getSession()

      if (!session) {
        router.push("/login")
        return
      }

      try {
        // Get user profile
        const { data: profileData, error } = await supabase.from("profiles").select("*").eq("id", session.user.id)

        if (error) {
          console.error("Error fetching profile:", error)
          return
        }

        // Check if profile exists
        if (!profileData || profileData.length === 0) {
          console.error("No profile found for user")

          // Create a basic profile for the user
          const { error: createError } = await supabase.from("profiles").insert([
            {
              id: session.user.id,
              username: `user_${session.user.id.substring(0, 8)}`,
              email: session.user.email,
              balance: 0,
              is_active: false,
              referral_code: `RAFIT${session.user.id.substring(0, 8)}${Math.random().toString(36).substring(2, 6).toUpperCase()}`,
            },
          ])

          if (createError) {
            console.error("Error creating profile:", createError)
            return
          }

          // Fetch the newly created profile
          const { data: newProfileData } = await supabase
            .from("profiles")
            .select("*")
            .eq("id", session.user.id)
            .single()

          setProfile(newProfileData)
          setReferralLink(
            `${typeof window !== "undefined" ? window.location.origin : ""}/signup?ref=${newProfileData.username}`,
          )
        } else {
          // Use the first profile if multiple exist
          const userProfile = {
            ...profileData[0],
            completed_tasks: profileData[0].completed_tasks || 0,
            total_earnings: profileData[0].total_earnings || 0,
            referral_count: profileData[0].referral_count || 0,
            is_active: profileData[0].is_active || false,
          }

          setProfile(userProfile)
          setReferralLink(
            `${typeof window !== "undefined" ? window.location.origin : ""}/signup?ref=${userProfile.username}`,
          )
        }

        // Get user's name from metadata if available
        const { data: userData } = await supabase.auth.getUser()
        if (userData?.user?.user_metadata?.full_name) {
          setUserName(userData.user.user_metadata.full_name)
        } else {
          setUserName(profileData?.[0]?.username || "User")
        }

        setLoading(false)
      } catch (error) {
        console.error("Error in dashboard:", error)
        setLoading(false)
      }
    }

    checkUser()
  }, [router])

  const copyReferralLink = () => {
    navigator.clipboard.writeText(referralLink)
    alert("Referral link copied to clipboard!")
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <LoadingSpinner size="lg" />
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8 animate-fade-in">
        <h1 className="text-4xl font-bold text-gradient">Welcome, {userName}</h1>
        <p className="text-muted-foreground">Here's an overview of your activity and earnings</p>
      </div>

      {!profile?.is_active && (
        <Alert className="mb-6 bg-yellow-50 border-yellow-200 animate-slide-up">
          <AlertCircle className="h-4 w-4 text-yellow-600" />
          <AlertDescription className="text-yellow-700">
            Your account is not activated yet. You need to deposit at least 50৳ to activate your account.
            <Link href="/deposit" className="ml-2 text-primary underline">
              Deposit now
            </Link>
          </AlertDescription>
        </Alert>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <Card className="hover-lift animate-slide-up delay-100">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Balance</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center">
              <DollarSign className="h-4 w-4 text-primary mr-2" />
              <span className="text-2xl font-bold text-gradient">{profile?.balance.toFixed(2)}৳</span>
            </div>
            <p className="text-xs text-muted-foreground mt-1">Available for withdrawal</p>
          </CardContent>
        </Card>

        <Card className="hover-lift animate-slide-up delay-200">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Tasks Completed</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center">
              <BarChart2 className="h-4 w-4 text-primary mr-2" />
              <span className="text-2xl font-bold text-gradient">{profile?.completed_tasks || 0}</span>
            </div>
            <p className="text-xs text-muted-foreground mt-1">Total tasks completed</p>
          </CardContent>
        </Card>

        <Card className="hover-lift animate-slide-up delay-300">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Total Earnings</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center">
              <Award className="h-4 w-4 text-primary mr-2" />
              <span className="text-2xl font-bold text-gradient">{profile?.total_earnings?.toFixed(2) || "0.00"}৳</span>
            </div>
            <p className="text-xs text-muted-foreground mt-1">Lifetime earnings</p>
          </CardContent>
        </Card>

        <Card className="hover-lift animate-slide-up delay-400">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Referrals</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center">
              <Users className="h-4 w-4 text-primary mr-2" />
              <span className="text-2xl font-bold text-gradient">{profile?.referral_count || 0}</span>
            </div>
            <p className="text-xs text-muted-foreground mt-1">People you've referred</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
        <Card className="hover-lift animate-slide-in-left">
          <CardHeader>
            <CardTitle className="text-gradient">Quick Actions</CardTitle>
            <CardDescription>Get started with these common tasks</CardDescription>
          </CardHeader>
          <CardContent className="grid grid-cols-2 gap-4">
            <Link href="/tasks">
              <Button variant="outline" className="w-full justify-start hover-scale" disabled={!profile?.is_active}>
                <BarChart2 className="h-4 w-4 mr-2" />
                View Tasks
              </Button>
            </Link>
            <Link href="/referrals">
              <Button variant="outline" className="w-full justify-start hover-scale">
                <Users className="h-4 w-4 mr-2" />
                Refer Friends
              </Button>
            </Link>
            <Link href="/deposit">
              <Button variant="outline" className="w-full justify-start hover-scale">
                <DollarSign className="h-4 w-4 mr-2" />
                Deposit
              </Button>
            </Link>
            <Link href="/withdraw">
              <Button variant="outline" className="w-full justify-start hover-scale" disabled={!profile?.is_active}>
                <DollarSign className="h-4 w-4 mr-2" />
                Withdraw
              </Button>
            </Link>
          </CardContent>
        </Card>

        <Card className="hover-lift animate-slide-in-right">
          <CardHeader>
            <CardTitle className="text-gradient">Your Referral Link</CardTitle>
            <CardDescription>Share this link to earn rewards</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center space-x-2">
              <input
                type="text"
                readOnly
                value={referralLink}
                className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
              />
              <Button onClick={copyReferralLink} className="hover-scale">
                Copy
              </Button>
            </div>
            <p className="text-xs text-muted-foreground mt-2">
              Earn rewards when someone signs up using your referral link
            </p>
            <div className="mt-4 p-3 bg-blue-50 border border-blue-200 rounded-md animate-pulse-subtle">
              <p className="text-sm text-blue-800 font-medium">Referral Rewards:</p>
              <ul className="text-xs text-blue-700 mt-1 list-disc list-inside">
                <li>Your friend gets 10৳ when they sign up using your link</li>
                <li>You earn 5% bonus when they complete tasks</li>
              </ul>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
