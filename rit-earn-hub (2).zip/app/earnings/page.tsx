"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { supabase } from "@/lib/supabase"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { DollarSign, BarChart2, Users } from "lucide-react"

interface Transaction {
  id: string
  type: "task" | "referral" | "deposit" | "withdrawal"
  amount: number
  description: string
  created_at: string
  status: "completed" | "pending" | "failed"
}

export default function Earnings() {
  const router = useRouter()
  const [loading, setLoading] = useState(true)
  const [transactions, setTransactions] = useState<Transaction[]>([])
  const [stats, setStats] = useState({
    totalEarnings: 0,
    taskEarnings: 0,
    referralEarnings: 0,
  })

  useEffect(() => {
    const checkUser = async () => {
      const {
        data: { session },
      } = await supabase.auth.getSession()

      if (!session) {
        router.push("/login")
        return
      }

      // Fetch transactions
      const fetchTransactions = async () => {
        // Combine all transaction types
        const allTransactions: Transaction[] = []

        // Task earnings
        const { data: taskData } = await supabase
          .from("user_tasks")
          .select(`
            id,
            task:task_id(title, reward),
            completed_at,
            status
          `)
          .eq("user_id", session.user.id)
          .eq("status", "completed")
          .order("completed_at", { ascending: false })

        if (taskData) {
          taskData.forEach((task: any) => {
            allTransactions.push({
              id: task.id,
              type: "task",
              amount: task.task.reward,
              description: `Completed task: ${task.task.title}`,
              created_at: task.completed_at,
              status: "completed",
            })
          })
        }

        // Referral earnings
        const { data: referralData } = await supabase
          .from("referrals")
          .select(`
            id,
            referred_user:referred_user_id(full_name),
            reward,
            created_at
          `)
          .eq("referrer_id", session.user.id)
          .order("created_at", { ascending: false })

        if (referralData) {
          referralData.forEach((referral: any) => {
            allTransactions.push({
              id: referral.id,
              type: "referral",
              amount: referral.reward,
              description: `Referral bonus: ${referral.referred_user.full_name}`,
              created_at: referral.created_at,
              status: "completed",
            })
          })
        }

        // Deposits
        const { data: depositData } = await supabase
          .from("deposits")
          .select("*")
          .eq("user_id", session.user.id)
          .order("created_at", { ascending: false })

        if (depositData) {
          depositData.forEach((deposit: any) => {
            allTransactions.push({
              id: deposit.id,
              type: "deposit",
              amount: deposit.amount,
              description: `Deposit via ${deposit.payment_method}`,
              created_at: deposit.created_at,
              status: deposit.status,
            })
          })
        }

        // Withdrawals
        const { data: withdrawalData } = await supabase
          .from("withdrawals")
          .select("*")
          .eq("user_id", session.user.id)
          .order("created_at", { ascending: false })

        if (withdrawalData) {
          withdrawalData.forEach((withdrawal: any) => {
            allTransactions.push({
              id: withdrawal.id,
              type: "withdrawal",
              amount: -withdrawal.amount, // Negative amount for withdrawals
              description: `Withdrawal to ${withdrawal.payment_method}`,
              created_at: withdrawal.created_at,
              status: withdrawal.status,
            })
          })
        }

        // Sort by date
        allTransactions.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())

        setTransactions(allTransactions)

        // Calculate stats
        const taskEarnings = allTransactions
          .filter((t) => t.type === "task" && t.status === "completed")
          .reduce((sum, t) => sum + t.amount, 0)

        const referralEarnings = allTransactions
          .filter((t) => t.type === "referral" && t.status === "completed")
          .reduce((sum, t) => sum + t.amount, 0)

        setStats({
          totalEarnings: taskEarnings + referralEarnings,
          taskEarnings,
          referralEarnings,
        })

        setLoading(false)
      }

      fetchTransactions()
    }

    checkUser()
  }, [router])

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "completed":
        return <Badge className="bg-green-500">Completed</Badge>
      case "pending":
        return <Badge className="bg-yellow-500">Pending</Badge>
      case "failed":
        return <Badge className="bg-red-500">Failed</Badge>
      default:
        return <Badge>Unknown</Badge>
    }
  }

  const getAmountColor = (type: string, amount: number) => {
    if (type === "withdrawal") return "text-red-500"
    return "text-green-500"
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold">Earnings & Transactions</h1>
        <p className="text-muted-foreground">Track your earnings and transaction history</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Total Earnings</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center">
              <DollarSign className="h-4 w-4 text-primary mr-2" />
              <span className="text-2xl font-bold">{stats.totalEarnings.toFixed(2)}</span>
            </div>
            <p className="text-xs text-muted-foreground mt-1">Lifetime earnings</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Task Earnings</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center">
              <BarChart2 className="h-4 w-4 text-primary mr-2" />
              <span className="text-2xl font-bold">{stats.taskEarnings.toFixed(2)}</span>
            </div>
            <p className="text-xs text-muted-foreground mt-1">Earned from completing tasks</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Referral Earnings</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center">
              <Users className="h-4 w-4 text-primary mr-2" />
              <span className="text-2xl font-bold">{stats.referralEarnings.toFixed(2)}</span>
            </div>
            <p className="text-xs text-muted-foreground mt-1">Earned from referrals</p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Transaction History</CardTitle>
          <CardDescription>All your earnings and withdrawals</CardDescription>
        </CardHeader>
        <CardContent>
          {transactions.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Date</TableHead>
                  <TableHead>Description</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Amount</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {transactions.map((transaction) => (
                  <TableRow key={transaction.id}>
                    <TableCell>{new Date(transaction.created_at).toLocaleDateString()}</TableCell>
                    <TableCell>{transaction.description}</TableCell>
                    <TableCell className="capitalize">{transaction.type}</TableCell>
                    <TableCell>{getStatusBadge(transaction.status)}</TableCell>
                    <TableCell
                      className={`text-right font-medium ${getAmountColor(transaction.type, transaction.amount)}`}
                    >
                      {transaction.amount > 0 ? "+" : ""}
                      {transaction.amount.toFixed(2)}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <div className="text-center py-8">
              <DollarSign className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
              <h3 className="text-xl font-semibold mb-2">No transactions yet</h3>
              <p className="text-muted-foreground">Complete tasks or refer friends to start earning</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
