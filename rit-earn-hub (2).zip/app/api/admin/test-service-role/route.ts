import { NextResponse } from "next/server"
import { createClient } from "@supabase/supabase-js"

export async function GET(request: Request) {
  try {
    // Initialize Supabase client with admin privileges using service role key
    const supabaseAdmin = createClient(
      process.env.NEXT_PUBLIC_SUPABASE_URL || "",
      process.env.SUPABASE_SERVICE_ROLE_KEY || "",
      {
        auth: {
          persistSession: false,
          autoRefreshToken: false,
        },
      },
    )

    // Test query to verify service role key is working
    const { data: depositCount, error: depositError } = await supabaseAdmin
      .from("deposits")
      .select("id", { count: "exact" })

    if (depositError) {
      return NextResponse.json(
        {
          error: "Service role key test failed",
          details: depositError.message,
        },
        { status: 500 },
      )
    }

    const { data: withdrawalCount, error: withdrawalError } = await supabaseAdmin
      .from("withdrawals")
      .select("id", { count: "exact" })

    if (withdrawalError) {
      return NextResponse.json(
        {
          error: "Service role key test failed",
          details: withdrawalError.message,
        },
        { status: 500 },
      )
    }

    // Test query to verify we can access user profiles
    const { data: userCount, error: userError } = await supabaseAdmin.from("profiles").select("id", { count: "exact" })

    if (userError) {
      return NextResponse.json(
        {
          error: "Service role key test failed",
          details: userError.message,
        },
        { status: 500 },
      )
    }

    return NextResponse.json({
      success: true,
      message: "Service role key is working correctly",
      counts: {
        deposits: depositCount.length,
        withdrawals: withdrawalCount.length,
        users: userCount.length,
      },
      serviceRoleKey: process.env.SUPABASE_SERVICE_ROLE_KEY
        ? "Present (first 5 chars: " + process.env.SUPABASE_SERVICE_ROLE_KEY.substring(0, 5) + "...)"
        : "Missing",
    })
  } catch (error: any) {
    console.error("Error testing service role key:", error)
    return NextResponse.json(
      {
        error: "Service role key test failed",
        details: error.message,
      },
      { status: 500 },
    )
  }
}
