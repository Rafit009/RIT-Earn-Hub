import { NextResponse } from "next/server"
import { createClient } from "@supabase/supabase-js"

// Initialize Supabase client with admin privileges
const supabaseAdmin = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL || "",
  process.env.SUPABASE_SERVICE_ROLE_KEY || "",
  {
    auth: {
      persistSession: false,
      autoRefreshToken: false,
    },
  },
)

export async function GET(request: Request) {
  try {
    // Check for admin authentication token in headers
    const adminAuth = request.headers.get("x-admin-auth")
    if (adminAuth !== "true") {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // First, ensure the completed_at column exists
    try {
      await supabaseAdmin.rpc("exec_sql", {
        sql: `
          DO $$
          BEGIN
            IF NOT EXISTS (
              SELECT 1 
              FROM information_schema.columns 
              WHERE table_name = 'user_tasks' 
              AND column_name = 'completed_at'
            ) THEN
              ALTER TABLE user_tasks ADD COLUMN completed_at TIMESTAMP WITH TIME ZONE;
            END IF;
          END $$;
        `,
      })
    } catch (error) {
      console.log("Error ensuring column exists:", error)
      // Continue execution even if this fails
    }

    // Fetch submitted tasks with a more resilient query
    const { data, error } = await supabaseAdmin
      .from("user_tasks")
      .select(`
        id,
        user_id,
        task_id,
        status,
        started_at,
        submission_date,
        submission_details,
        admin_approved,
        created_at,
        user:profiles(username, is_active),
        task:tasks(title, reward)
      `)
      .eq("status", "submitted")
      .order("created_at", { ascending: false })

    if (error) {
      console.error("Error fetching task submissions:", error)
      return NextResponse.json({ error: error.message }, { status: 500 })
    }

    // Normalize the data to handle missing columns
    const submissions = data.map((submission) => ({
      id: submission.id,
      user_id: submission.user_id,
      task_id: submission.task_id,
      status: submission.status || "submitted",
      started_at: submission.started_at || submission.created_at,
      completed_at: null, // Default value since the column might not exist yet
      submission_details: submission.submission_details || "No details provided",
      submission_date: submission.submission_date || submission.created_at,
      admin_approved: submission.admin_approved || false,
      user: submission.user,
      task: submission.task,
    }))

    return NextResponse.json({ submissions })
  } catch (error: any) {
    console.error("Error in task submissions API:", error)
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}
