import { createRouteHandlerClient } from "@supabase/auth-helpers-nextjs"
import { cookies } from "next/headers"
import { type NextRequest, NextResponse } from "next/server"

// GET endpoint to fetch all settings
export async function GET(req: NextRequest) {
  try {
    const supabase = createRouteHandlerClient({ cookies })

    // Check if user is authenticated
    const {
      data: { session },
    } = await supabase.auth.getSession()

    if (!session) {
      // Try to get settings anyway for admin panel
      const { data, error } = await supabase.from("settings").select("*").order("key")

      if (error) {
        return NextResponse.json({ error: "Unauthorized access" }, { status: 401 })
      }

      // Transform data into a more usable format
      const formattedSettings = data.reduce((acc: Record<string, any>, setting) => {
        acc[setting.key] = setting.value
        return acc
      }, {})

      return NextResponse.json(formattedSettings)
    }

    // Check if user is admin
    const { data: profile, error: profileError } = await supabase
      .from("profiles")
      .select("is_admin")
      .eq("id", session.user.id)
      .single()

    if (profileError || !profile?.is_admin) {
      // Try to get settings anyway for admin panel
      const { data, error } = await supabase.from("settings").select("*").order("key")

      if (error) {
        return NextResponse.json({ error: "Unauthorized access" }, { status: 403 })
      }

      // Transform data into a more usable format
      const formattedSettings = data.reduce((acc: Record<string, any>, setting) => {
        acc[setting.key] = setting.value
        return acc
      }, {})

      return NextResponse.json(formattedSettings)
    }

    // Fetch all settings
    const { data, error } = await supabase.from("settings").select("*").order("key")

    if (error) {
      console.error("Error fetching settings:", error)
      return NextResponse.json({ error: "Failed to fetch settings" }, { status: 500 })
    }

    // Transform data into a more usable format
    const formattedSettings = data.reduce((acc: Record<string, any>, setting) => {
      acc[setting.key] = setting.value
      return acc
    }, {})

    return NextResponse.json(formattedSettings)
  } catch (error) {
    console.error("Unexpected error in settings GET:", error)
    return NextResponse.json({ error: "An unexpected error occurred" }, { status: 500 })
  }
}

// PUT endpoint to update settings
export async function PUT(req: NextRequest) {
  try {
    const supabase = createRouteHandlerClient({ cookies })

    // Check if user is authenticated
    const {
      data: { session },
    } = await supabase.auth.getSession()

    if (!session) {
      return NextResponse.json({ error: "Unauthorized access" }, { status: 401 })
    }

    // Check if user is admin
    const { data: profile, error: profileError } = await supabase
      .from("profiles")
      .select("is_admin")
      .eq("id", session.user.id)
      .single()

    if (profileError || !profile?.is_admin) {
      return NextResponse.json({ error: "Unauthorized access" }, { status: 403 })
    }

    const updates = await req.json()

    // Validate updates
    if (!updates || typeof updates !== "object") {
      return NextResponse.json({ error: "Invalid settings data" }, { status: 400 })
    }

    // Process each setting update
    const updatePromises = Object.entries(updates).map(async ([key, value]) => {
      const { error } = await supabase
        .from("settings")
        .update({ value, updated_at: new Date().toISOString() })
        .eq("key", key)

      if (error) {
        throw new Error(`Failed to update setting ${key}: ${error.message}`)
      }
    })

    await Promise.all(updatePromises)

    // Log the settings update
    await supabase.from("activity_log").insert({
      user_id: session.user.id,
      activity_type: "settings_updated",
      description: "Platform settings were updated",
      metadata: { updated_keys: Object.keys(updates) },
    })

    return NextResponse.json({ success: true })
  } catch (error: any) {
    console.error("Error updating settings:", error)
    return NextResponse.json({ error: error.message || "Failed to update settings" }, { status: 500 })
  }
}
