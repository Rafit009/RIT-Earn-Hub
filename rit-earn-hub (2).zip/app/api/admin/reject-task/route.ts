import { NextResponse } from "next/server"
import { createClient } from "@supabase/supabase-js"

// Initialize Supabase client with admin privileges using service role key
const supabaseAdmin = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL || "",
  process.env.SUPABASE_SERVICE_ROLE_KEY || "",
  {
    auth: {
      persistSession: false,
      autoRefreshToken: false,
    },
  },
)

export async function POST(request: Request) {
  try {
    // Parse the request body
    const body = await request.json()

    // Check for admin authentication token in headers
    const adminAuth = request.headers.get("x-admin-auth")
    if (adminAuth !== "true") {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Extract data
    const { submissionId, userId, taskId } = body

    if (!submissionId || !userId || !taskId) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    // Update user_tasks to reset to available status
    const { error: updateError } = await supabaseAdmin
      .from("user_tasks")
      .update({
        status: "available",
        submission_details: null,
        submission_date: null,
        started_at: null,
      })
      .eq("id", submissionId)

    if (updateError) {
      console.error("Error updating task status:", updateError)
      return NextResponse.json({ error: `Failed to update task status: ${updateError.message}` }, { status: 500 })
    }

    // Log the activity
    await supabaseAdmin.from("activity_log").insert([
      {
        user_id: userId,
        activity_type: "task_rejected",
        description: "Your task submission was rejected. Please try again.",
        metadata: {
          task_id: taskId,
        },
      },
    ])

    return NextResponse.json({
      success: true,
      message: "Task rejected successfully",
    })
  } catch (error: any) {
    console.error("Error in reject task API:", error)
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}
