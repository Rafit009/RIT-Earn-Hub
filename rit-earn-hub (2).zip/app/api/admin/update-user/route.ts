import { NextResponse } from "next/server"
import { createClient } from "@supabase/supabase-js"

// Initialize Supabase client with admin privileges
const supabaseAdmin = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL || "",
  process.env.SUPABASE_SERVICE_ROLE_KEY || "",
  {
    auth: {
      persistSession: false,
      autoRefreshToken: false,
    },
  },
)

export async function POST(request: Request) {
  try {
    // Check for admin authentication token in headers
    const adminAuth = request.headers.get("x-admin-auth")
    if (adminAuth !== "true") {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Parse request body
    const { userId, balance } = await request.json()

    if (!userId) {
      return NextResponse.json({ error: "User ID is required" }, { status: 400 })
    }

    // Update user balance
    const { error } = await supabaseAdmin
      .from("profiles")
      .update({ balance, updated_at: new Date().toISOString() })
      .eq("id", userId)

    if (error) {
      console.error("Error updating user:", error)
      return NextResponse.json({ error: error.message }, { status: 500 })
    }

    // Log the activity
    await supabaseAdmin.from("activity_log").insert([
      {
        user_id: userId,
        activity_type: "balance_update",
        description: `Your balance was updated to ${balance}৳ by an admin`,
        metadata: {
          new_balance: balance,
          updated_via: "admin_panel",
        },
      },
    ])

    return NextResponse.json({
      success: true,
      message: "User updated successfully",
    })
  } catch (error: any) {
    console.error("Error in update user API:", error)
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}
