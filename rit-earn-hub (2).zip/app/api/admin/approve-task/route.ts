import { NextResponse } from "next/server"
import { createClient } from "@supabase/supabase-js"

// Initialize Supabase client with admin privileges
const supabaseAdmin = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL || "",
  process.env.SUPABASE_SERVICE_ROLE_KEY || "",
  {
    auth: {
      persistSession: false,
      autoRefreshToken: false,
    },
  },
)

export async function POST(request: Request) {
  try {
    const { submissionId } = await request.json()

    // Check for admin authentication token in headers
    const adminAuth = request.headers.get("x-admin-auth")
    if (adminAuth !== "true") {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    if (!submissionId) {
      return NextResponse.json({ error: "Submission ID is required" }, { status: 400 })
    }

    // Get the submission details
    const { data: submission, error: submissionError } = await supabaseAdmin
      .from("user_tasks")
      .select("*, tasks(*)")
      .eq("id", submissionId)
      .single()

    if (submissionError) {
      console.error("Error fetching submission:", submissionError)
      return NextResponse.json({ error: "Failed to fetch submission details" }, { status: 500 })
    }

    if (submission.status !== "submitted") {
      return NextResponse.json({ error: "This submission is not in a submitted state" }, { status: 400 })
    }

    // Check if task has a completion limit and if it's been reached
    if (submission.tasks.completion_limit !== null) {
      const { count, error: countError } = await supabaseAdmin
        .from("user_tasks")
        .select("*", { count: "exact" })
        .eq("task_id", submission.task_id)
        .eq("status", "completed")

      if (countError) {
        console.error("Error counting completed tasks:", countError)
        return NextResponse.json({ error: "Failed to check completion count" }, { status: 500 })
      }

      // If limit reached, check if we should still approve this one
      if (count >= submission.tasks.completion_limit) {
        // We'll still approve this one, but mark the task as closed
        await supabaseAdmin.from("tasks").update({ is_closed: true }).eq("id", submission.task_id)
      }
    }

    // Update the submission status to completed
    const { error: updateError } = await supabaseAdmin
      .from("user_tasks")
      .update({
        status: "completed",
      })
      .eq("id", submissionId)

    if (updateError) {
      console.error("Error updating submission:", updateError)
      return NextResponse.json({ error: "Failed to approve submission" }, { status: 500 })
    }

    // Call the complete_task function to update user balance and stats
    const { data: userData, error: userError } = await supabaseAdmin
      .from("profiles")
      .select("id, balance, total_earnings, completed_tasks")
      .eq("id", submission.user_id)
      .single()

    if (userError) {
      console.error("Error fetching user data:", userError)
      return NextResponse.json({ error: "Failed to fetch user data" }, { status: 500 })
    }

    // Update user balance and stats
    const newBalance = Number.parseFloat(userData.balance) + Number.parseFloat(submission.tasks.reward)
    const newTotalEarnings = Number.parseFloat(userData.total_earnings) + Number.parseFloat(submission.tasks.reward)
    const newCompletedTasks = userData.completed_tasks + 1

    const { error: profileUpdateError } = await supabaseAdmin
      .from("profiles")
      .update({
        balance: newBalance,
        total_earnings: newTotalEarnings,
        completed_tasks: newCompletedTasks,
      })
      .eq("id", submission.user_id)

    if (profileUpdateError) {
      console.error("Error updating user profile:", profileUpdateError)
      return NextResponse.json({ error: "Failed to update user balance" }, { status: 500 })
    }

    // Add activity log
    await supabaseAdmin.from("activities").insert({
      user_id: submission.user_id,
      type: "task_completed",
      description: `Completed task: ${submission.tasks.title}`,
      amount: submission.tasks.reward,
      status: "completed",
    })

    // Check if we need to close the task due to reaching completion limit
    if (submission.tasks.completion_limit !== null) {
      const { count, error: countError } = await supabaseAdmin
        .from("user_tasks")
        .select("*", { count: "exact" })
        .eq("task_id", submission.task_id)
        .eq("status", "completed")

      if (!countError && count >= submission.tasks.completion_limit) {
        await supabaseAdmin.from("tasks").update({ is_closed: true }).eq("id", submission.task_id)
      }
    }

    return NextResponse.json({
      success: true,
      message: "Task submission approved successfully",
    })
  } catch (error: any) {
    console.error("Error in approve-task API:", error)
    return NextResponse.json({ error: error.message || "An unexpected error occurred" }, { status: 500 })
  }
}
