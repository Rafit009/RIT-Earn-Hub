import { NextResponse } from "next/server"
import { createClient } from "@supabase/supabase-js"

// Initialize Supabase client with admin privileges
const supabaseAdmin = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL || "",
  process.env.SUPABASE_SERVICE_ROLE_KEY || "",
  {
    auth: {
      persistSession: false,
      autoRefreshToken: false,
    },
  },
)

export async function POST(request: Request) {
  try {
    // Check for admin authentication token in headers
    const adminAuth = request.headers.get("x-admin-auth")
    if (adminAuth !== "true") {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Find completed deposits for inactive users that might not have been credited
    const { data: deposits, error: depositsError } = await supabaseAdmin.rpc("find_uncredited_deposits")

    if (depositsError) {
      console.error("Error finding deposits:", depositsError)
      return NextResponse.json({ error: "Failed to find deposits" }, { status: 500 })
    }

    // Process the deposits
    const results = []
    for (const deposit of deposits) {
      try {
        // Apply the deposit to the user's balance
        const { data: updateResult, error: updateError } = await supabaseAdmin.rpc("apply_missed_deposit", {
          deposit_id: deposit.id,
        })

        if (updateError) {
          results.push({
            deposit_id: deposit.id,
            status: "error",
            message: updateError.message,
          })
        } else {
          results.push({
            deposit_id: deposit.id,
            status: "success",
            message: `Deposit of ${deposit.amount}৳ credited to user (${deposit.user_id})`,
          })
        }
      } catch (error) {
        results.push({
          deposit_id: deposit.id,
          status: "error",
          message: error.message,
        })
      }
    }

    return NextResponse.json({
      success: true,
      message: `Processed ${deposits.length} uncredited deposits`,
      fixed: results.filter((r) => r.status === "success").length,
      errors: results.filter((r) => r.status === "error").length,
      results,
    })
  } catch (error: any) {
    console.error("Error processing deposits:", error)
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}
