import { NextResponse } from "next/server"
import { createClient } from "@supabase/supabase-js"

// Initialize Supabase client with admin privileges using service role key
const supabaseAdmin = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL || "",
  process.env.SUPABASE_SERVICE_ROLE_KEY || "",
  {
    auth: {
      persistSession: false,
      autoRefreshToken: false,
    },
  },
)

export async function POST(request: Request) {
  try {
    // Parse the request body
    const body = await request.json()
    console.log("Processing transaction request:", body)

    // Check for admin authentication token in headers
    const adminAuth = request.headers.get("x-admin-auth")
    if (adminAuth !== "true") {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Extract transaction data
    const { type, id, status } = body

    if (!type || !id || !status) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    // Validate transaction type
    if (type !== "deposits" && type !== "withdrawals") {
      return NextResponse.json({ error: "Invalid transaction type" }, { status: 400 })
    }

    // Validate status
    if (status !== "completed" && status !== "failed") {
      return NextResponse.json({ error: "Invalid status" }, { status: 400 })
    }

    console.log(`Processing ${type} transaction with ID ${id}, setting status to ${status}`)

    // Get the transaction details
    const { data: transaction, error: fetchError } = await supabaseAdmin.from(type).select("*").eq("id", id).single()

    if (fetchError) {
      console.error(`Failed to fetch ${type}:`, fetchError)
      return NextResponse.json({ error: `Failed to fetch ${type}: ${fetchError.message}` }, { status: 500 })
    }

    if (!transaction) {
      return NextResponse.json({ error: `Transaction not found` }, { status: 404 })
    }

    if (transaction.status !== "pending") {
      return NextResponse.json({ error: `This transaction has already been ${transaction.status}` }, { status: 400 })
    }

    // Get user details
    const { data: userData, error: userError } = await supabaseAdmin
      .from("profiles")
      .select("username, is_active, balance")
      .eq("id", transaction.user_id)
      .single()

    if (userError) {
      console.error(`Failed to fetch user data:`, userError)
      return NextResponse.json({ error: `Failed to fetch user data: ${userError.message}` }, { status: 500 })
    }

    console.log("User data:", userData)

    // Update transaction status
    const { error: updateError } = await supabaseAdmin
      .from(type)
      .update({
        status: status,
        updated_at: new Date().toISOString(),
      })
      .eq("id", id)

    if (updateError) {
      console.error(`Failed to update ${type}:`, updateError)
      return NextResponse.json({ error: `Failed to update ${type}: ${updateError.message}` }, { status: 500 })
    }

    console.log(`Transaction status updated to ${status}`)

    // Get payment method (handle both field names)
    const paymentMethod = transaction.method || transaction.payment_method || "unknown"

    // Handle specific actions based on transaction type and status
    if (type === "deposits" && status === "completed") {
      // For deposits: Add amount to user's balance
      const shouldActivate = transaction.amount >= 50 && !userData.is_active
      const currentBalance = Number.parseFloat(userData.balance) || 0
      const newBalance = currentBalance + Number.parseFloat(transaction.amount)

      console.log(`Updating user balance: ${currentBalance} + ${transaction.amount} = ${newBalance}`)
      console.log(`Should activate account: ${shouldActivate}`)
      console.log(`User activation status before update: ${userData.is_active}`)

      // Update user balance and activate account if needed
      const updateData = {
        balance: newBalance,
        updated_at: new Date().toISOString(),
      }

      // Only update activation status if deposit amount is sufficient
      if (shouldActivate) {
        updateData.is_active = true

        // Process referral bonus if the user is being activated
        try {
          await supabaseAdmin.rpc("process_referral_bonus", {
            referred_user_id: transaction.user_id,
          })
          console.log("Referral bonus processed for user:", transaction.user_id)
        } catch (refError) {
          console.error("Error processing referral bonus:", refError)
          // Continue even if referral bonus processing fails
        }
      }

      console.log("Updating profile with data:", updateData)

      const { error: balanceError } = await supabaseAdmin
        .from("profiles")
        .update(updateData)
        .eq("id", transaction.user_id)

      if (balanceError) {
        console.error(`Failed to update user balance:`, balanceError)
        return NextResponse.json({ error: `Failed to update user balance: ${balanceError.message}` }, { status: 500 })
      }

      console.log(`User balance updated successfully from ${currentBalance} to ${newBalance}`)
      if (shouldActivate) {
        console.log(`User account activated: ${transaction.user_id}`)
      }

      // Log the activity
      await supabaseAdmin.from("activity_log").insert([
        {
          user_id: transaction.user_id,
          activity_type: "deposit_approved",
          description: `Your deposit of ${transaction.amount}৳ has been approved${shouldActivate ? " and your account has been activated" : ""}`,
          metadata: {
            transaction_id: id,
            amount: transaction.amount,
            method: paymentMethod,
            approved_via: "admin_panel",
            account_activated: shouldActivate,
          },
        },
      ])
    } else if (type === "deposits" && status === "failed") {
      // For deposits: Just log the declined activity
      await supabaseAdmin.from("activity_log").insert([
        {
          user_id: transaction.user_id,
          activity_type: "deposit_declined",
          description: `Your deposit of ${transaction.amount}৳ has been declined`,
          metadata: {
            transaction_id: id,
            amount: transaction.amount,
            method: paymentMethod,
            declined_via: "admin_panel",
          },
        },
      ])

      console.log("Activity log created for deposit decline")
    } else if (type === "withdrawals" && status === "completed") {
      // For withdrawals: Just log the activity (amount already deducted)
      await supabaseAdmin.from("activity_log").insert([
        {
          user_id: transaction.user_id,
          activity_type: "withdrawal_approved",
          description: `Your withdrawal of ${transaction.amount}৳ has been approved`,
          metadata: {
            transaction_id: id,
            amount: transaction.amount,
            method: paymentMethod,
            approved_via: "admin_panel",
          },
        },
      ])

      console.log("Activity log created for withdrawal approval")
    } else if (type === "withdrawals" && status === "failed") {
      // If withdrawal is declined, refund the amount to user's balance
      const currentBalance = userData.balance || 0
      const newBalance = currentBalance + transaction.amount

      console.log(`Refunding withdrawal: ${currentBalance} + ${transaction.amount} = ${newBalance}`)

      const { error: refundError } = await supabaseAdmin
        .from("profiles")
        .update({
          balance: newBalance,
        })
        .eq("id", transaction.user_id)

      if (refundError) {
        console.error(`Failed to refund user balance:`, refundError)
        return NextResponse.json({ error: `Failed to refund user balance: ${refundError.message}` }, { status: 500 })
      }

      console.log("User balance refunded successfully")

      // Log the declined withdrawal
      await supabaseAdmin.from("activity_log").insert([
        {
          user_id: transaction.user_id,
          activity_type: "withdrawal_declined",
          description: `Your withdrawal of ${transaction.amount}৳ has been declined. The amount has been refunded to your balance.`,
          metadata: {
            transaction_id: id,
            amount: transaction.amount,
            method: paymentMethod,
            declined_via: "admin_panel",
          },
        },
      ])

      console.log("Activity log created for withdrawal decline")
    }

    // Send notification via Telegram (simplified approach)
    try {
      console.log("Sending Telegram notification")

      // Get user's username
      const username = userData.username || "unknown"

      // Create a simple message for Telegram
      const message = `
Transaction ${status.toUpperCase()}:
Type: ${type === "deposits" ? "Deposit" : "Withdrawal"}
Amount: ${transaction.amount}৳
User: @${username}
Method: ${paymentMethod}
ID: ${id}
      `

      // Send a direct message to Telegram
      const BOT_TOKEN = "7825284153:AAEKbga9rIBOUnSL2ndRrO6Hl1HsxS1EV7w"
      const CHAT_ID = "6880722176"

      const TELEGRAM_API_URL = `https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`

      const telegramResponse = await fetch(TELEGRAM_API_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          chat_id: CHAT_ID,
          text: message,
        }),
      })

      if (!telegramResponse.ok) {
        const telegramError = await telegramResponse.json()
        console.error("Telegram notification error:", telegramError)
      } else {
        console.log("Telegram notification sent successfully")
      }
    } catch (error) {
      console.error("Error sending Telegram notification:", error)
      // Continue even if Telegram notification fails
    }

    return NextResponse.json({
      success: true,
      message: `Transaction ${status} successfully`,
      transaction: {
        ...transaction,
        status: status,
        updated_at: new Date().toISOString(),
      },
    })
  } catch (error: any) {
    console.error("Error in transaction processing API:", error)
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}
