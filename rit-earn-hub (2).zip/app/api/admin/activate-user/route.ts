import { createClient } from "@supabase/supabase-js"
import { NextResponse } from "next/server"

export async function POST(request: Request) {
  try {
    const { userId } = await request.json()

    if (!userId) {
      return NextResponse.json({ error: "User ID is required" }, { status: 400 })
    }

    // Create a service role client to bypass RLS
    const supabaseAdmin = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!)

    // Start a transaction
    const { error: activationError } = await supabaseAdmin.rpc("activate_user_with_referral_bonus", {
      user_id_param: userId,
    })

    if (activationError) {
      console.error("User activation error:", activationError)
      return NextResponse.json({ error: activationError.message }, { status: 500 })
    }

    return NextResponse.json({ message: "User activated successfully with referral bonuses applied" })
  } catch (error) {
    console.error("Activation error:", error)
    return NextResponse.json({ error: "An unexpected error occurred" }, { status: 500 })
  }
}
