import { NextResponse } from "next/server"
import { createClient } from "@supabase/supabase-js"

// Initialize Supabase client with admin privileges using service role key
const supabaseAdmin = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL || "",
  process.env.SUPABASE_SERVICE_ROLE_KEY || "",
  {
    auth: {
      persistSession: false,
      autoRefreshToken: false,
    },
  },
)

export async function POST(request: Request) {
  try {
    // Parse the request body
    const body = await request.json()

    // Check for admin authentication token in headers
    const adminAuth = request.headers.get("x-admin-auth")
    if (adminAuth !== "true") {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Extract user ID
    const { userId } = body

    if (!userId) {
      return NextResponse.json({ error: "User ID is required" }, { status: 400 })
    }

    // Get user details
    const { data: userData, error: userError } = await supabaseAdmin
      .from("profiles")
      .select("id, username, referred_by, is_active")
      .eq("id", userId)
      .single()

    if (userError) {
      console.error("Error fetching user:", userError)
      return NextResponse.json({ error: `Failed to fetch user: ${userError.message}` }, { status: 500 })
    }

    if (!userData) {
      return NextResponse.json({ error: "User not found" }, { status: 404 })
    }

    // Check if user has a referrer
    if (!userData.referred_by) {
      return NextResponse.json({ error: "User was not referred by anyone" }, { status: 400 })
    }

    // Process referral bonus
    const { data, error: processError } = await supabaseAdmin.rpc("process_referral_bonus", {
      referred_user_id: userId,
    })

    if (processError) {
      console.error("Error processing referral bonus:", processError)
      return NextResponse.json({ error: `Failed to process referral bonus: ${processError.message}` }, { status: 500 })
    }

    return NextResponse.json({
      success: true,
      message: "Referral bonus processed successfully",
      result: data,
    })
  } catch (error: any) {
    console.error("Error in process-referral API:", error)
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}
