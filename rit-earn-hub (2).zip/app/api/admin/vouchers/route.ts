import { NextResponse } from "next/server"
import { createClient } from "@supabase/supabase-js"

// Initialize Supabase client with admin privileges
const supabaseAdmin = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL || "",
  process.env.SUPABASE_SERVICE_ROLE_KEY || "",
  {
    auth: {
      persistSession: false,
      autoRefreshToken: false,
    },
  },
)

// GET - Fetch all vouchers
export async function GET(request: Request) {
  try {
    // Check for admin authentication token in headers
    const adminAuth = request.headers.get("x-admin-auth")
    if (adminAuth !== "true") {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Get query parameters
    const { searchParams } = new URL(request.url)
    const active = searchParams.get("active")

    // Build query
    let query = supabaseAdmin.from("vouchers").select(`
      *,
      creator:created_by(username)
    `)

    // Filter by active status if provided
    if (active === "true") {
      query = query.eq("is_active", true)
    } else if (active === "false") {
      query = query.eq("is_active", false)
    }

    // Execute query
    const { data, error } = await query.order("created_at", { ascending: false })

    if (error) {
      console.error("Error fetching vouchers:", error)
      return NextResponse.json({ error: error.message }, { status: 500 })
    }

    return NextResponse.json({ vouchers: data })
  } catch (error: any) {
    console.error("Error in vouchers API:", error)
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}

// POST - Create a new voucher
export async function POST(request: Request) {
  try {
    // Check for admin authentication token in headers
    const adminAuth = request.headers.get("x-admin-auth")
    if (adminAuth !== "true") {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Parse request body
    const body = await request.json()
    const { code, amount, description, maxUses, expiresAt, createdBy } = body

    // Validate required fields
    if (!code || !amount) {
      return NextResponse.json({ error: "Code and amount are required" }, { status: 400 })
    }

    // Check if voucher code already exists
    const { data: existingVoucher, error: checkError } = await supabaseAdmin
      .from("vouchers")
      .select("id")
      .eq("code", code)
      .single()

    if (existingVoucher) {
      return NextResponse.json({ error: "Voucher code already exists" }, { status: 400 })
    }

    // Create new voucher
    const { data, error } = await supabaseAdmin
      .from("vouchers")
      .insert({
        code,
        amount: Number(amount),
        description,
        max_uses: maxUses ? Number(maxUses) : null,
        expires_at: expiresAt || null,
        created_by: createdBy,
      })
      .select()

    if (error) {
      console.error("Error creating voucher:", error)
      return NextResponse.json({ error: error.message }, { status: 500 })
    }

    return NextResponse.json({
      success: true,
      message: "Voucher created successfully",
      voucher: data[0],
    })
  } catch (error: any) {
    console.error("Error in create voucher API:", error)
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}

// PUT - Update a voucher
export async function PUT(request: Request) {
  try {
    // Check for admin authentication token in headers
    const adminAuth = request.headers.get("x-admin-auth")
    if (adminAuth !== "true") {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Parse request body
    const body = await request.json()
    const { id, isActive, description, maxUses, expiresAt } = body

    // Validate required fields
    if (!id) {
      return NextResponse.json({ error: "Voucher ID is required" }, { status: 400 })
    }

    // Prepare update data
    const updateData: any = {}

    if (isActive !== undefined) updateData.is_active = isActive
    if (description !== undefined) updateData.description = description
    if (maxUses !== undefined) updateData.max_uses = maxUses === null ? null : Number(maxUses)
    if (expiresAt !== undefined) updateData.expires_at = expiresAt

    // Update voucher
    const { data, error } = await supabaseAdmin.from("vouchers").update(updateData).eq("id", id).select()

    if (error) {
      console.error("Error updating voucher:", error)
      return NextResponse.json({ error: error.message }, { status: 500 })
    }

    return NextResponse.json({
      success: true,
      message: "Voucher updated successfully",
      voucher: data[0],
    })
  } catch (error: any) {
    console.error("Error in update voucher API:", error)
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}

// DELETE - Delete a voucher
export async function DELETE(request: Request) {
  try {
    // Check for admin authentication token in headers
    const adminAuth = request.headers.get("x-admin-auth")
    if (adminAuth !== "true") {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Get voucher ID from query params
    const { searchParams } = new URL(request.url)
    const id = searchParams.get("id")

    if (!id) {
      return NextResponse.json({ error: "Voucher ID is required" }, { status: 400 })
    }

    // Delete voucher
    const { error } = await supabaseAdmin.from("vouchers").delete().eq("id", id)

    if (error) {
      console.error("Error deleting voucher:", error)
      return NextResponse.json({ error: error.message }, { status: 500 })
    }

    return NextResponse.json({
      success: true,
      message: "Voucher deleted successfully",
    })
  } catch (error: any) {
    console.error("Error in delete voucher API:", error)
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}
