import { NextResponse } from "next/server"
import { createClient } from "@supabase/supabase-js"

// Initialize Supabase client with admin privileges
const supabaseAdmin = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL || "",
  process.env.SUPABASE_SERVICE_ROLE_KEY || "",
  {
    auth: {
      persistSession: false,
      autoRefreshToken: false,
    },
  },
)

export async function POST(request: Request) {
  try {
    // Check for admin authentication token in headers
    const adminAuth = request.headers.get("x-admin-auth")
    if (adminAuth !== "true") {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Get all completed deposits
    const { data: completedDeposits, error: depositsError } = await supabaseAdmin
      .from("deposits")
      .select("id, user_id, amount, created_at")
      .eq("status", "completed")
      .order("created_at", { ascending: true })

    if (depositsError) {
      return NextResponse.json({ error: `Failed to fetch deposits: ${depositsError.message}` }, { status: 500 })
    }

    console.log(`Found ${completedDeposits.length} completed deposits to verify`)

    // Process each deposit to ensure it was correctly applied
    const results = []
    for (const deposit of completedDeposits) {
      // Get user's current balance
      const { data: userData, error: userError } = await supabaseAdmin
        .from("profiles")
        .select("id, username, balance, is_active")
        .eq("id", deposit.user_id)
        .single()

      if (userError) {
        results.push({
          deposit_id: deposit.id,
          status: "error",
          message: `Failed to fetch user data: ${userError.message}`,
        })
        continue
      }

      // Check if this deposit is in the activity log
      const { data: activityData, error: activityError } = await supabaseAdmin
        .from("activity_log")
        .select("id")
        .eq("user_id", deposit.user_id)
        .eq("activity_type", "deposit_approved")
        .eq("metadata->transaction_id", deposit.id)
        .single()

      if (activityError && !activityError.message.includes("No rows found")) {
        results.push({
          deposit_id: deposit.id,
          status: "error",
          message: `Failed to check activity log: ${activityError.message}`,
        })
        continue
      }

      // If we found an activity log entry, this deposit was likely processed correctly
      if (activityData) {
        results.push({
          deposit_id: deposit.id,
          status: "skipped",
          message: "Deposit already has an activity log entry",
        })
        continue
      }

      // This deposit might not have been processed correctly
      // Add an activity log entry and update the balance
      const { error: logError } = await supabaseAdmin.from("activity_log").insert([
        {
          user_id: deposit.user_id,
          activity_type: "deposit_approved",
          description: `Your deposit of ${deposit.amount}৳ has been approved (fixed)`,
          metadata: {
            transaction_id: deposit.id,
            amount: deposit.amount,
            fixed_by: "admin_repair_script",
          },
        },
      ])

      if (logError) {
        results.push({
          deposit_id: deposit.id,
          status: "error",
          message: `Failed to create activity log: ${logError.message}`,
        })
        continue
      }

      // Update the user's balance
      const newBalance = Number.parseFloat(userData.balance) + Number.parseFloat(deposit.amount)
      const { error: updateError } = await supabaseAdmin
        .from("profiles")
        .update({
          balance: newBalance,
          updated_at: new Date().toISOString(),
        })
        .eq("id", deposit.user_id)

      if (updateError) {
        results.push({
          deposit_id: deposit.id,
          status: "error",
          message: `Failed to update balance: ${updateError.message}`,
        })
        continue
      }

      results.push({
        deposit_id: deposit.id,
        status: "fixed",
        message: `Added ${deposit.amount}৳ to user @${userData.username}'s balance`,
      })
    }

    return NextResponse.json({
      success: true,
      message: `Processed ${completedDeposits.length} deposits`,
      results,
    })
  } catch (error: any) {
    console.error("Error in fix-deposit-balances API:", error)
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}
