import { NextResponse } from "next/server"
import { createClient } from "@supabase/supabase-js"

// Initialize Supabase client with admin privileges using service role key
const supabaseAdmin = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL || "",
  process.env.SUPABASE_SERVICE_ROLE_KEY || "",
  {
    auth: {
      persistSession: false,
      autoRefreshToken: false,
    },
  },
)

export async function GET(request: Request) {
  try {
    // Check for admin authentication token in headers
    const adminAuth = request.headers.get("x-admin-auth")
    if (adminAuth !== "true") {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Get the transaction type from query params
    const { searchParams } = new URL(request.url)
    const type = searchParams.get("type") || "all"

    // Fetch deposits
    const { data: deposits, error: depositsError } = await supabaseAdmin
      .from("deposits")
      .select(`
        *,
        user:profiles(username, is_active)
      `)
      .order("created_at", { ascending: false })

    if (depositsError) {
      console.error("Error fetching deposits:", depositsError)
      return NextResponse.json({ error: depositsError.message }, { status: 500 })
    }

    // Fetch withdrawals
    const { data: withdrawals, error: withdrawalsError } = await supabaseAdmin
      .from("withdrawals")
      .select(`
        *,
        user:profiles(username, is_active)
      `)
      .order("created_at", { ascending: false })

    if (withdrawalsError) {
      console.error("Error fetching withdrawals:", withdrawalsError)
      return NextResponse.json({ error: withdrawalsError.message }, { status: 500 })
    }

    // Return the requested data
    if (type === "deposits") {
      return NextResponse.json({ deposits })
    } else if (type === "withdrawals") {
      return NextResponse.json({ withdrawals })
    } else {
      return NextResponse.json({ deposits, withdrawals })
    }
  } catch (error: any) {
    console.error("Error in fetch transactions API:", error)
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}
