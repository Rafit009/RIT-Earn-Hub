import { NextResponse } from "next/server"
import { createClient } from "@supabase/supabase-js"

// Initialize Supabase client with admin privileges
const supabaseAdmin = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL || "",
  process.env.SUPABASE_SERVICE_ROLE_KEY || "",
  {
    auth: {
      persistSession: false,
      autoRefreshToken: false,
    },
  },
)

export async function POST(request: Request) {
  try {
    // Check for admin authentication token in headers
    const adminAuth = request.headers.get("x-admin-auth")
    if (adminAuth !== "true") {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Find all pending referrals that might need bonuses applied
    const { data: pendingReferrals, error: referralsError } = await supabaseAdmin
      .from("referrals")
      .select("id, referrer_id, referred_id")
      .eq("status", "pending")

    if (referralsError) {
      console.error("Error fetching pending referrals:", referralsError)
      return NextResponse.json({ error: "Failed to fetch pending referrals" }, { status: 500 })
    }

    // Process each pending referral
    const results = []
    for (const referral of pendingReferrals) {
      try {
        // Apply the immediate referral bonuses
        const { data: bonusResult, error: bonusError } = await supabaseAdmin.rpc("apply_immediate_referral_bonus", {
          referred_user_id: referral.referred_id,
          referrer_id: referral.referrer_id,
        })

        if (bonusError) {
          results.push({
            referral_id: referral.id,
            status: "error",
            message: bonusError.message,
          })
        } else {
          results.push({
            referral_id: referral.id,
            status: "success",
            message: "Referral bonuses applied successfully",
          })
        }
      } catch (error) {
        results.push({
          referral_id: referral.id,
          status: "error",
          message: error.message || "Unknown error",
        })
      }
    }

    return NextResponse.json({
      success: true,
      message: `Processed ${pendingReferrals.length} pending referrals`,
      fixed: results.filter((r) => r.status === "success").length,
      errors: results.filter((r) => r.status === "error").length,
      results,
    })
  } catch (error: any) {
    console.error("Error in fix-all-referral-bonuses API:", error)
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}
