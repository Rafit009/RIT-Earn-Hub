import { NextResponse } from "next/server"
import { createClient } from "@supabase/supabase-js"

// Initialize Supabase client with admin privileges using service role key
const supabaseAdmin = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL || "",
  process.env.SUPABASE_SERVICE_ROLE_KEY || "",
  {
    auth: {
      persistSession: false,
      autoRefreshToken: false,
    },
  },
)

export async function POST(request: Request) {
  try {
    // Parse the request body
    const body = await request.json()

    // Check for admin authentication token in headers
    const adminAuth = request.headers.get("x-admin-auth")
    if (adminAuth !== "true") {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Extract transaction data
    const { type, id, status } = body

    if (!type || !id || !status) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    // Validate transaction type
    if (type !== "deposits" && type !== "withdrawals") {
      return NextResponse.json({ error: "Invalid transaction type" }, { status: 400 })
    }

    // Validate status
    if (status !== "completed" && status !== "failed") {
      return NextResponse.json({ error: "Invalid status" }, { status: 400 })
    }

    // Get the transaction details
    const { data: transaction, error: fetchError } = await supabaseAdmin
      .from(type)
      .select("*, user:profiles(username, is_active, balance)")
      .eq("id", id)
      .single()

    if (fetchError) {
      console.error(`Failed to fetch ${type}:`, fetchError)
      return NextResponse.json({ error: `Failed to fetch ${type}: ${fetchError.message}` }, { status: 500 })
    }

    if (!transaction) {
      return NextResponse.json({ error: `Transaction not found` }, { status: 404 })
    }

    if (transaction.status !== "pending") {
      return NextResponse.json({ error: `This transaction has already been ${transaction.status}` }, { status: 400 })
    }

    console.log(`Processing ${type} transaction:`, transaction)

    // Update transaction status
    const { error: updateError } = await supabaseAdmin
      .from(type)
      .update({
        status: status,
        updated_at: new Date().toISOString(),
      })
      .eq("id", id)

    if (updateError) {
      console.error(`Failed to update ${type}:`, updateError)
      return NextResponse.json({ error: `Failed to update ${type}: ${updateError.message}` }, { status: 500 })
    }

    // Get payment method safely (handle both field names)
    const paymentMethod = transaction.method || transaction.payment_method || "unknown"

    // Handle specific actions based on transaction type and status
    if (type === "deposits" && status === "completed") {
      // For deposits: Add amount to user's balance
      const shouldActivate = transaction.amount >= 50 && !transaction.user.is_active
      const currentBalance = transaction.user.balance || 0
      const newBalance = currentBalance + transaction.amount

      console.log(`Updating user balance: ${currentBalance} + ${transaction.amount} = ${newBalance}`)
      console.log(`Should activate account: ${shouldActivate}`)

      // Update user balance and activate account if needed
      const { error: balanceError } = await supabaseAdmin
        .from("profiles")
        .update({
          balance: newBalance,
          is_active: shouldActivate ? true : transaction.user.is_active,
        })
        .eq("id", transaction.user_id)

      if (balanceError) {
        console.error(`Failed to update user balance:`, balanceError)
        return NextResponse.json({ error: `Failed to update user balance: ${balanceError.message}` }, { status: 500 })
      }

      // Log the activity
      await supabaseAdmin.from("activity_log").insert([
        {
          user_id: transaction.user_id,
          activity_type: "deposit_approved",
          description: `Your deposit of ${transaction.amount}৳ has been approved`,
          metadata: {
            transaction_id: id,
            amount: transaction.amount,
            method: paymentMethod,
            approved_via: "admin_panel",
          },
        },
      ])
    } else if (type === "deposits" && status === "failed") {
      // For deposits: Just log the declined activity
      await supabaseAdmin.from("activity_log").insert([
        {
          user_id: transaction.user_id,
          activity_type: "deposit_declined",
          description: `Your deposit of ${transaction.amount}৳ has been declined`,
          metadata: {
            transaction_id: id,
            amount: transaction.amount,
            method: paymentMethod,
            declined_via: "admin_panel",
          },
        },
      ])
    } else if (type === "withdrawals" && status === "completed") {
      // For withdrawals: Just log the activity (amount already deducted)
      await supabaseAdmin.from("activity_log").insert([
        {
          user_id: transaction.user_id,
          activity_type: "withdrawal_approved",
          description: `Your withdrawal of ${transaction.amount}৳ has been approved`,
          metadata: {
            transaction_id: id,
            amount: transaction.amount,
            method: paymentMethod,
            approved_via: "admin_panel",
          },
        },
      ])
    } else if (type === "withdrawals" && status === "failed") {
      // If withdrawal is declined, refund the amount to user's balance
      const currentBalance = transaction.user.balance || 0
      const newBalance = currentBalance + transaction.amount

      console.log(`Refunding withdrawal: ${currentBalance} + ${transaction.amount} = ${newBalance}`)

      const { error: refundError } = await supabaseAdmin
        .from("profiles")
        .update({
          balance: newBalance,
        })
        .eq("id", transaction.user_id)

      if (refundError) {
        console.error(`Failed to refund user balance:`, refundError)
        return NextResponse.json({ error: `Failed to refund user balance: ${refundError.message}` }, { status: 500 })
      }

      // Log the declined withdrawal
      await supabaseAdmin.from("activity_log").insert([
        {
          user_id: transaction.user_id,
          activity_type: "withdrawal_declined",
          description: `Your withdrawal of ${transaction.amount}৳ has been declined. The amount has been refunded to your balance.`,
          metadata: {
            transaction_id: id,
            amount: transaction.amount,
            method: paymentMethod,
            declined_via: "admin_panel",
          },
        },
      ])
    }

    // Send notification via Telegram
    try {
      // Create a sanitized transaction object for the notification
      const notificationTransaction = {
        ...transaction,
        status: status,
        updated_at: new Date().toISOString(),
        // Ensure method field exists for notification
        method: paymentMethod,
      }

      await fetch("/api/telegram-notify", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          table: type,
          record: {
            new: notificationTransaction,
          },
        }),
      })
    } catch (error) {
      console.error("Error sending Telegram notification:", error)
      // Continue even if Telegram notification fails
    }

    return NextResponse.json({
      success: true,
      message: `Transaction ${status} successfully`,
      transaction: {
        ...transaction,
        status: status,
        updated_at: new Date().toISOString(),
      },
    })
  } catch (error: any) {
    console.error("Error in transaction update API:", error)
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}
