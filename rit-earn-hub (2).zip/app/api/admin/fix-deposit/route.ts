import { NextResponse } from "next/server"
import { createClient } from "@supabase/supabase-js"

// Initialize Supabase client with admin privileges using service role key
const supabaseAdmin = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL || "",
  process.env.SUPABASE_SERVICE_ROLE_KEY || "",
  {
    auth: {
      persistSession: false,
      autoRefreshToken: false,
    },
  },
)

export async function POST(request: Request) {
  try {
    // Parse the request body
    const body = await request.json()
    console.log("Processing deposit request:", body)

    // Extract transaction data
    const { id, status } = body

    if (!id || !status) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    // Validate status
    if (status !== "completed" && status !== "failed") {
      return NextResponse.json({ error: "Invalid status" }, { status: 400 })
    }

    // Get the deposit details
    const { data: deposit, error: fetchError } = await supabaseAdmin.from("deposits").select("*").eq("id", id).single()

    if (fetchError) {
      console.error("Failed to fetch deposit:", fetchError)
      return NextResponse.json({ error: `Failed to fetch deposit: ${fetchError.message}` }, { status: 500 })
    }

    if (!deposit) {
      return NextResponse.json({ error: "Deposit not found" }, { status: 404 })
    }

    if (deposit.status !== "pending") {
      return NextResponse.json({ error: `This deposit has already been ${deposit.status}` }, { status: 400 })
    }

    // Get user details
    const { data: userData, error: userError } = await supabaseAdmin
      .from("profiles")
      .select("username, is_active, balance")
      .eq("id", deposit.user_id)
      .single()

    if (userError) {
      console.error("Failed to fetch user data:", userError)
      return NextResponse.json({ error: `Failed to fetch user data: ${userError.message}` }, { status: 500 })
    }

    // Update deposit status
    const { error: updateError } = await supabaseAdmin
      .from("deposits")
      .update({
        status: status,
        updated_at: new Date().toISOString(),
      })
      .eq("id", id)

    if (updateError) {
      console.error("Failed to update deposit:", updateError)
      return NextResponse.json({ error: `Failed to update deposit: ${updateError.message}` }, { status: 500 })
    }

    // Get payment method (handle both field names)
    const paymentMethod = deposit.method || deposit.payment_method || "unknown"

    // Handle specific actions based on status
    if (status === "completed") {
      // Add amount to user's balance
      const shouldActivate = deposit.amount >= 50 && !userData.is_active
      const currentBalance = Number.parseFloat(userData.balance) || 0
      const newBalance = currentBalance + Number.parseFloat(deposit.amount)

      console.log(`Updating user balance: ${currentBalance} + ${deposit.amount} = ${newBalance}`)
      console.log(`Should activate account: ${shouldActivate}`)
      console.log(`User activation status before update: ${userData.is_active}`)

      // Update user balance and activate account if needed
      const updateData = {
        balance: newBalance,
        updated_at: new Date().toISOString(),
      }

      // Only update activation status if deposit amount is sufficient
      if (shouldActivate) {
        updateData.is_active = true
      }

      console.log("Updating profile with data:", updateData)

      const { error: balanceError } = await supabaseAdmin.from("profiles").update(updateData).eq("id", deposit.user_id)

      if (balanceError) {
        console.error("Failed to update user balance:", balanceError)
        return NextResponse.json({ error: `Failed to update user balance: ${balanceError.message}` }, { status: 500 })
      }

      console.log(`User balance updated successfully from ${currentBalance} to ${newBalance}`)
      if (shouldActivate) {
        console.log(`User account activated: ${deposit.user_id}`)
      }

      // Log the activity
      await supabaseAdmin.from("activity_log").insert([
        {
          user_id: deposit.user_id,
          activity_type: "deposit_approved",
          description: `Your deposit of ${deposit.amount}৳ has been approved${shouldActivate ? " and your account has been activated" : ""}`,
          metadata: {
            transaction_id: id,
            amount: deposit.amount,
            method: paymentMethod,
            approved_via: "admin_panel",
            account_activated: shouldActivate,
          },
        },
      ])
    } else if (status === "failed") {
      // Log the declined deposit
      await supabaseAdmin.from("activity_log").insert([
        {
          user_id: deposit.user_id,
          activity_type: "deposit_declined",
          description: `Your deposit of ${deposit.amount}৳ has been declined`,
          metadata: {
            transaction_id: id,
            amount: deposit.amount,
            method: paymentMethod,
            declined_via: "admin_panel",
          },
        },
      ])
    }

    // Send notification via Telegram (simplified approach)
    try {
      console.log("Sending Telegram notification")

      // Get user's username
      const username = userData.username || "unknown"

      // Create a simple message for Telegram
      const message = `
Deposit ${status.toUpperCase()}:
Amount: ${deposit.amount}৳
User: @${username}
Method: ${paymentMethod}
ID: ${id}
      `

      // Send a direct message to Telegram
      const BOT_TOKEN = "7825284153:AAEKbga9rIBOUnSL2ndRrO6Hl1HsxS1EV7w"
      const CHAT_ID = "6880722176"

      const TELEGRAM_API_URL = `https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`

      const telegramResponse = await fetch(TELEGRAM_API_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          chat_id: CHAT_ID,
          text: message,
        }),
      })

      if (!telegramResponse.ok) {
        const telegramError = await telegramResponse.json()
        console.error("Telegram notification error:", telegramError)
      } else {
        console.log("Telegram notification sent successfully")
      }
    } catch (error) {
      console.error("Error sending Telegram notification:", error)
      // Continue even if Telegram notification fails
    }

    return NextResponse.json({
      success: true,
      message: `Deposit ${status} successfully`,
      deposit: {
        ...deposit,
        status: status,
        updated_at: new Date().toISOString(),
      },
    })
  } catch (error: any) {
    console.error("Error in deposit processing API:", error)
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}
