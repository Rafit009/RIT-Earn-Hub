import { NextResponse } from "next/server"
import { createClient } from "@supabase/supabase-js"

// Initialize Supabase admin client with service role key
const supabaseAdmin = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL || "",
  process.env.SUPABASE_SERVICE_ROLE_KEY || "",
  {
    auth: {
      persistSession: false,
      autoRefreshToken: false,
    },
  },
)

export async function POST(request: Request) {
  try {
    // Check for admin authentication token in headers
    const adminAuth = request.headers.get("x-admin-auth")
    if (adminAuth !== "true") {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Add missing columns to user_tasks table
    const addStartedAtColumn = await supabaseAdmin.rpc("execute_sql", {
      sql_query: `
        DO $$
        BEGIN
          IF NOT EXISTS (
            SELECT 1 
            FROM information_schema.columns 
            WHERE table_name = 'user_tasks' 
            AND column_name = 'started_at'
          ) THEN
            ALTER TABLE user_tasks ADD COLUMN started_at TIMESTAMP WITH TIME ZONE;
          END IF;
        END $$;
      `,
    })

    const addSubmissionDateColumn = await supabaseAdmin.rpc("execute_sql", {
      sql_query: `
        DO $$
        BEGIN
          IF NOT EXISTS (
            SELECT 1 
            FROM information_schema.columns 
            WHERE table_name = 'user_tasks' 
            AND column_name = 'submission_date'
          ) THEN
            ALTER TABLE user_tasks ADD COLUMN submission_date TIMESTAMP WITH TIME ZONE;
          END IF;
        END $$;
      `,
    })

    const addSubmissionDetailsColumn = await supabaseAdmin.rpc("execute_sql", {
      sql_query: `
        DO $$
        BEGIN
          IF NOT EXISTS (
            SELECT 1 
            FROM information_schema.columns 
            WHERE table_name = 'user_tasks' 
            AND column_name = 'submission_details'
          ) THEN
            ALTER TABLE user_tasks ADD COLUMN submission_details TEXT;
          END IF;
        END $$;
      `,
    })

    const addAdminApprovedColumn = await supabaseAdmin.rpc("execute_sql", {
      sql_query: `
        DO $$
        BEGIN
          IF NOT EXISTS (
            SELECT 1 
            FROM information_schema.columns 
            WHERE table_name = 'user_tasks' 
            AND column_name = 'admin_approved'
          ) THEN
            ALTER TABLE user_tasks ADD COLUMN admin_approved BOOLEAN DEFAULT false;
          END IF;
        END $$;
      `,
    })

    // Check for errors
    if (
      addStartedAtColumn.error ||
      addSubmissionDateColumn.error ||
      addSubmissionDetailsColumn.error ||
      addAdminApprovedColumn.error
    ) {
      const errors = [
        addStartedAtColumn.error,
        addSubmissionDateColumn.error,
        addSubmissionDetailsColumn.error,
        addAdminApprovedColumn.error,
      ].filter(Boolean)

      return NextResponse.json({ error: "Error updating schema", details: errors }, { status: 500 })
    }

    return NextResponse.json({
      success: true,
      message: "Database schema updated successfully",
    })
  } catch (error: any) {
    console.error("Error in fix database schema API:", error)
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}
