import { NextResponse } from "next/server"
import { createClient } from "@supabase/supabase-js"

// Initialize Supabase client with admin privileges using service role key
const supabaseAdmin = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL || "",
  process.env.SUPABASE_SERVICE_ROLE_KEY || "",
  {
    auth: {
      persistSession: false,
      autoRefreshToken: false,
    },
  },
)

export async function GET(request: Request) {
  try {
    // Check for admin authentication token in headers
    const adminAuth = request.headers.get("x-admin-auth")
    if (adminAuth !== "true") {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Get the transaction type from query params
    const { searchParams } = new URL(request.url)
    const type = searchParams.get("type") || "deposits"
    const id = searchParams.get("id")

    if (id) {
      // Fetch specific transaction
      const { data, error } = await supabaseAdmin
        .from(type)
        .select(`
          *,
          user:profiles(id, username, is_active, balance)
        `)
        .eq("id", id)
        .single()

      if (error) {
        return NextResponse.json({ error: error.message }, { status: 500 })
      }

      return NextResponse.json({ transaction: data })
    } else {
      // Fetch all transactions
      const { data, error } = await supabaseAdmin
        .from(type)
        .select(`
          *,
          user:profiles(id, username, is_active, balance)
        `)
        .order("created_at", { ascending: false })

      if (error) {
        return NextResponse.json({ error: error.message }, { status: 500 })
      }

      return NextResponse.json({ transactions: data })
    }
  } catch (error: any) {
    console.error("Error in debug transactions API:", error)
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}
