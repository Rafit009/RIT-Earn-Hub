import { type NextRequest, NextResponse } from "next/server"
import { createClient } from "@supabase/supabase-js"
import { initializeDatabase } from "@/lib/database-schema"

// Initialize Supabase client with service role key for admin operations
const supabaseAdmin = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!, {
  auth: {
    autoRefreshToken: false,
    persistSession: false,
  },
})

export async function POST(request: NextRequest) {
  try {
    // Check if user is admin
    const { data: session } = await supabaseAdmin.auth.getSession()

    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { data: user } = await supabaseAdmin
      .from("profiles")
      .select("role")
      .eq("id", session.session?.user.id)
      .single()

    if (!user || user.role !== "admin") {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Run database initialization
    const success = await initializeDatabase()

    if (success) {
      return NextResponse.json({
        success: true,
        message: "Database schema fixed successfully",
      })
    } else {
      return NextResponse.json({ success: false, message: "Failed to fix database schema" }, { status: 500 })
    }
  } catch (error) {
    console.error("Error fixing database schema:", error)
    return NextResponse.json({ success: false, message: "An unexpected error occurred" }, { status: 500 })
  }
}
