import { NextResponse } from "next/server"
import { createClient } from "@supabase/supabase-js"

// Initialize Supabase client with admin privileges using service role key
const supabaseAdmin = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL || "",
  process.env.SUPABASE_SERVICE_ROLE_KEY || "",
  {
    auth: {
      persistSession: false,
      autoRefreshToken: false,
    },
  },
)

export async function POST(request: Request) {
  try {
    // Parse the request body
    const body = await request.json()

    // Check for admin authentication token in headers
    const adminAuth = request.headers.get("x-admin-auth")
    if (adminAuth !== "true") {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Extract task data
    const { title, description, reward, completion_limit } = body

    // Validate inputs
    if (!title || !description || !reward) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    // Create new task using admin client that bypasses RLS
    const { data, error } = await supabaseAdmin
      .from("tasks")
      .insert([
        {
          title,
          description,
          reward: Number(reward),
          completion_limit: completion_limit || null,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        },
      ])
      .select()

    if (error) {
      console.error("Error creating task:", error)
      return NextResponse.json({ error: error.message }, { status: 500 })
    }

    return NextResponse.json({ success: true, data })
  } catch (error: any) {
    console.error("Error in task creation API:", error)
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}

export async function PUT(request: Request) {
  try {
    // Parse the request body
    const body = await request.json()

    // Check for admin authentication token in headers
    const adminAuth = request.headers.get("x-admin-auth")
    if (adminAuth !== "true") {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Extract task data
    const { id, title, description, reward, completion_limit, is_closed } = body

    // Validate inputs
    if (!id || !title || !description || !reward) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    // Update task using admin client that bypasses RLS
    const { data, error } = await supabaseAdmin
      .from("tasks")
      .update({
        title,
        description,
        reward: Number(reward),
        completion_limit: completion_limit || null,
        is_closed: is_closed || false,
        updated_at: new Date().toISOString(),
      })
      .eq("id", id)
      .select()

    if (error) {
      console.error("Error updating task:", error)
      return NextResponse.json({ error: error.message }, { status: 500 })
    }

    return NextResponse.json({ success: true, data })
  } catch (error: any) {
    console.error("Error in task update API:", error)
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}

export async function DELETE(request: Request) {
  try {
    // Get the task ID from the URL
    const { searchParams } = new URL(request.url)
    const id = searchParams.get("id")

    // Check for admin authentication token in headers
    const adminAuth = request.headers.get("x-admin-auth")
    if (adminAuth !== "true") {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Validate inputs
    if (!id) {
      return NextResponse.json({ error: "Task ID is required" }, { status: 400 })
    }

    // Delete task using admin client that bypasses RLS
    const { error } = await supabaseAdmin.from("tasks").delete().eq("id", id)

    if (error) {
      console.error("Error deleting task:", error)
      return NextResponse.json({ error: error.message }, { status: 500 })
    }

    return NextResponse.json({ success: true })
  } catch (error: any) {
    console.error("Error in task deletion API:", error)
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}
