import { NextResponse } from "next/server"
import { createClient } from "@supabase/supabase-js"

// Initialize Supabase client with admin privileges using service role key
const supabaseAdmin = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL || "",
  process.env.SUPABASE_SERVICE_ROLE_KEY || "",
  {
    auth: {
      persistSession: false,
      autoRefreshToken: false,
    },
  },
)

export async function POST(request: Request) {
  try {
    // Check for admin authentication token in headers
    const adminAuth = request.headers.get("x-admin-auth")
    if (adminAuth !== "true") {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Extract SQL query from request body
    const { query } = await request.json()

    if (!query) {
      return NextResponse.json({ error: "SQL query is required" }, { status: 400 })
    }

    // Execute SQL query
    const { data, error } = await supabaseAdmin.rpc("exec_sql", { sql: query })

    if (error) {
      console.error("Error executing SQL:", error)
      return NextResponse.json({ error: error.message }, { status: 500 })
    }

    return NextResponse.json({
      success: true,
      message: "SQL query executed successfully",
      data,
    })
  } catch (error: any) {
    console.error("Error in SQL API:", error)
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}
