import { NextResponse } from "next/server"
import { createServerComponentClient } from "@supabase/auth-helpers-nextjs"
import { cookies } from "next/headers"

export async function GET(request: Request) {
  try {
    // Get the user ID from the query params
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get("userId")

    if (!userId) {
      return NextResponse.json({ error: "User ID is required" }, { status: 400 })
    }

    // Create a Supabase client with server-side auth
    const supabase = createServerComponentClient({ cookies })

    // Verify the user is authenticated and matches the requested userId
    const {
      data: { session },
    } = await supabase.auth.getSession()

    if (!session || session.user.id !== userId) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Get user's profile data
    const { data: profileData, error: profileError } = await supabase
      .from("profiles")
      .select("username, referral_count, referral_earnings, referral_code")
      .eq("id", userId)
      .single()

    if (profileError) {
      return NextResponse.json({ error: profileError.message }, { status: 500 })
    }

    // Fetch referrals with a more reliable approach
    const { data: referralsData, error: referralsError } = await supabase
      .from("referrals")
      .select("id, referred_id, created_at, status, reward")
      .eq("referrer_id", userId)
      .order("created_at", { ascending: false })

    if (referralsError) {
      return NextResponse.json({ error: referralsError.message }, { status: 500 })
    }

    // For each referral, fetch the referred user's details from profiles table
    const referralsWithUserDetails = await Promise.all(
      referralsData.map(async (referral) => {
        const { data: userData, error: userError } = await supabase
          .from("profiles")
          .select("username, full_name, email, is_active")
          .eq("id", referral.referred_id)
          .single()

        if (userError) {
          console.error("Error fetching user details:", userError)
          return {
            ...referral,
            referred_username: "Unknown",
            referred_fullname: "Unknown User",
            referred_email: "unknown@example.com",
            status: referral.status || "pending",
            reward: referral.reward || 5.0, // Default reward value if not present
          }
        }

        return {
          ...referral,
          referred_username: userData.username || "Unknown",
          referred_fullname: userData.full_name || "Unknown User",
          referred_email: userData.email || "unknown@example.com",
          status: referral.status || (userData.is_active ? "active" : "pending"),
          reward: referral.reward || 5.0, // Default reward value if not present
        }
      }),
    )

    // Calculate stats
    const activeReferrals = referralsWithUserDetails.filter((r) => r.status === "active").length
    const pendingReferrals = referralsWithUserDetails.filter((r) => r.status === "pending").length

    // Use the count from the database for total_count
    const totalCount = profileData.referral_count || referralsWithUserDetails.length

    // Use referral_earnings from profile if available, otherwise calculate from referrals
    const totalEarnings =
      profileData.referral_earnings || referralsWithUserDetails.reduce((sum, item) => sum + (item.reward || 0), 0)

    const stats = {
      total_count: totalCount,
      total_earnings: totalEarnings,
      active_referrals: activeReferrals,
      pending_referrals: pendingReferrals,
      referral_code: profileData.referral_code,
      username: profileData.username,
    }

    return NextResponse.json({
      stats,
      referrals: referralsWithUserDetails,
    })
  } catch (error: any) {
    console.error("Error in referrals API:", error)
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}
