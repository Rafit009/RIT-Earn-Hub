import { NextResponse } from "next/server"
import { createClient } from "@supabase/supabase-js"
import { cookies } from "next/headers"

export async function POST(request: Request) {
  try {
    const { voucherCode } = await request.json()

    if (!voucherCode) {
      return NextResponse.json({ error: "Voucher code is required" }, { status: 400 })
    }

    // Create Supabase client
    const cookieStore = cookies()
    const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!, {
      cookies: {
        get(name: string) {
          return cookieStore.get(name)?.value
        },
        set(name: string, value: string, options: any) {
          cookieStore.set({ name, value, ...options })
        },
        remove(name: string, options: any) {
          cookieStore.set({ name, value: "", ...options })
        },
      },
    })

    // Get the current user
    const {
      data: { session },
    } = await supabase.auth.getSession()

    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Check voucher validity
    const { data, error } = await supabase.rpc("check_voucher_validity", {
      voucher_code: voucherCode,
      user_id: session.user.id,
    })

    if (error) {
      console.error("Error checking voucher validity:", error)
      return NextResponse.json({ error: error.message }, { status: 500 })
    }

    if (!data || !data[0] || !data[0].is_valid) {
      return NextResponse.json({
        valid: false,
        message: data && data[0] ? data[0].message : "Invalid voucher code",
      })
    }

    return NextResponse.json({
      valid: true,
      message: data[0].message,
      amount: data[0].amount,
    })
  } catch (error: any) {
    console.error("Error in validate voucher API:", error)
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}
