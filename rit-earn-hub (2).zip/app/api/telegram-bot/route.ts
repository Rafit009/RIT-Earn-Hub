import { NextResponse } from "next/server"
import { createClient } from "@supabase/supabase-js"

// Initialize Supabase client with admin privileges
const supabaseAdmin = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL || "",
  process.env.SUPABASE_SERVICE_ROLE_KEY || "",
  {
    auth: {
      persistSession: false,
      autoRefreshToken: false,
    },
  },
)

// Telegram Bot configuration
const BOT_TOKEN = "7825284153:AAEKbga9rIBOUnSL2ndRrO6Hl1HsxS1EV7w"
const ADMIN_CHAT_ID = "6880722176"

export async function POST(request: Request) {
  try {
    const body = await request.json()
    console.log("Telegram Bot webhook received:", JSON.stringify(body))

    // Handle different types of updates from Telegram
    if (body.callback_query) {
      // Handle button callbacks (approve/decline actions)
      return handleCallbackQuery(body.callback_query)
    } else if (body.message) {
      // Handle direct messages to the bot
      return handleMessage(body.message)
    }

    return NextResponse.json({ status: "No action taken" })
  } catch (error: any) {
    console.error("Error in Telegram Bot webhook:", error)
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}

async function handleMessage(message: any) {
  // Only respond to messages from the admin
  if (message.chat.id.toString() !== ADMIN_CHAT_ID) {
    return NextResponse.json({ status: "Unauthorized" }, { status: 403 })
  }

  const chatId = message.chat.id
  const text = message.text || ""

  if (text === "/start") {
    await sendTelegramMessage(
      chatId,
      "Welcome to RIT Earn Hub Admin Bot! You will receive notifications about deposit and withdrawal requests here.",
    )
  } else if (text === "/pending") {
    // Fetch and display pending transactions
    await sendPendingTransactions(chatId)
  } else {
    await sendTelegramMessage(
      chatId,
      "Available commands:\n/start - Start the bot\n/pending - View pending transactions",
    )
  }

  return NextResponse.json({ status: "Message handled" })
}

async function handleCallbackQuery(callbackQuery: any) {
  const chatId = callbackQuery.message.chat.id
  const messageId = callbackQuery.message.message_id
  const data = callbackQuery.data
  const callbackId = callbackQuery.id

  console.log("Processing callback query:", { chatId, messageId, data, callbackId })

  // Only allow actions from the admin
  if (chatId.toString() !== ADMIN_CHAT_ID) {
    await answerCallbackQuery(callbackId, "Unauthorized: Only admins can perform this action")
    return NextResponse.json({ status: "Unauthorized" }, { status: 403 })
  }

  // Parse the callback data
  // Format: action:type:id (e.g., approve:deposit:123456)
  const [action, type, id] = data.split(":")

  if (!action || !type || !id) {
    await answerCallbackQuery(callbackId, "Invalid action format")
    await sendTelegramMessage(chatId, "Invalid action format")
    return NextResponse.json({ status: "Invalid action format" }, { status: 400 })
  }

  try {
    // Answer the callback query first to prevent Telegram timeout
    await answerCallbackQuery(callbackId, `Processing ${action} for ${type}...`)

    if (action === "approve") {
      await approveTransaction(type, id, chatId, messageId)
    } else if (action === "decline") {
      await declineTransaction(type, id, chatId, messageId)
    } else {
      await sendTelegramMessage(chatId, "Unknown action")
    }

    return NextResponse.json({ status: "Action processed" })
  } catch (error: any) {
    console.error(`Error processing ${action} for ${type} ${id}:`, error)
    await sendTelegramMessage(chatId, `Error: ${error.message}`)
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}

async function approveTransaction(type: string, id: string, chatId: number | string, messageId: number) {
  console.log(`Approving ${type} with ID ${id}`)

  // Normalize the type to match the table name
  const tableName =
    type === "deposit"
      ? "deposits"
      : type === "deposits"
        ? "deposits"
        : type === "withdrawal"
          ? "withdrawals"
          : "withdrawals"

  // Get the transaction details
  const { data: transaction, error: fetchError } = await supabaseAdmin.from(tableName).select("*").eq("id", id).single()

  if (fetchError) {
    console.error(`Failed to fetch ${tableName}:`, fetchError)
    throw new Error(`Failed to fetch ${type}: ${fetchError.message}`)
  }

  if (!transaction) {
    throw new Error(`${type.charAt(0).toUpperCase() + type.slice(1, -1)} not found`)
  }

  if (transaction.status !== "pending") {
    await updateTelegramMessage(
      chatId,
      messageId,
      `This ${type.slice(0, -1)} has already been ${transaction.status}`,
      [],
    )
    return
  }

  console.log(`Transaction found:`, transaction)

  // Get user details
  const { data: userData, error: userError } = await supabaseAdmin
    .from("profiles")
    .select("username, is_active, balance")
    .eq("id", transaction.user_id)
    .single()

  if (userError) {
    console.error(`Failed to fetch user data:`, userError)
    throw new Error(`Failed to fetch user data: ${userError.message}`)
  }

  // Update transaction status
  const { error: updateError } = await supabaseAdmin
    .from(tableName)
    .update({
      status: "completed",
      updated_at: new Date().toISOString(),
    })
    .eq("id", id)

  if (updateError) {
    console.error(`Failed to update ${tableName}:`, updateError)
    throw new Error(`Failed to update ${type}: ${updateError.message}`)
  }

  console.log(`Transaction status updated to completed`)

  // Get payment method safely (handle both field names)
  const paymentMethod = transaction.method || transaction.payment_method || "unknown"

  // Handle specific actions based on transaction type
  if (tableName === "deposits") {
    // For deposits: Add amount to user's balance
    const shouldActivate = transaction.amount >= 50 && !userData.is_active
    const currentBalance = Number.parseFloat(userData.balance) || 0
    const newBalance = currentBalance + Number.parseFloat(transaction.amount)

    console.log(`Updating user balance: ${currentBalance} + ${transaction.amount} = ${newBalance}`)
    console.log(`Should activate account: ${shouldActivate}`)
    console.log(`User activation status before update: ${userData.is_active}`)

    // Update user balance and activate account if needed
    const updateData = {
      balance: newBalance,
      updated_at: new Date().toISOString(),
    }

    // Only update activation status if deposit amount is sufficient
    if (shouldActivate) {
      updateData.is_active = true
    }

    console.log("Updating profile with data:", updateData)

    const { error: balanceError } = await supabaseAdmin
      .from("profiles")
      .update(updateData)
      .eq("id", transaction.user_id)

    if (balanceError) {
      console.error(`Failed to update user balance:`, balanceError)
      throw new Error(`Failed to update user balance: ${balanceError.message}`)
    }

    console.log(`User balance updated successfully from ${currentBalance} to ${newBalance}`)
    if (shouldActivate) {
      console.log(`User account activated: ${transaction.user_id}`)
    }

    // Log the activity
    await supabaseAdmin.from("activity_log").insert([
      {
        user_id: transaction.user_id,
        activity_type: "deposit_approved",
        description: `Your deposit of ${transaction.amount}৳ has been approved${shouldActivate ? " and your account has been activated" : ""}`,
        metadata: {
          transaction_id: id,
          amount: transaction.amount,
          method: paymentMethod,
          approved_via: "telegram_bot",
          account_activated: shouldActivate,
        },
      },
    ])
  } else if (tableName === "withdrawals") {
    // For withdrawals: Just log the activity (amount already deducted)
    await supabaseAdmin.from("activity_log").insert([
      {
        user_id: transaction.user_id,
        activity_type: "withdrawal_approved",
        description: `Your withdrawal of ${transaction.amount}৳ has been approved`,
        metadata: {
          transaction_id: id,
          amount: transaction.amount,
          method: paymentMethod,
          approved_via: "telegram_bot",
        },
      },
    ])

    console.log(`Activity log created for withdrawal approval`)
  }

  // Update the Telegram message to show it's been approved
  await updateTelegramMessage(
    chatId,
    messageId,
    `✅ ${tableName === "deposits" ? "DEPOSIT" : "WITHDRAWAL"} APPROVED

Amount: ${transaction.amount}৳
User: @${userData.username}
Method: ${paymentMethod}
ID: ${id}`,
    [],
  )

  console.log(`Telegram message updated with approval confirmation`)
}

async function declineTransaction(type: string, id: string, chatId: number | string, messageId: number) {
  console.log(`Declining ${type} with ID ${id}`)

  // Normalize the type to match the table name
  const tableName =
    type === "deposit"
      ? "deposits"
      : type === "deposits"
        ? "deposits"
        : type === "withdrawal"
          ? "withdrawals"
          : "withdrawals"

  // Get the transaction details
  const { data: transaction, error: fetchError } = await supabaseAdmin.from(tableName).select("*").eq("id", id).single()

  if (fetchError) {
    console.error(`Failed to fetch ${tableName}:`, fetchError)
    throw new Error(`Failed to fetch ${type}: ${fetchError.message}`)
  }

  if (!transaction) {
    throw new Error(`${type.charAt(0).toUpperCase() + type.slice(1, -1)} not found`)
  }

  if (transaction.status !== "pending") {
    await updateTelegramMessage(
      chatId,
      messageId,
      `This ${type.slice(0, -1)} has already been ${transaction.status}`,
      [],
    )
    return
  }

  // Get user details
  const { data: userData, error: userError } = await supabaseAdmin
    .from("profiles")
    .select("username, balance")
    .eq("id", transaction.user_id)
    .single()

  if (userError) {
    console.error(`Failed to fetch user data:`, userError)
    throw new Error(`Failed to fetch user data: ${userError.message}`)
  }

  console.log(`Transaction found:`, transaction)

  // Update transaction status
  const { error: updateError } = await supabaseAdmin
    .from(tableName)
    .update({
      status: "failed",
      updated_at: new Date().toISOString(),
    })
    .eq("id", id)

  if (updateError) {
    console.error(`Failed to update ${tableName}:`, updateError)
    throw new Error(`Failed to update ${type}: ${updateError.message}`)
  }

  console.log(`Transaction status updated to failed`)

  // Get payment method safely (handle both field names)
  const paymentMethod = transaction.method || transaction.payment_method || "unknown"

  // Handle specific actions based on transaction type
  if (tableName === "deposits") {
    // For deposits: Just log the declined activity
    await supabaseAdmin.from("activity_log").insert([
      {
        user_id: transaction.user_id,
        activity_type: "deposit_declined",
        description: `Your deposit of ${transaction.amount}৳ has been declined`,
        metadata: {
          transaction_id: id,
          amount: transaction.amount,
          method: paymentMethod,
          declined_via: "telegram_bot",
        },
      },
    ])

    console.log(`Activity log created for deposit decline`)
  } else if (tableName === "withdrawals") {
    // For withdrawals: Refund the amount to user's balance
    const currentBalance = userData.balance || 0
    const newBalance = currentBalance + transaction.amount

    console.log(`Refunding withdrawal: ${currentBalance} + ${transaction.amount} = ${newBalance}`)

    const { error: refundError } = await supabaseAdmin
      .from("profiles")
      .update({
        balance: newBalance,
      })
      .eq("id", transaction.user_id)

    if (refundError) {
      console.error(`Failed to refund user balance:`, refundError)
      throw new Error(`Failed to refund user balance: ${refundError.message}`)
    }

    console.log(`User balance refunded for declined withdrawal`)

    // Log the declined withdrawal
    await supabaseAdmin.from("activity_log").insert([
      {
        user_id: transaction.user_id,
        activity_type: "withdrawal_declined",
        description: `Your withdrawal of ${transaction.amount}৳ has been declined. The amount has been refunded to your balance.`,
        metadata: {
          transaction_id: id,
          amount: transaction.amount,
          method: paymentMethod,
          declined_via: "telegram_bot",
        },
      },
    ])

    console.log(`Activity log created for withdrawal decline`)
  }

  // Update the Telegram message to show it's been declined
  await updateTelegramMessage(
    chatId,
    messageId,
    `❌ ${tableName === "deposits" ? "DEPOSIT" : "WITHDRAWAL"} DECLINED

Amount: ${transaction.amount}৳
User: @${userData.username}
Method: ${paymentMethod}
ID: ${id}`,
    [],
  )

  console.log(`Telegram message updated with decline confirmation`)
}

async function sendPendingTransactions(chatId: number | string) {
  try {
    // Fetch pending deposits
    const { data: pendingDeposits, error: depositsError } = await supabaseAdmin
      .from("deposits")
      .select("*, user:profiles(username)")
      .eq("status", "pending")
      .order("created_at", { ascending: false })

    if (depositsError) {
      throw depositsError
    }

    // Fetch pending withdrawals
    const { data: pendingWithdrawals, error: withdrawalsError } = await supabaseAdmin
      .from("withdrawals")
      .select("*, user:profiles(username)")
      .eq("status", "pending")
      .order("created_at", { ascending: false })

    if (withdrawalsError) {
      throw withdrawalsError
    }

    // Send message with pending transactions
    if (pendingDeposits.length === 0 && pendingWithdrawals.length === 0) {
      await sendTelegramMessage(chatId, "No pending transactions found.")
      return
    }

    // Send deposits
    if (pendingDeposits.length > 0) {
      await sendTelegramMessage(chatId, `📥 *PENDING DEPOSITS (${pendingDeposits.length})*`, "MarkdownV2")

      for (const deposit of pendingDeposits) {
        await sendTransactionMessage(chatId, deposit, "deposits")
      }
    }

    // Send withdrawals
    if (pendingWithdrawals.length > 0) {
      await sendTelegramMessage(chatId, `📤 *PENDING WITHDRAWALS (${pendingWithdrawals.length})*`, "MarkdownV2")

      for (const withdrawal of pendingWithdrawals) {
        await sendTransactionMessage(chatId, withdrawal, "withdrawals")
      }
    }
  } catch (error: any) {
    console.error("Error fetching pending transactions:", error)
    await sendTelegramMessage(chatId, `Error fetching pending transactions: ${error.message}`)
  }
}

async function sendTransactionMessage(chatId: number | string, transaction: any, type: string) {
  // Get payment method and phone number safely (handle field name inconsistencies)
  const method = transaction.method || transaction.payment_method || "N/A"
  const phone = transaction.mobile_number || transaction.phone_number || "N/A"
  const transactionId = transaction.transaction_id || "N/A"
  const formattedDate = new Date(transaction.created_at).toLocaleString()

  const message = `
${type === "deposits" ? "📥 DEPOSIT" : "📤 WITHDRAWAL"} REQUEST

Amount: ${transaction.amount}৳
User: @${transaction.user.username}
Method: ${method}
Phone: ${phone}
${type === "deposits" ? `Transaction ID: ${transactionId}` : ""}
Date: ${formattedDate}
ID: ${transaction.id}
`

  const inlineKeyboard = {
    inline_keyboard: [
      [
        {
          text: "✅ Approve",
          callback_data: `approve:${type}:${transaction.id}`,
        },
        {
          text: "❌ Decline",
          callback_data: `decline:${type}:${transaction.id}`,
        },
      ],
    ],
  }

  await sendTelegramMessage(chatId, message, undefined, inlineKeyboard)
}

async function sendTelegramMessage(chatId: number | string, text: string, parse_mode?: string, reply_markup?: any) {
  const TELEGRAM_API_URL = `https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`

  const response = await fetch(TELEGRAM_API_URL, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      chat_id: chatId,
      text: text,
      parse_mode: parse_mode,
      reply_markup: reply_markup,
    }),
  })

  if (!response.ok) {
    const errorData = await response.json()
    console.error("Telegram API error:", errorData)
    throw new Error(`Telegram API error: ${JSON.stringify(errorData)}`)
  }

  return await response.json()
}

async function updateTelegramMessage(
  chatId: number | string,
  messageId: number,
  text: string,
  reply_markup: any = null,
) {
  const TELEGRAM_API_URL = `https://api.telegram.org/bot${BOT_TOKEN}/editMessageText`

  const response = await fetch(TELEGRAM_API_URL, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      chat_id: chatId,
      message_id: messageId,
      text: text,
      reply_markup: reply_markup.length === 0 ? undefined : { inline_keyboard: reply_markup },
    }),
  })

  if (!response.ok) {
    const errorData = await response.json()
    console.error("Telegram API error:", errorData)
    throw new Error(`Telegram API error: ${JSON.stringify(errorData)}`)
  }

  return await response.json()
}

// Add a function to answer callback queries
async function answerCallbackQuery(callbackQueryId: string, text = "") {
  const TELEGRAM_API_URL = `https://api.telegram.org/bot${BOT_TOKEN}/answerCallbackQuery`

  const response = await fetch(TELEGRAM_API_URL, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      callback_query_id: callbackQueryId,
      text: text,
    }),
  })

  if (!response.ok) {
    const errorData = await response.json()
    console.error("Telegram API error:", errorData)
    throw new Error(`Telegram API error: ${JSON.stringify(errorData)}`)
  }

  return await response.json()
}

// GET handler for setting up the webhook
export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const setupWebhook = searchParams.get("setup") === "true"

    if (setupWebhook) {
      // Get the base URL from the request
      const baseUrl = new URL(request.url).origin
      const webhookUrl = `${baseUrl}/api/telegram-bot`

      // Set the webhook URL for the Telegram Bot
      const TELEGRAM_API_URL = `https://api.telegram.org/bot${BOT_TOKEN}/setWebhook`
      const response = await fetch(TELEGRAM_API_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          url: webhookUrl,
          allowed_updates: ["message", "callback_query"],
        }),
      })

      const data = await response.json()
      return NextResponse.json(data)
    }

    return NextResponse.json({ status: "OK", message: "Telegram Bot API is running" })
  } catch (error: any) {
    console.error("Error in GET handler:", error)
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}
