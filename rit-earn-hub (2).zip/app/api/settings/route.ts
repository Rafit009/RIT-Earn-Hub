import { createRouteHandlerClient } from "@supabase/auth-helpers-nextjs"
import { cookies } from "next/headers"
import { type NextRequest, NextResponse } from "next/server"

// GET endpoint to fetch public settings
export async function GET(req: NextRequest) {
  try {
    const supabase = createRouteHandlerClient({ cookies })

    // Fetch only public settings
    const { data, error } = await supabase
      .from("settings")
      .select("key, value")
      .in("key", ["platform_name", "currency_symbol", "min_deposit", "min_withdrawal", "maintenance_mode"])

    if (error) {
      console.error("Error fetching public settings:", error)
      return NextResponse.json({ error: "Failed to fetch settings" }, { status: 500 })
    }

    // Transform data into a more usable format
    const formattedSettings = data.reduce((acc: Record<string, any>, setting) => {
      acc[setting.key] = setting.value
      return acc
    }, {})

    return NextResponse.json(formattedSettings)
  } catch (error) {
    console.error("Unexpected error in public settings GET:", error)
    return NextResponse.json({ error: "An unexpected error occurred" }, { status: 500 })
  }
}
