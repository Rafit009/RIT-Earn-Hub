import { NextResponse } from "next/server"
import { initializeDatabase } from "@/lib/database-schema"

// This route will be called on application startup
export async function GET() {
  try {
    const success = await initializeDatabase()

    if (success) {
      return NextResponse.json({ success: true, message: "Database initialized successfully" })
    } else {
      return NextResponse.json({ success: false, message: "Failed to initialize database" }, { status: 500 })
    }
  } catch (error) {
    console.error("Error in init route:", error)
    return NextResponse.json({ success: false, message: "An unexpected error occurred" }, { status: 500 })
  }
}
