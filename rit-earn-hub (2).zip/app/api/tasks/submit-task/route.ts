import { type NextRequest, NextResponse } from "next/server"
import { createClient } from "@supabase/supabase-js"

// Initialize Supabase client with service role key for admin operations
const supabaseAdmin = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!, {
  auth: {
    autoRefreshToken: false,
    persistSession: false,
  },
})

export async function POST(request: NextRequest) {
  try {
    const { taskId, userId, submissionDetails } = await request.json()

    if (!taskId || !userId) {
      return NextResponse.json({ error: "Task ID and User ID are required" }, { status: 400 })
    }

    // Check if task is closed or has reached completion limit
    const { data: taskData, error: taskError } = await supabaseAdmin
      .from("tasks")
      .select("is_closed, completion_limit")
      .eq("id", taskId)
      .single()

    if (taskError) {
      console.error("Error checking task status:", taskError)
      return NextResponse.json({ error: "Failed to check task status" }, { status: 500 })
    }

    if (taskData.is_closed) {
      return NextResponse.json({ error: "This task is no longer available for completion" }, { status: 400 })
    }

    // If task has a completion limit, check if it's been reached
    if (taskData.completion_limit !== null) {
      const { count, error: countError } = await supabaseAdmin
        .from("user_tasks")
        .select("*", { count: "exact" })
        .eq("task_id", taskId)
        .eq("status", "completed")

      if (countError) {
        console.error("Error counting completed tasks:", countError)
        return NextResponse.json({ error: "Failed to check completion count" }, { status: 500 })
      }

      if (count >= taskData.completion_limit) {
        // Update task to closed if limit reached
        await supabaseAdmin.from("tasks").update({ is_closed: true }).eq("id", taskId)

        return NextResponse.json({ error: "This task has reached its maximum number of completions" }, { status: 400 })
      }
    }

    // Check if user has started this task
    const { data: existingTask, error: checkError } = await supabaseAdmin
      .from("user_tasks")
      .select("*")
      .eq("user_id", userId)
      .eq("task_id", taskId)
      .single()

    if (checkError) {
      console.error("Error checking existing task:", checkError)
      return NextResponse.json({ error: "Failed to check existing task" }, { status: 500 })
    }

    if (!existingTask) {
      return NextResponse.json({ error: "You need to start this task first" }, { status: 400 })
    }

    if (existingTask.status === "submitted" || existingTask.status === "completed") {
      return NextResponse.json({ error: "This task has already been submitted" }, { status: 400 })
    }

    // Update task status to submitted
    const { error: updateError } = await supabaseAdmin
      .from("user_tasks")
      .update({
        status: "submitted",
        submission_date: new Date().toISOString(),
        submission_details: submissionDetails || "Task completed",
      })
      .eq("user_id", userId)
      .eq("task_id", taskId)

    if (updateError) {
      console.error("Error submitting task:", updateError)
      return NextResponse.json({ error: "Failed to submit task" }, { status: 500 })
    }

    // Add activity log
    const { data: taskInfo } = await supabaseAdmin.from("tasks").select("title, reward").eq("id", taskId).single()

    if (taskInfo) {
      await supabaseAdmin.from("activities").insert({
        user_id: userId,
        type: "task_submitted",
        description: `Submitted task: ${taskInfo.title}`,
        amount: taskInfo.reward,
        status: "pending",
      })
    }

    return NextResponse.json({
      success: true,
      message: "Task submitted successfully and sent for review",
    })
  } catch (error) {
    console.error("Error in submit-task API:", error)
    return NextResponse.json({ error: "An unexpected error occurred" }, { status: 500 })
  }
}
