import { type NextRequest, NextResponse } from "next/server"
import { createClient } from "@supabase/supabase-js"

// Initialize Supabase client with service role key for admin operations
const supabaseAdmin = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!, {
  auth: {
    autoRefreshToken: false,
    persistSession: false,
  },
})

export async function POST(request: NextRequest) {
  try {
    const { taskId, userId } = await request.json()

    if (!taskId || !userId) {
      return NextResponse.json({ error: "Task ID and User ID are required" }, { status: 400 })
    }

    // Check if task is closed or has reached completion limit
    const { data: taskData, error: taskError } = await supabaseAdmin
      .from("tasks")
      .select("is_closed, completion_limit")
      .eq("id", taskId)
      .single()

    if (taskError) {
      console.error("Error checking task status:", taskError)
      return NextResponse.json({ error: "Failed to check task status" }, { status: 500 })
    }

    if (taskData.is_closed) {
      return NextResponse.json({ error: "This task is no longer available for completion" }, { status: 400 })
    }

    // If task has a completion limit, check if it's been reached
    if (taskData.completion_limit !== null) {
      const { count, error: countError } = await supabaseAdmin
        .from("user_tasks")
        .select("*", { count: "exact" })
        .eq("task_id", taskId)
        .eq("status", "completed")

      if (countError) {
        console.error("Error counting completed tasks:", countError)
        return NextResponse.json({ error: "Failed to check completion count" }, { status: 500 })
      }

      if (count >= taskData.completion_limit) {
        // Update task to closed if limit reached
        await supabaseAdmin.from("tasks").update({ is_closed: true }).eq("id", taskId)

        return NextResponse.json({ error: "This task has reached its maximum number of completions" }, { status: 400 })
      }
    }

    // Check if user has already started or completed this task
    const { data: existingTask, error: checkError } = await supabaseAdmin
      .from("user_tasks")
      .select("*")
      .eq("user_id", userId)
      .eq("task_id", taskId)
      .single()

    if (!checkError && existingTask) {
      return NextResponse.json({
        success: true,
        message: "Task already started",
        task: existingTask,
      })
    }

    // Create new user_task record
    const { data: newTask, error: createError } = await supabaseAdmin
      .from("user_tasks")
      .insert({
        user_id: userId,
        task_id: taskId,
        status: "pending",
        started_at: new Date().toISOString(),
      })
      .select()
      .single()

    if (createError) {
      console.error("Error starting task:", createError)
      return NextResponse.json({ error: "Failed to start task" }, { status: 500 })
    }

    return NextResponse.json({
      success: true,
      message: "Task started successfully",
      task: newTask,
    })
  } catch (error) {
    console.error("Error in start-task API:", error)
    return NextResponse.json({ error: "An unexpected error occurred" }, { status: 500 })
  }
}
