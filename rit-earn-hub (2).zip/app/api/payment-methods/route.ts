import { createRouteHandlerClient } from "@supabase/auth-helpers-nextjs"
import { cookies } from "next/headers"
import { NextResponse } from "next/server"

export async function GET(request: Request) {
  try {
    const supabase = createRouteHandlerClient({ cookies })

    // Get query parameters
    const url = new URL(request.url)
    const forDeposit = url.searchParams.get("for_deposit") === "true"
    const forWithdrawal = url.searchParams.get("for_withdrawal") === "true"

    // Build query
    let query = supabase.from("payment_methods").select("*").eq("is_active", true)

    // Add filters if specified
    if (forDeposit) {
      query = query.eq("for_deposit", true)
    }

    if (forWithdrawal) {
      query = query.eq("for_withdrawal", true)
    }

    // Execute query
    const { data, error } = await query.order("display_name")

    if (error) {
      console.error("Error fetching payment methods:", error)
      return NextResponse.json({ error: error.message }, { status: 500 })
    }

    return NextResponse.json(data)
  } catch (error: any) {
    console.error("Unexpected error in payment methods API:", error)
    return NextResponse.json({ error: "An unexpected error occurred" }, { status: 500 })
  }
}
