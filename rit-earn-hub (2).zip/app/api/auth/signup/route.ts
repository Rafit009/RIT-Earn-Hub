import { createRouteHandlerClient } from "@supabase/auth-helpers-nextjs"
import { cookies } from "next/headers"
import { NextResponse } from "next/server"
import { createClient } from "@supabase/supabase-js"
import { ensureUserProfile, generateReferralCode } from "@/lib/user-helpers"

export async function POST(request: Request) {
  try {
    const requestUrl = new URL(request.url)
    const formData = await request.json()
    const email = formData.email
    const password = formData.password
    const name = formData.name
    const phone = formData.phone
    const referralCode = formData.referralCode

    console.log("Processing signup for:", { email, name, phone, hasReferral: !!referralCode })

    // Regular supabase client with user permissions
    const supabase = createRouteHandlerClient({ cookies })

    // Create the user account
    const { data: authData, error: authError } = await supabase.auth.signUp({
      email,
      password,
      options: {
        emailRedirectTo: `${requestUrl.origin}/auth/callback`,
      },
    })

    if (authError) {
      console.error("Auth error during signup:", authError)
      return NextResponse.json({ error: authError.message }, { status: 400 })
    }

    // Get the user ID from the auth response
    const userId = authData.user?.id

    if (!userId) {
      console.error("No user ID returned from auth signup")
      return NextResponse.json({ error: "User creation failed" }, { status: 400 })
    }

    // Create a service role client to bypass RLS
    const supabaseAdmin = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!)

    // Generate a unique referral code
    const userReferralCode = generateReferralCode(name)

    // Find referrer if referral code provided
    let referrerId = null
    if (referralCode) {
      // Find the referrer
      const { data: referrerData, error: referrerError } = await supabaseAdmin
        .from("profiles")
        .select("id")
        .eq("referral_code", referralCode)
        .single()

      if (!referrerError && referrerData) {
        referrerId = referrerData.id
      }
    }

    // Ensure user profile exists
    const { success: profileSuccess, error: profileError } = await ensureUserProfile(userId, {
      username: name.toLowerCase().replace(/\s+/g, "_"),
      fullName: name,
      email,
      referralCode: userReferralCode,
      referredBy: referrerId,
    })

    if (!profileSuccess) {
      console.error("Profile creation error:", profileError)
      return NextResponse.json({ error: profileError.message }, { status: 400 })
    }

    // If referrer was found, create referral record and apply bonuses immediately
    if (referrerId) {
      // Create the referral record
      const { error: referralError } = await supabaseAdmin.from("referrals").insert({
        referrer_id: referrerId,
        referred_id: userId,
        status: "pending", // Will be updated to 'active' after bonus is applied
        reward: 35.0,
        created_at: new Date().toISOString(),
      })

      if (referralError) {
        console.error("Referral tracking error:", referralError)
        // Continue with signup even if referral tracking fails
      } else {
        // Apply the immediate referral bonuses
        const { data: bonusResult, error: bonusError } = await supabaseAdmin.rpc("apply_immediate_referral_bonus", {
          referred_user_id: userId,
          referrer_id: referrerId,
        })

        if (bonusError) {
          console.error("Error applying referral bonuses:", bonusError)
          // Continue with signup even if bonus application fails
        } else {
          console.log("Referral bonuses applied successfully:", bonusResult)
        }
      }
    }

    return NextResponse.json({
      message: "Signup successful. Please check your email to verify your account.",
      user: authData.user,
    })
  } catch (error: any) {
    console.error("Unexpected signup error:", error)
    return NextResponse.json({ error: "An unexpected error occurred" }, { status: 500 })
  }
}
