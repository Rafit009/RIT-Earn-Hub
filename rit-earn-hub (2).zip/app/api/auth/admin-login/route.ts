import { NextResponse } from "next/server"
import { cookies } from "next/headers"
import { createServerClient } from "@supabase/ssr"
import type { Database } from "@/types/supabase"

export async function POST(request: Request) {
  try {
    const { email, password } = await request.json()

    // Create Supabase server client
    const cookieStore = cookies()
    const supabase = createServerClient<Database>(
      process.env.NEXT_PUBLIC_SUPABASE_URL!,
      process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
      {
        cookies: {
          get(name: string) {
            return cookieStore.get(name)?.value
          },
          set(name: string, value: string, options: any) {
            cookieStore.set({ name, value, ...options })
          },
          remove(name: string, options: any) {
            cookieStore.set({ name, value: "", ...options })
          },
        },
      },
    )

    // Sign in with email and password
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password,
    })

    if (error) {
      return NextResponse.json({ error: error.message }, { status: 400 })
    }

    // Check if user is an admin
    const { data: userData, error: userError } = await supabase
      .from("users")
      .select("role")
      .eq("id", data.user.id)
      .single()

    if (userError) {
      // Sign out if there was an error checking the role
      await supabase.auth.signOut()
      return NextResponse.json({ error: "Authentication failed" }, { status: 401 })
    }

    if (userData.role !== "admin") {
      // Sign out if the user is not an admin
      await supabase.auth.signOut()
      return NextResponse.json({ error: "Unauthorized: Admin access required" }, { status: 403 })
    }

    return NextResponse.json({
      message: "Admin login successful",
      user: {
        id: data.user.id,
        email: data.user.email,
        role: userData.role,
      },
    })
  } catch (error: any) {
    return NextResponse.json({ error: error.message || "Internal server error" }, { status: 500 })
  }
}
