import { NextResponse } from "next/server"

export async function POST(request: Request) {
  try {
    const body = await request.json()
    console.log("Received webhook payload:", JSON.stringify(body))

    const { record } = body
    const transaction = record?.new

    // Verify the transaction data exists
    if (!transaction) {
      console.error("Invalid transaction data:", body)
      return NextResponse.json({ error: "Invalid transaction data" }, { status: 400 })
    }

    // Use the provided bot token and chat ID
    const BOT_TOKEN = "7825284153:AAEKbga9rIBOUnSL2ndRrO6Hl1HsxS1EV7w"
    const CHAT_ID = "6880722176"

    // Determine transaction type (deposit or withdrawal)
    // Check the table name if available in the record
    let transactionType = "UNKNOWN"
    let tableType = "unknown"

    if (body.table) {
      // If table name is directly provided
      transactionType = body.table === "withdrawals" ? "WITHDRAWAL" : "DEPOSIT"
      tableType = body.table
    } else {
      // Otherwise try to determine from the transaction properties
      // For withdrawals, we typically have method/payment_method but no transaction_id initially
      // Also check if this is coming from the withdrawals table based on specific fields
      if (transaction.hasOwnProperty("method") && !transaction.hasOwnProperty("transaction_id")) {
        transactionType = "WITHDRAWAL"
        tableType = "withdrawals"
      } else if (transaction.hasOwnProperty("transaction_id")) {
        transactionType = "DEPOSIT"
        tableType = "deposits"
      } else {
        // Additional check: if amount is negative, it's likely a withdrawal
        transactionType = transaction.amount < 0 ? "WITHDRAWAL" : "DEPOSIT"
        tableType = transaction.amount < 0 ? "withdrawals" : "deposits"
      }
    }

    console.log(`Processing ${transactionType} notification, table: ${tableType}`)

    // Get user details
    const userResponse = await fetch(
      `${process.env.NEXT_PUBLIC_SUPABASE_URL}/rest/v1/profiles?id=eq.${transaction.user_id}&select=username,full_name,email,mobile_number`,
      {
        headers: {
          "Content-Type": "application/json",
          apikey: process.env.SUPABASE_SERVICE_ROLE_KEY || "",
          Authorization: `Bearer ${process.env.SUPABASE_SERVICE_ROLE_KEY}`,
        },
      },
    )

    const userData = await userResponse.json()
    console.log("User data:", userData)

    const user = userData[0] || { username: "Unknown", full_name: "Unknown User", email: "unknown@example.com" }

    // Format date
    const formattedDate = new Date(transaction.created_at).toLocaleString("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    })

    // Handle potentially missing fields - ensure we have values for all fields
    const paymentMethod = transaction.method || transaction.payment_method || "N/A"
    const mobileNumber = transaction.mobile_number || transaction.phone_number || user.mobile_number || "N/A"
    const transactionId = transaction.transaction_id || "N/A"
    const amount = Math.abs(transaction.amount || 0)
    const status = (transaction.status || "PENDING").toUpperCase()

    // Create a detailed message
    const message = `
💰 New ${transactionType} Request 💰

👤 User: ${user.full_name || user.username} (@${user.username || "unknown"})
📧 Email: ${user.email || "N/A"}
🆔 User ID: ${transaction.user_id}
💵 Amount: ${amount} Taka
🏦 Method: ${paymentMethod}
📱 Mobile: ${mobileNumber}
🔢 Transaction ID: ${transactionId}
📊 Status: ${status}
⏰ Time: ${formattedDate}
🔑 Transaction ID: ${transaction.id}
`

    console.log("Sending message to Telegram:", message)

    const TELEGRAM_API_URL = `https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`

    // Add inline keyboard for actions if the status is pending
    const inlineKeyboard =
      status === "PENDING"
        ? {
            inline_keyboard: [
              [
                {
                  text: "✅ Approve",
                  callback_data: `approve:${tableType}:${transaction.id}`,
                },
                {
                  text: "❌ Decline",
                  callback_data: `decline:${tableType}:${transaction.id}`,
                },
              ],
            ],
          }
        : undefined

    const telegramResponse = await fetch(TELEGRAM_API_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        chat_id: CHAT_ID,
        text: message,
        reply_markup: inlineKeyboard,
      }),
    })

    const telegramData = await telegramResponse.json()
    console.log("Telegram API response:", telegramData)

    if (!telegramResponse.ok) {
      console.error("Telegram API error:", telegramData)
      return NextResponse.json(
        { error: "Failed to send Telegram notification", details: telegramData },
        { status: 500 },
      )
    }

    return NextResponse.json({
      success: true,
      message: "Notification Sent",
    })
  } catch (error) {
    console.error("Error sending notification:", error)
    return NextResponse.json({ error: "Internal Server Error", details: error }, { status: 500 })
  }
}
