import { NextResponse } from "next/server"

export async function GET(request: Request) {
  try {
    // Use the provided bot token and chat ID
    const BOT_TOKEN = "7825284153:AAEKbga9rIBOUnSL2ndRrO6Hl1HsxS1EV7w"
    const CHAT_ID = "6880722176"

    // Create a test message
    const message =
      `🧪 Test Notification 🧪\n\n` +
      `This is a test message to verify that the Telegram notification system is working correctly.\n\n` +
      `⏰ Time: ${new Date().toLocaleString()}`

    const TELEGRAM_API_URL = `https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`

    const telegramResponse = await fetch(TELEGRAM_API_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        chat_id: CHAT_ID,
        text: message,
        parse_mode: "Markdown",
      }),
    })

    if (!telegramResponse.ok) {
      const errorData = await telegramResponse.json()
      console.error("Telegram API error:", errorData)
      return NextResponse.json({ error: "Failed to send Telegram notification", details: errorData }, { status: 500 })
    }

    return NextResponse.json({
      success: true,
      message: "Test notification sent successfully",
    })
  } catch (error) {
    console.error("Error sending test notification:", error)
    return NextResponse.json({ error: "Internal Server Error", details: error }, { status: 500 })
  }
}
