import { NextResponse } from "next/server"

export async function GET(request: Request) {
  try {
    // Use the provided bot token and chat ID
    const BOT_TOKEN = "7825284153:AAEKbga9rIBOUnSL2ndRrO6Hl1HsxS1EV7w"
    const CHAT_ID = "6880722176"

    // Create a test message with buttons
    const message =
      "🧪 Test Telegram Bot Buttons 🧪\n\nThis is a test message to verify that the Telegram bot buttons are working correctly."

    const TELEGRAM_API_URL = `https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`

    const telegramResponse = await fetch(TELEGRAM_API_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        chat_id: CHAT_ID,
        text: message,
        reply_markup: {
          inline_keyboard: [
            [
              {
                text: "✅ Test Approve",
                callback_data: "test:approve:123",
              },
              {
                text: "❌ Test Decline",
                callback_data: "test:decline:123",
              },
            ],
          ],
        },
      }),
    })

    if (!telegramResponse.ok) {
      const errorData = await telegramResponse.json()
      console.error("Telegram API error:", errorData)
      return NextResponse.json({ error: "Failed to send Telegram test message", details: errorData }, { status: 500 })
    }

    const data = await telegramResponse.json()
    return NextResponse.json({
      success: true,
      message: "Test message with buttons sent successfully",
      response: data,
    })
  } catch (error) {
    console.error("Error sending test message:", error)
    return NextResponse.json({ error: "Internal Server Error", details: error }, { status: 500 })
  }
}
