import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Link from "next/link"

export default function MaintenancePage() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-100 p-4">
      <Card className="max-w-md w-full">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl">Maintenance Mode</CardTitle>
          <CardDescription>We're currently performing maintenance on our platform.</CardDescription>
        </CardHeader>
        <CardContent className="flex flex-col items-center">
          <div className="mb-6 text-center">
            <p className="mb-4">
              We apologize for the inconvenience. Our team is working to improve your experience. Please check back
              later.
            </p>
            <p className="text-sm text-muted-foreground">
              If you're an administrator, please log in to access the platform.
            </p>
          </div>
          <Link href="/admin-login">
            <Button>Admin Login</Button>
          </Link>
        </CardContent>
      </Card>
    </div>
  )
}
