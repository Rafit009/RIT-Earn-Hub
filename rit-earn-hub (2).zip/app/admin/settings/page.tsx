"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { ArrowLeft, Save, RefreshCw, Trash2, Plus } from "lucide-react"
import Link from "next/link"
import { LoadingSpinner } from "@/components/loading-spinner"
import { Switch } from "@/components/ui/switch"
import { createClientComponentClient } from "@supabase/auth-helpers-nextjs"
import { z } from "zod"
import { Textarea } from "@/components/ui/textarea"

// Define validation schema
const settingsSchema = z.object({
  platform_name: z.string().min(1, "Platform name is required"),
  admin_email: z.string().email("Invalid email address"),
  deposit_fee: z.number().min(0, "Must be 0 or greater").max(100, "Must be 100 or less"),
  withdrawal_fee: z.number().min(0, "Must be 0 or greater").max(100, "Must be 100 or less"),
  min_deposit: z.number().min(1, "Must be at least 1"),
  min_withdrawal: z.number().min(1, "Must be at least 1"),
  referral_bonus: z.number().min(0, "Must be 0 or greater"),
  referred_bonus: z.number().min(0, "Must be 0 or greater"),
  activation_amount: z.number().min(1, "Must be at least 1"),
  maintenance_mode: z.boolean(),
  currency_symbol: z.string().min(1, "Currency symbol is required"),
})

type Settings = z.infer<typeof settingsSchema>

interface PaymentMethod {
  id: string
  name: string
  display_name: string
  account_number: string
  instructions: string
  is_active: boolean
  for_deposit: boolean
  for_withdrawal: boolean
}

export default function AdminSettings() {
  const router = useRouter()
  const supabase = createClientComponentClient()
  const [loading, setLoading] = useState(false)
  const [saving, setSaving] = useState(false)
  const [message, setMessage] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [validationErrors, setValidationErrors] = useState<Record<string, string>>({})
  const [isAdmin, setIsAdmin] = useState(false)
  const [checkingAdmin, setCheckingAdmin] = useState(true)
  const [settings, setSettings] = useState<Settings>({
    platform_name: "RIT Earn Hub",
    admin_email: "admin@ritearnhub.com",
    deposit_fee: 0,
    withdrawal_fee: 0,
    min_deposit: 50,
    min_withdrawal: 50,
    referral_bonus: 35,
    referred_bonus: 10,
    activation_amount: 50,
    maintenance_mode: false,
    currency_symbol: "৳",
  })

  const [paymentMethods, setPaymentMethods] = useState<PaymentMethod[]>([])
  const [newPaymentMethod, setNewPaymentMethod] = useState<Omit<PaymentMethod, "id">>({
    name: "",
    display_name: "",
    account_number: "",
    instructions: "",
    is_active: true,
    for_deposit: true,
    for_withdrawal: true,
  })
  const [addingPaymentMethod, setAddingPaymentMethod] = useState(false)

  // Check admin status
  useEffect(() => {
    const checkAdminStatus = async () => {
      try {
        // First check if admin is authenticated via localStorage (for client-side only)
        const adminAuthenticated = localStorage.getItem("adminAuthenticated") === "true"

        if (adminAuthenticated) {
          setIsAdmin(true)
          setCheckingAdmin(false)
          fetchSettings()
          fetchPaymentMethods()
          return
        }

        // If not authenticated via localStorage, check with Supabase
        const {
          data: { user },
        } = await supabase.auth.getUser()

        if (!user) {
          router.push("/admin-login")
          return
        }

        const { data: profile, error: profileError } = await supabase
          .from("profiles")
          .select("is_admin")
          .eq("id", user.id)
          .single()

        if (profileError) {
          console.error("Error fetching profile:", profileError)
          router.push("/admin-login")
          return
        }

        if (!profile?.is_admin) {
          router.push("/admin-login")
          return
        }

        // If we get here, user is an admin
        localStorage.setItem("adminAuthenticated", "true")
        setIsAdmin(true)
        setCheckingAdmin(false)
        fetchSettings()
        fetchPaymentMethods()
      } catch (err) {
        console.error("Error checking admin status:", err)
        router.push("/admin-login")
      }
    }

    checkAdminStatus()
  }, [router, supabase])

  // Fetch settings
  const fetchSettings = async () => {
    try {
      setLoading(true)
      setError(null)

      const response = await fetch("/api/admin/settings", {
        // Add cache: 'no-store' to prevent caching
        cache: "no-store",
        headers: {
          "Cache-Control": "no-cache",
        },
      })

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.error || "Failed to fetch settings")
      }

      const data = await response.json()

      // Convert string values to appropriate types
      const formattedSettings = {
        platform_name: data.platform_name || "RIT Earn Hub",
        admin_email: data.admin_email || "admin@ritearnhub.com",
        deposit_fee: Number(data.deposit_fee || 0),
        withdrawal_fee: Number(data.withdrawal_fee || 0),
        min_deposit: Number(data.min_deposit || 50),
        min_withdrawal: Number(data.min_withdrawal || 50),
        referral_bonus: Number(data.referral_bonus || 35),
        referred_bonus: Number(data.referred_bonus || 10),
        activation_amount: Number(data.activation_amount || 50),
        maintenance_mode: data.maintenance_mode === true || data.maintenance_mode === "true",
        currency_symbol: data.currency_symbol || "৳",
      }

      setSettings(formattedSettings)
    } catch (err: any) {
      console.error("Error fetching settings:", err)
      setError(err.message || "Failed to load settings")
    } finally {
      setLoading(false)
    }
  }

  const fetchPaymentMethods = async () => {
    try {
      setLoading(true)

      const { data, error } = await supabase.from("payment_methods").select("*").order("created_at")

      if (error) throw error

      setPaymentMethods(data || [])
    } catch (err: any) {
      console.error("Error fetching payment methods:", err)
      setError(err.message || "Failed to load payment methods")
    } finally {
      setLoading(false)
    }
  }

  // Handle input change
  const handleChange = (key: keyof Settings, value: any) => {
    setSettings((prev) => ({
      ...prev,
      [key]: value,
    }))

    // Clear validation error for this field if it exists
    if (validationErrors[key]) {
      setValidationErrors((prev) => {
        const newErrors = { ...prev }
        delete newErrors[key]
        return newErrors
      })
    }
  }

  // Save settings
  const handleSave = async () => {
    try {
      // Validate settings
      const result = settingsSchema.safeParse(settings)

      if (!result.success) {
        const formattedErrors: Record<string, string> = {}
        result.error.errors.forEach((err) => {
          formattedErrors[err.path[0] as string] = err.message
        })
        setValidationErrors(formattedErrors)
        return
      }

      setSaving(true)
      setMessage(null)
      setError(null)

      const response = await fetch("/api/admin/settings", {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(settings),
      })

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.error || "Failed to save settings")
      }

      setMessage("Settings saved successfully!")

      // Clear message after 3 seconds
      setTimeout(() => {
        setMessage(null)
      }, 3000)
    } catch (err: any) {
      console.error("Error saving settings:", err)
      setError(err.message || "Failed to save settings")
    } finally {
      setSaving(false)
    }
  }

  const handlePaymentMethodChange = (index: number, field: keyof PaymentMethod, value: any) => {
    const updatedMethods = [...paymentMethods]
    updatedMethods[index] = {
      ...updatedMethods[index],
      [field]: value,
    }
    setPaymentMethods(updatedMethods)
  }

  const handleNewPaymentMethodChange = (field: keyof Omit<PaymentMethod, "id">, value: any) => {
    setNewPaymentMethod({
      ...newPaymentMethod,
      [field]: value,
    })
  }

  const savePaymentMethod = async (index: number) => {
    try {
      setSaving(true)
      const method = paymentMethods[index]

      const { error } = await supabase
        .from("payment_methods")
        .update({
          name: method.name,
          display_name: method.display_name,
          account_number: method.account_number,
          instructions: method.instructions,
          is_active: method.is_active,
          for_deposit: method.for_deposit,
          for_withdrawal: method.for_withdrawal,
          updated_at: new Date().toISOString(),
        })
        .eq("id", method.id)

      if (error) throw error

      setMessage("Payment method updated successfully!")

      // Clear message after 3 seconds
      setTimeout(() => {
        setMessage(null)
      }, 3000)
    } catch (err: any) {
      console.error("Error updating payment method:", err)
      setError(err.message || "Failed to update payment method")
    } finally {
      setSaving(false)
    }
  }

  const addPaymentMethod = async () => {
    try {
      setSaving(true)

      // Validate required fields
      if (!newPaymentMethod.name || !newPaymentMethod.display_name || !newPaymentMethod.account_number) {
        throw new Error("Name, display name, and account number are required")
      }

      const { error } = await supabase.from("payment_methods").insert([
        {
          name: newPaymentMethod.name.toLowerCase().replace(/\s+/g, "_"),
          display_name: newPaymentMethod.display_name,
          account_number: newPaymentMethod.account_number,
          instructions: newPaymentMethod.instructions,
          is_active: newPaymentMethod.is_active,
          for_deposit: newPaymentMethod.for_deposit,
          for_withdrawal: newPaymentMethod.for_withdrawal,
        },
      ])

      if (error) throw error

      setMessage("Payment method added successfully!")

      // Reset form and refresh payment methods
      setNewPaymentMethod({
        name: "",
        display_name: "",
        account_number: "",
        instructions: "",
        is_active: true,
        for_deposit: true,
        for_withdrawal: true,
      })
      setAddingPaymentMethod(false)
      fetchPaymentMethods()

      // Clear message after 3 seconds
      setTimeout(() => {
        setMessage(null)
      }, 3000)
    } catch (err: any) {
      console.error("Error adding payment method:", err)
      setError(err.message || "Failed to add payment method")
    } finally {
      setSaving(false)
    }
  }

  const deletePaymentMethod = async (id: string) => {
    if (!confirm("Are you sure you want to delete this payment method? This action cannot be undone.")) {
      return
    }

    try {
      setSaving(true)

      const { error } = await supabase.from("payment_methods").delete().eq("id", id)

      if (error) throw error

      setMessage("Payment method deleted successfully!")

      // Refresh payment methods
      fetchPaymentMethods()

      // Clear message after 3 seconds
      setTimeout(() => {
        setMessage(null)
      }, 3000)
    } catch (err: any) {
      console.error("Error deleting payment method:", err)
      setError(err.message || "Failed to delete payment method")
    } finally {
      setSaving(false)
    }
  }

  if (checkingAdmin) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <LoadingSpinner size="lg" />
      </div>
    )
  }

  if (!isAdmin) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded mb-6">
          <p className="font-medium">Access Denied</p>
          <p>You do not have permission to access this page.</p>
        </div>
        <Button onClick={() => (window.location.href = "/dashboard")} className="mt-4">
          Return to Dashboard
        </Button>
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <Link href="/admin" className="inline-flex items-center text-primary hover:underline">
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Admin Dashboard
        </Link>
        <h1 className="text-3xl font-bold mt-2">Platform Settings</h1>
        <p className="text-muted-foreground">Configure platform settings, fees, and other parameters</p>
      </div>

      {message && (
        <Alert className="mb-6 bg-green-50 border-green-200 text-green-700">
          <AlertDescription>{message}</AlertDescription>
        </Alert>
      )}

      {error && (
        <Alert variant="destructive" className="mb-6">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      <div className="flex justify-end mb-4">
        <Button variant="outline" onClick={fetchSettings} disabled={loading} className="mr-2">
          <RefreshCw className={`h-4 w-4 mr-2 ${loading ? "animate-spin" : ""}`} />
          Refresh
        </Button>
        <Button onClick={handleSave} disabled={saving || loading}>
          <Save className="h-4 w-4 mr-2" />
          {saving ? "Saving..." : "Save Changes"}
        </Button>
      </div>

      {loading ? (
        <div className="flex justify-center py-12">
          <LoadingSpinner size="lg" />
        </div>
      ) : (
        <>
          <Card className="max-w-2xl mx-auto mb-8">
            <CardHeader>
              <CardTitle>General Settings</CardTitle>
              <CardDescription>Configure general platform settings</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="platform_name">Platform Name</Label>
                <Input
                  id="platform_name"
                  value={settings.platform_name}
                  onChange={(e) => handleChange("platform_name", e.target.value)}
                  error={validationErrors.platform_name}
                />
                {validationErrors.platform_name && (
                  <p className="text-sm text-red-500">{validationErrors.platform_name}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="admin_email">Admin Email</Label>
                <Input
                  id="admin_email"
                  type="email"
                  value={settings.admin_email}
                  onChange={(e) => handleChange("admin_email", e.target.value)}
                  error={validationErrors.admin_email}
                />
                {validationErrors.admin_email && <p className="text-sm text-red-500">{validationErrors.admin_email}</p>}
              </div>

              <div className="space-y-2">
                <Label htmlFor="currency_symbol">Currency Symbol</Label>
                <Input
                  id="currency_symbol"
                  value={settings.currency_symbol}
                  onChange={(e) => handleChange("currency_symbol", e.target.value)}
                  error={validationErrors.currency_symbol}
                />
                {validationErrors.currency_symbol && (
                  <p className="text-sm text-red-500">{validationErrors.currency_symbol}</p>
                )}
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="maintenance_mode">Maintenance Mode</Label>
                  <p className="text-sm text-muted-foreground">When enabled, only admins can access the platform</p>
                </div>
                <Switch
                  id="maintenance_mode"
                  checked={settings.maintenance_mode}
                  onCheckedChange={(checked) => handleChange("maintenance_mode", checked)}
                />
              </div>
            </CardContent>
          </Card>

          <Card className="max-w-2xl mx-auto mb-8">
            <CardHeader>
              <CardTitle>Fees and Limits</CardTitle>
              <CardDescription>Configure fees and limits for transactions</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="deposit_fee">Deposit Fee (%)</Label>
                <Input
                  id="deposit_fee"
                  type="number"
                  value={settings.deposit_fee}
                  onChange={(e) => handleChange("deposit_fee", Number(e.target.value))}
                  error={validationErrors.deposit_fee}
                />
                {validationErrors.deposit_fee && <p className="text-sm text-red-500">{validationErrors.deposit_fee}</p>}
              </div>

              <div className="space-y-2">
                <Label htmlFor="withdrawal_fee">Withdrawal Fee (%)</Label>
                <Input
                  id="withdrawal_fee"
                  type="number"
                  value={settings.withdrawal_fee}
                  onChange={(e) => handleChange("withdrawal_fee", Number(e.target.value))}
                  error={validationErrors.withdrawal_fee}
                />
                {validationErrors.withdrawal_fee && (
                  <p className="text-sm text-red-500">{validationErrors.withdrawal_fee}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="min_deposit">Minimum Deposit ({settings.currency_symbol})</Label>
                <Input
                  id="min_deposit"
                  type="number"
                  value={settings.min_deposit}
                  onChange={(e) => handleChange("min_deposit", Number(e.target.value))}
                  error={validationErrors.min_deposit}
                />
                {validationErrors.min_deposit && <p className="text-sm text-red-500">{validationErrors.min_deposit}</p>}
              </div>

              <div className="space-y-2">
                <Label htmlFor="min_withdrawal">Minimum Withdrawal ({settings.currency_symbol})</Label>
                <Input
                  id="min_withdrawal"
                  type="number"
                  value={settings.min_withdrawal}
                  onChange={(e) => handleChange("min_withdrawal", Number(e.target.value))}
                  error={validationErrors.min_withdrawal}
                />
                {validationErrors.min_withdrawal && (
                  <p className="text-sm text-red-500">{validationErrors.min_withdrawal}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="activation_amount">Account Activation Amount ({settings.currency_symbol})</Label>
                <Input
                  id="activation_amount"
                  type="number"
                  value={settings.activation_amount}
                  onChange={(e) => handleChange("activation_amount", Number(e.target.value))}
                  error={validationErrors.activation_amount}
                />
                {validationErrors.activation_amount && (
                  <p className="text-sm text-red-500">{validationErrors.activation_amount}</p>
                )}
                <p className="text-sm text-muted-foreground">
                  Minimum deposit amount required to activate a user account
                </p>
              </div>
            </CardContent>
          </Card>

          <Card className="max-w-2xl mx-auto">
            <CardHeader>
              <CardTitle>Referral Settings</CardTitle>
              <CardDescription>Configure referral program settings</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="referral_bonus">Referral Bonus ({settings.currency_symbol})</Label>
                <Input
                  id="referral_bonus"
                  type="number"
                  value={settings.referral_bonus}
                  onChange={(e) => handleChange("referral_bonus", Number(e.target.value))}
                  error={validationErrors.referral_bonus}
                />
                {validationErrors.referral_bonus && (
                  <p className="text-sm text-red-500">{validationErrors.referral_bonus}</p>
                )}
                <p className="text-sm text-muted-foreground">
                  Amount earned by user when someone signs up using their referral code
                </p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="referred_bonus">Referred Bonus ({settings.currency_symbol})</Label>
                <Input
                  id="referred_bonus"
                  type="number"
                  value={settings.referred_bonus}
                  onChange={(e) => handleChange("referred_bonus", Number(e.target.value))}
                  error={validationErrors.referred_bonus}
                />
                {validationErrors.referred_bonus && (
                  <p className="text-sm text-red-500">{validationErrors.referred_bonus}</p>
                )}
                <p className="text-sm text-muted-foreground">
                  Amount earned by new user when they sign up using a referral code
                </p>
              </div>
            </CardContent>
            <CardFooter className="flex justify-end">
              <Button onClick={handleSave} disabled={saving || loading}>
                <Save className="h-4 w-4 mr-2" />
                {saving ? "Saving..." : "Save Changes"}
              </Button>
            </CardFooter>
          </Card>

          <Card className="max-w-2xl mx-auto mt-8">
            <CardHeader>
              <CardTitle>Payment Methods</CardTitle>
              <CardDescription>Configure payment methods for deposits and withdrawals</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {paymentMethods.map((method, index) => (
                <div key={method.id} className="border rounded-md p-4 space-y-4">
                  <div className="flex justify-between items-center">
                    <h3 className="font-medium">{method.display_name}</h3>
                    <Button variant="destructive" size="sm" onClick={() => deletePaymentMethod(method.id)}>
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor={`name-${index}`}>Internal Name</Label>
                      <Input
                        id={`name-${index}`}
                        value={method.name}
                        onChange={(e) => handlePaymentMethodChange(index, "name", e.target.value)}
                      />
                      <p className="text-xs text-muted-foreground">Internal identifier (lowercase, no spaces)</p>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor={`display-name-${index}`}>Display Name</Label>
                      <Input
                        id={`display-name-${index}`}
                        value={method.display_name}
                        onChange={(e) => handlePaymentMethodChange(index, "display_name", e.target.value)}
                      />
                      <p className="text-xs text-muted-foreground">Name shown to users</p>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor={`account-${index}`}>Account Number</Label>
                    <Input
                      id={`account-${index}`}
                      value={method.account_number}
                      onChange={(e) => handlePaymentMethodChange(index, "account_number", e.target.value)}
                    />
                    <p className="text-xs text-muted-foreground">Phone number or account ID for this payment method</p>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor={`instructions-${index}`}>Instructions</Label>
                    <Textarea
                      id={`instructions-${index}`}
                      value={method.instructions}
                      onChange={(e) => handlePaymentMethodChange(index, "instructions", e.target.value)}
                      rows={3}
                    />
                    <p className="text-xs text-muted-foreground">
                      Instructions shown to users when using this payment method
                    </p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="flex items-center space-x-2">
                      <Switch
                        id={`active-${index}`}
                        checked={method.is_active}
                        onCheckedChange={(checked) => handlePaymentMethodChange(index, "is_active", checked)}
                      />
                      <Label htmlFor={`active-${index}`}>Active</Label>
                    </div>

                    <div className="flex items-center space-x-2">
                      <Switch
                        id={`deposit-${index}`}
                        checked={method.for_deposit}
                        onCheckedChange={(checked) => handlePaymentMethodChange(index, "for_deposit", checked)}
                      />
                      <Label htmlFor={`deposit-${index}`}>For Deposits</Label>
                    </div>

                    <div className="flex items-center space-x-2">
                      <Switch
                        id={`withdrawal-${index}`}
                        checked={method.for_withdrawal}
                        onCheckedChange={(checked) => handlePaymentMethodChange(index, "for_withdrawal", checked)}
                      />
                      <Label htmlFor={`withdrawal-${index}`}>For Withdrawals</Label>
                    </div>
                  </div>

                  <Button onClick={() => savePaymentMethod(index)} disabled={saving}>
                    Save Changes
                  </Button>
                </div>
              ))}

              {addingPaymentMethod ? (
                <div className="border rounded-md p-4 space-y-4">
                  <h3 className="font-medium">Add New Payment Method</h3>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="new-name">Internal Name</Label>
                      <Input
                        id="new-name"
                        value={newPaymentMethod.name}
                        onChange={(e) => handleNewPaymentMethodChange("name", e.target.value)}
                      />
                      <p className="text-xs text-muted-foreground">Internal identifier (lowercase, no spaces)</p>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="new-display-name">Display Name</Label>
                      <Input
                        id="new-display-name"
                        value={newPaymentMethod.display_name}
                        onChange={(e) => handleNewPaymentMethodChange("display_name", e.target.value)}
                      />
                      <p className="text-xs text-muted-foreground">Name shown to users</p>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="new-account">Account Number</Label>
                    <Input
                      id="new-account"
                      value={newPaymentMethod.account_number}
                      onChange={(e) => handleNewPaymentMethodChange("account_number", e.target.value)}
                    />
                    <p className="text-xs text-muted-foreground">Phone number or account ID for this payment method</p>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="new-instructions">Instructions</Label>
                    <Textarea
                      id="new-instructions"
                      value={newPaymentMethod.instructions}
                      onChange={(e) => handleNewPaymentMethodChange("instructions", e.target.value)}
                      rows={3}
                    />
                    <p className="text-xs text-muted-foreground">
                      Instructions shown to users when using this payment method
                    </p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="flex items-center space-x-2">
                      <Switch
                        id="new-active"
                        checked={newPaymentMethod.is_active}
                        onCheckedChange={(checked) => handleNewPaymentMethodChange("is_active", checked)}
                      />
                      <Label htmlFor="new-active">Active</Label>
                    </div>

                    <div className="flex items-center space-x-2">
                      <Switch
                        id="new-deposit"
                        checked={newPaymentMethod.for_deposit}
                        onCheckedChange={(checked) => handleNewPaymentMethodChange("for_deposit", checked)}
                      />
                      <Label htmlFor="new-deposit">For Deposits</Label>
                    </div>

                    <div className="flex items-center space-x-2">
                      <Switch
                        id="new-withdrawal"
                        checked={newPaymentMethod.for_withdrawal}
                        onCheckedChange={(checked) => handleNewPaymentMethodChange("for_withdrawal", checked)}
                      />
                      <Label htmlFor="new-withdrawal">For Withdrawals</Label>
                    </div>
                  </div>

                  <div className="flex space-x-2">
                    <Button onClick={addPaymentMethod} disabled={saving}>
                      Add Payment Method
                    </Button>
                    <Button variant="outline" onClick={() => setAddingPaymentMethod(false)}>
                      Cancel
                    </Button>
                  </div>
                </div>
              ) : (
                <Button onClick={() => setAddingPaymentMethod(true)} className="flex items-center">
                  <Plus className="h-4 w-4 mr-2" />
                  Add Payment Method
                </Button>
              )}
            </CardContent>
          </Card>
        </>
      )}
    </div>
  )
}
