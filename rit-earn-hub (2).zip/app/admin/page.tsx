"use client"

import { CardFooter } from "@/components/ui/card"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Users, Database, MessageSquare, Gift, BarChart3, CreditCard, CheckSquare } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { LoadingSpinner } from "@/components/loading-spinner"

export default function AdminDashboard() {
  const router = useRouter()
  const [loading, setLoading] = useState(true)
  const [isAdmin, setIsAdmin] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState<string | null>(null)

  useEffect(() => {
    const checkAdmin = () => {
      const adminAuthenticated = localStorage.getItem("adminAuthenticated") === "true"

      if (!adminAuthenticated) {
        router.push("/admin-login")
        return
      }

      setIsAdmin(true)
      setLoading(false)
    }

    checkAdmin()
  }, [router])

  const initializeDatabase = async () => {
    setLoading(true)
    setError(null)
    setSuccess(null)

    try {
      const response = await fetch("/api/init", {
        headers: {
          "x-admin-auth": "true",
        },
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || "Failed to initialize database")
      }

      setSuccess("Database schema initialized successfully!")
    } catch (error: any) {
      console.error("Error initializing database:", error)
      setError(error.message || "Failed to initialize database")
    } finally {
      setLoading(false)
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <LoadingSpinner size="lg" />
      </div>
    )
  }

  if (!isAdmin) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded mb-6">
          <p className="font-medium">Access Denied</p>
          <p>You do not have permission to access this page.</p>
        </div>
        <Button onClick={() => (window.location.href = "/dashboard")} className="mt-4">
          Return to Dashboard
        </Button>
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-2">Admin Dashboard</h1>
      <p className="text-muted-foreground mb-8">Manage your platform and users</p>

      {error && (
        <Alert variant="destructive" className="mb-6">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {success && (
        <Alert className="mb-6">
          <AlertDescription>{success}</AlertDescription>
        </Alert>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <Card className="hover:shadow-md transition-shadow">
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center">
              <Users className="h-5 w-5 mr-2 text-primary" /> Users
            </CardTitle>
            <CardDescription>Manage user accounts</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-sm">View and manage all user accounts, update balances, and handle user issues.</p>
          </CardContent>
          <CardFooter>
            <Button onClick={() => router.push("/admin/users")} className="w-full">
              Manage Users
            </Button>
          </CardFooter>
        </Card>

        <Card className="hover:shadow-md transition-shadow">
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center">
              <CreditCard className="h-5 w-5 mr-2 text-primary" /> Transactions
            </CardTitle>
            <CardDescription>Review deposits and withdrawals</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-sm">Process pending deposits and withdrawal requests from users.</p>
          </CardContent>
          <CardFooter>
            <Button onClick={() => router.push("/admin/transactions")} className="w-full">
              Manage Transactions
            </Button>
          </CardFooter>
        </Card>

        <Card className="hover:shadow-md transition-shadow">
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center">
              <CheckSquare className="h-5 w-5 mr-2 text-primary" /> Tasks
            </CardTitle>
            <CardDescription>Manage tasks and submissions</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-sm">Create, edit, and delete tasks. Review and approve task submissions.</p>
          </CardContent>
          <CardFooter>
            <Button onClick={() => router.push("/admin/tasks")} className="w-full">
              Manage Tasks
            </Button>
          </CardFooter>
        </Card>

        <Card className="hover:shadow-md transition-shadow">
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center">
              <Gift className="h-5 w-5 mr-2 text-primary" /> Vouchers
            </CardTitle>
            <CardDescription>Manage deposit vouchers</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-sm">Create and manage voucher codes for deposits.</p>
          </CardContent>
          <CardFooter>
            <Button onClick={() => router.push("/admin/vouchers")} className="w-full">
              Manage Vouchers
            </Button>
          </CardFooter>
        </Card>

        <Card className="hover:shadow-md transition-shadow">
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center">
              <BarChart3 className="h-5 w-5 mr-2 text-primary" /> Analytics
            </CardTitle>
            <CardDescription>Platform statistics</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-sm">View platform statistics, user growth, and financial reports.</p>
          </CardContent>
          <CardFooter>
            <Button onClick={() => router.push("/admin/analytics")} className="w-full">
              View Analytics
            </Button>
          </CardFooter>
        </Card>

        <Card className="hover:shadow-md transition-shadow">
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center">
              <MessageSquare className="h-5 w-5 mr-2 text-primary" /> Telegram Bot
            </CardTitle>
            <CardDescription>Manage Telegram bot settings</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-sm">Configure and manage the Telegram bot for transaction approvals.</p>
          </CardContent>
          <CardFooter>
            <Button onClick={() => router.push("/admin/setup-telegram-bot")} className="w-full">
              Manage Bot
            </Button>
          </CardFooter>
        </Card>

        <Card className="hover:shadow-md transition-shadow bg-blue-50">
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center">
              <Database className="h-5 w-5 mr-2 text-blue-600" /> Database Utilities
            </CardTitle>
            <CardDescription>Fix database schema issues</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-sm">Initialize and fix database schema issues, add missing columns.</p>
          </CardContent>
          <CardFooter className="flex gap-2">
            <Button onClick={initializeDatabase} className="flex-1 bg-blue-600 hover:bg-blue-700">
              Fix Schema
            </Button>
            <Button onClick={() => router.push("/admin/fix-database")} className="flex-1">
              Advanced
            </Button>
          </CardFooter>
        </Card>

        <Card className="hover:shadow-md transition-shadow">
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center">
              <Gift className="h-5 w-5 mr-2 text-primary" /> Referrals
            </CardTitle>
            <CardDescription>Manage referral bonuses</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-sm">Process referral bonuses for users who didn't receive them automatically.</p>
          </CardContent>
          <CardFooter>
            <Button onClick={() => router.push("/admin/referrals/process")} className="w-full">
              Process Referrals
            </Button>
          </CardFooter>
        </Card>
      </div>
    </div>
  )
}
