"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { ArrowLeft } from "lucide-react"
import Link from "next/link"

export default function TestNotifications() {
  const [loading, setLoading] = useState(false)
  const [message, setMessage] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)

  const testTelegramNotification = async () => {
    setLoading(true)
    setMessage(null)
    setError(null)

    try {
      const response = await fetch("/api/test-telegram")
      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || "Failed to send test notification")
      }

      setMessage("Test notification sent successfully! Check your Telegram.")
    } catch (error: any) {
      setError(error.message || "An error occurred while sending the test notification")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <Link href="/admin" className="inline-flex items-center text-primary hover:underline">
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Admin Dashboard
        </Link>
        <h1 className="text-3xl font-bold mt-2">Test Notifications</h1>
        <p className="text-muted-foreground">Test the notification systems</p>
      </div>

      {message && (
        <Alert className="mb-6">
          <AlertDescription>{message}</AlertDescription>
        </Alert>
      )}

      {error && (
        <Alert variant="destructive" className="mb-6">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      <Card className="max-w-2xl mx-auto">
        <CardHeader>
          <CardTitle>Telegram Notifications</CardTitle>
          <CardDescription>Test the Telegram notification system</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <p>
            This will send a test message to the configured Telegram bot. Make sure you have added the bot to your chat
            and started a conversation with it.
          </p>
          <p>
            <strong>Bot Token:</strong> 7825284153:AAEKbga9rIBOUnSL2ndRrO6Hl1HsxS1EV7w
            <br />
            <strong>Chat ID:</strong> 6880722176
          </p>
          <Button onClick={testTelegramNotification} disabled={loading}>
            {loading ? "Sending..." : "Send Test Notification"}
          </Button>
        </CardContent>
      </Card>
    </div>
  )
}
