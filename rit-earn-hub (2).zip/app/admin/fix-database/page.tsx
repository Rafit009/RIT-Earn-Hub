"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { LoadingSpinner } from "@/components/loading-spinner"
import { CheckCircle, Database, AlertCircle } from "lucide-react"

// Import the new component
import { FixTransactionProcessing } from "./utils"

export default function FixDatabasePage() {
  const [loading, setLoading] = useState(false)
  const [success, setSuccess] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)

  const fixDatabase = async () => {
    try {
      setLoading(true)
      setError(null)
      setSuccess(null)

      const response = await fetch("/api/admin/fix-database", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || "Failed to fix database schema")
      }

      setSuccess(data.message || "Database schema fixed successfully")
    } catch (error: any) {
      console.error("Error fixing database:", error)
      setError(error.message || "Failed to fix database schema. Please try again.")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold">Database Utilities</h1>
        <p className="text-muted-foreground">This page contains utilities to fix common database issues</p>
      </div>

      {error && (
        <Alert variant="destructive" className="mb-6">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {success && (
        <Alert className="mb-6 bg-green-50 border-green-200">
          <CheckCircle className="h-4 w-4 text-green-600" />
          <AlertDescription className="text-green-700">{success}</AlertDescription>
        </Alert>
      )}

      <div className="grid gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Database className="h-5 w-5 mr-2" /> Fix Database Schema
            </CardTitle>
            <CardDescription>
              This utility will fix missing columns and tables in the database schema. Use this if you are experiencing
              errors related to missing columns.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground mb-4">
              This will add the following missing columns to the user_tasks table:
            </p>
            <ul className="list-disc pl-5 mb-4 space-y-1">
              <li>started_at</li>
              <li>submission_date</li>
              <li>submission_details</li>
              <li>admin_approved</li>
            </ul>
            <p className="text-amber-600 text-sm">
              <AlertCircle className="h-4 w-4 inline mr-1" />
              This operation is safe and will not delete any existing data.
            </p>
          </CardContent>
          <CardFooter>
            <Button onClick={fixDatabase} disabled={loading} className="w-full">
              {loading ? (
                <>
                  <LoadingSpinner size="sm" className="mr-2" /> Fixing Database...
                </>
              ) : (
                <>Fix Database Schema</>
              )}
            </Button>
          </CardFooter>
        </Card>

        {/* Add the new transaction processing fix component */}
        <FixTransactionProcessing />
      </div>
    </div>
  )
}
