import { Skeleton } from "@/components/ui/skeleton"

export default function Loading() {
  return (
    <div className="min-h-screen flex flex-col md:flex-row">
      {/* Left side skeleton */}
      <div className="bg-indigo-600 text-white md:w-1/2 p-8 flex flex-col justify-between">
        <div>
          <Skeleton className="h-10 w-40 bg-indigo-500 mb-12" />
          <Skeleton className="h-12 w-3/4 bg-indigo-500 mb-4" />
          <Skeleton className="h-8 w-2/3 bg-indigo-500 mb-8" />
        </div>

        <Skeleton className="h-64 w-full bg-indigo-500" />

        <Skeleton className="h-4 w-1/2 bg-indigo-500 mt-8" />
      </div>

      {/* Right side skeleton */}
      <div className="md:w-1/2 p-8 flex items-center justify-center">
        <div className="w-full max-w-md">
          <div className="text-center mb-8">
            <Skeleton className="h-10 w-48 mx-auto mb-2" />
            <Skeleton className="h-6 w-64 mx-auto" />
          </div>

          <div className="space-y-6">
            <div>
              <Skeleton className="h-5 w-32 mb-2" />
              <Skeleton className="h-10 w-full" />
            </div>

            <div>
              <Skeleton className="h-5 w-32 mb-2" />
              <Skeleton className="h-10 w-full" />
            </div>

            <Skeleton className="h-10 w-full" />
          </div>

          <Skeleton className="h-5 w-48 mx-auto mt-8" />
        </div>
      </div>
    </div>
  )
}
