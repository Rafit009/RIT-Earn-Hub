"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { ArrowLeft } from "lucide-react"
import Link from "next/link"
import { LoadingSpinner } from "@/components/loading-spinner"

export default function TestServiceRole() {
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<any>(null)
  const [error, setError] = useState<string | null>(null)

  const testServiceRole = async () => {
    setLoading(true)
    setError(null)
    setResult(null)

    try {
      const response = await fetch("/api/admin/test-service-role")
      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || "Failed to test service role key")
      }

      setResult(data)
    } catch (error: any) {
      console.error("Error testing service role key:", error)
      setError(error.message || "An error occurred while testing service role key")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <Link href="/admin" className="inline-flex items-center text-primary hover:underline">
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Admin Dashboard
        </Link>
        <h1 className="text-3xl font-bold mt-2">Test Service Role Key</h1>
        <p className="text-muted-foreground">Verify that the Supabase service role key is working correctly</p>
      </div>

      {error && (
        <Alert variant="destructive" className="mb-6">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      <Card className="max-w-2xl mx-auto mb-8">
        <CardHeader>
          <CardTitle>Service Role Key Test</CardTitle>
          <CardDescription>Click the button below to test the service role key</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <Button onClick={testServiceRole} disabled={loading} className="w-full">
            {loading ? (
              <>
                <LoadingSpinner size="sm" className="mr-2" /> Testing...
              </>
            ) : (
              "Test Service Role Key"
            )}
          </Button>

          {result && (
            <div className="mt-4">
              <h3 className="font-medium text-lg mb-2">Test Results:</h3>
              <pre className="bg-muted p-4 rounded-md overflow-x-auto whitespace-pre-wrap">
                {JSON.stringify(result, null, 2)}
              </pre>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
