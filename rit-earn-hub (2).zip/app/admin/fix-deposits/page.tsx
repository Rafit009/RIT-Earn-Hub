"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { CheckCircle, AlertCircle, ArrowRight, RefreshCw, Database, ArrowLeft } from "lucide-react"
import Link from "next/link"

// Update the component to include links to both functions
export default function FixDepositsPage() {
  const [loading, setLoading] = useState(false)
  const [results, setResults] = useState<any[] | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState<string | null>(null)

  const runFix = async () => {
    setLoading(true)
    setError(null)
    setSuccess(null)

    try {
      const response = await fetch("/api/admin/fix-deposit-balances", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-admin-auth": "true", // Admin authentication token
        },
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || "Failed to fix deposits")
      }

      setSuccess(data.message)
      setResults(data.results)
    } catch (error: any) {
      console.error("Error fixing deposits:", error)
      setError(error.message || "Failed to fix deposits")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <Link href="/admin" className="inline-flex items-center text-primary hover:underline">
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Admin Dashboard
        </Link>
        <h1 className="text-3xl font-bold mt-2">Fix Deposit Issues</h1>
        <p className="text-muted-foreground">Tools to fix various deposit-related issues</p>
      </div>

      {error && (
        <Alert variant="destructive" className="mb-6">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {success && (
        <Alert className="mb-6 bg-green-50 border-green-200">
          <CheckCircle className="h-4 w-4 text-green-600" />
          <AlertDescription className="text-green-700">{success}</AlertDescription>
        </Alert>
      )}

      <div className="grid gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Fix Transaction Processing</CardTitle>
            <CardDescription>
              Update the database function that processes transactions to fix issues with deposits for inactive accounts
            </CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-sm mb-4">
              This utility fixes the root cause of the issue by updating the transaction processing function in the
              database. After applying this fix, new deposit transactions will be correctly processed for both active
              and inactive accounts.
            </p>
          </CardContent>
          <CardFooter>
            <Link href="/admin/fix-database" className="w-full">
              <Button className="w-full flex items-center">
                <Database className="h-4 w-4 mr-2" />
                Go to Database Utilities
              </Button>
            </Link>
          </CardFooter>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Fix Missed Deposit Credits</CardTitle>
            <CardDescription>
              Find and fix deposits that weren't credited to user accounts due to the transaction processing issue
            </CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-sm mb-4">
              This utility finds completed deposits that might not have been credited to user accounts (especially
              inactive accounts) and applies them correctly.
            </p>
            <div className="bg-amber-50 border border-amber-200 text-amber-700 p-4 rounded-md">
              <p className="text-sm">
                <AlertCircle className="h-4 w-4 inline-block mr-1" />
                Use this after fixing the transaction processing function to ensure all existing deposits are properly
                credited.
              </p>
            </div>
          </CardContent>
          <CardFooter>
            <Link href="/admin/fix-deposits/missed" className="w-full">
              <Button className="w-full flex items-center">
                <RefreshCw className="h-4 w-4 mr-2" />
                Fix Missed Deposits
                <ArrowRight className="h-4 w-4 ml-2" />
              </Button>
            </Link>
          </CardFooter>
        </Card>
      </div>
    </div>
  )
}
