"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { ArrowLeft, CheckCircle, XCircle, RefreshCw } from "lucide-react"
import Link from "next/link"
import { LoadingSpinner } from "@/components/loading-spinner"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"

interface Result {
  deposit_id: string
  status: "success" | "error"
  message: string
}

export default function FixMissedDepositsPage() {
  const [loading, setLoading] = useState(false)
  const [results, setResults] = useState<Result[] | null>(null)
  const [message, setMessage] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)

  const fixMissedDeposits = async () => {
    setLoading(true)
    setError(null)
    setMessage(null)
    setResults(null)

    try {
      // Check if admin is authenticated via localStorage
      const adminAuthenticated = localStorage.getItem("adminAuthenticated") === "true"

      if (!adminAuthenticated) {
        throw new Error("You must be logged in as an admin to perform this action")
      }

      const response = await fetch("/api/admin/fix-deposit-transactions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-admin-auth": "true", // Admin authentication token
        },
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || "Failed to fix missed deposits")
      }

      setMessage(data.message)
      setResults(data.results)
    } catch (error: any) {
      console.error("Error fixing missed deposits:", error)
      setError(error.message || "An error occurred while fixing missed deposits")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <Link href="/admin/fix-deposits" className="inline-flex items-center text-primary hover:underline">
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Deposit Fixes
        </Link>
        <h1 className="text-3xl font-bold mt-2">Fix Missed Deposits</h1>
        <p className="text-muted-foreground">Find and fix deposits that weren't credited to user accounts</p>
      </div>

      {error && (
        <Alert className="mb-6 bg-red-50 border-red-200">
          <AlertDescription className="text-red-700">{error}</AlertDescription>
        </Alert>
      )}

      {message && (
        <Alert className="mb-6 bg-green-50 border-green-200">
          <CheckCircle className="h-4 w-4 text-green-600" />
          <AlertDescription className="text-green-700">{message}</AlertDescription>
        </Alert>
      )}

      <Card className="mb-8">
        <CardHeader>
          <CardTitle className="flex items-center">
            <RefreshCw className="h-5 w-5 mr-2" /> Fix Missed Deposit Credits
          </CardTitle>
          <CardDescription>
            This tool finds completed deposits that might not have been credited to user accounts and applies them.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-sm mb-4">
            Due to the previous issue with deposit processing for inactive user accounts, some deposits may not have
            been correctly credited to user balances. This utility will:
          </p>
          <ul className="list-disc list-inside text-sm mb-4 space-y-1">
            <li>Find completed deposits that don't have a corresponding activity log entry</li>
            <li>Add the deposit amount to the user's balance</li>
            <li>Activate inactive accounts if the deposit amount is 50৳ or more</li>
            <li>Create proper activity log entries for the fixed deposits</li>
          </ul>
          <div className="bg-amber-50 border border-amber-200 text-amber-700 p-4 rounded-md">
            <p className="text-sm">
              <strong>Note:</strong> This is safe to run multiple times, as it will only process deposits that weren't
              properly credited. It won't duplicate credits or affect already processed deposits.
            </p>
          </div>
        </CardContent>
        <CardFooter>
          <Button onClick={fixMissedDeposits} disabled={loading} className="w-full">
            {loading ? <LoadingSpinner size="sm" className="mr-2" /> : <RefreshCw className="h-4 w-4 mr-2" />}
            {loading ? "Finding and fixing missed deposits..." : "Find & Fix Missed Deposits"}
          </Button>
        </CardFooter>
      </Card>

      {results && results.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Results</CardTitle>
            <CardDescription>Found and processed {results.length} potentially missed deposits</CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Status</TableHead>
                  <TableHead>Deposit ID</TableHead>
                  <TableHead>Details</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {results.map((result, index) => (
                  <TableRow key={index}>
                    <TableCell>
                      {result.status === "success" ? (
                        <span className="inline-flex items-center text-green-600">
                          <CheckCircle className="h-4 w-4 mr-1" /> Fixed
                        </span>
                      ) : (
                        <span className="inline-flex items-center text-red-600">
                          <XCircle className="h-4 w-4 mr-1" /> Error
                        </span>
                      )}
                    </TableCell>
                    <TableCell className="font-mono text-xs">{result.deposit_id}</TableCell>
                    <TableCell>{result.message}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}

      {results && results.length === 0 && (
        <Alert className="bg-blue-50 border-blue-200">
          <AlertDescription className="text-blue-700">
            No missed deposits were found. All deposits appear to be correctly processed.
          </AlertDescription>
        </Alert>
      )}
    </div>
  )
}
