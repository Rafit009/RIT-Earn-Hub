"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { ArrowLeft } from "lucide-react"
import Link from "next/link"
import { LoadingSpinner } from "@/components/loading-spinner"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"

export default function DebugTransactions() {
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<any>(null)
  const [error, setError] = useState<string | null>(null)
  const [transactionId, setTransactionId] = useState("")
  const [transactionType, setTransactionType] = useState("deposits")

  const fetchTransaction = async () => {
    setLoading(true)
    setError(null)
    setResult(null)

    try {
      // Check if admin is authenticated via localStorage
      const adminAuthenticated = localStorage.getItem("adminAuthenticated") === "true"

      if (!adminAuthenticated) {
        throw new Error("Not authenticated as admin")
      }

      let url = `/api/admin/debug-transactions?type=${transactionType}`
      if (transactionId) {
        url += `&id=${transactionId}`
      }

      const response = await fetch(url, {
        headers: {
          "x-admin-auth": "true", // Admin authentication token
        },
      })

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.error || "Failed to fetch transaction data")
      }

      const data = await response.json()
      setResult(data)
    } catch (error: any) {
      console.error("Error fetching transaction:", error)
      setError(error.message || "An error occurred while fetching transaction data")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <Link href="/admin" className="inline-flex items-center text-primary hover:underline">
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Admin Dashboard
        </Link>
        <h1 className="text-3xl font-bold mt-2">Transaction Debug</h1>
        <p className="text-muted-foreground">Inspect transaction details for troubleshooting</p>
      </div>

      {error && (
        <Alert variant="destructive" className="mb-6">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      <Card className="max-w-2xl mx-auto mb-8">
        <CardHeader>
          <CardTitle>Transaction Lookup</CardTitle>
          <CardDescription>Enter transaction details to inspect</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label>Transaction Type</Label>
            <RadioGroup value={transactionType} onValueChange={setTransactionType} className="flex flex-col space-y-1">
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="deposits" id="deposits" />
                <Label htmlFor="deposits" className="cursor-pointer">
                  Deposits
                </Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="withdrawals" id="withdrawals" />
                <Label htmlFor="withdrawals" className="cursor-pointer">
                  Withdrawals
                </Label>
              </div>
            </RadioGroup>
          </div>

          <div className="space-y-2">
            <Label htmlFor="transactionId">Transaction ID (optional)</Label>
            <Input
              id="transactionId"
              value={transactionId}
              onChange={(e) => setTransactionId(e.target.value)}
              placeholder="Leave empty to fetch all transactions"
            />
            <p className="text-xs text-muted-foreground">
              Enter a specific transaction ID or leave empty to fetch all transactions
            </p>
          </div>

          <Button onClick={fetchTransaction} disabled={loading} className="w-full">
            {loading ? (
              <>
                <LoadingSpinner size="sm" className="mr-2" /> Fetching...
              </>
            ) : (
              "Fetch Transaction Data"
            )}
          </Button>
        </CardContent>
      </Card>

      {result && (
        <Card className="max-w-4xl mx-auto">
          <CardHeader>
            <CardTitle>Transaction Data</CardTitle>
            <CardDescription>Raw transaction data for debugging</CardDescription>
          </CardHeader>
          <CardContent>
            <pre className="bg-muted p-4 rounded-md overflow-x-auto whitespace-pre-wrap">
              {JSON.stringify(result, null, 2)}
            </pre>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
