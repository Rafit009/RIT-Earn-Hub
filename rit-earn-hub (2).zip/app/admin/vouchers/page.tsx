"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { LoadingSpinner } from "@/components/loading-spinner"
import { ArrowLeft, Plus, Edit, Trash2, CheckCircle, XCircle, Calendar, RefreshCw } from "lucide-react"
import Link from "next/link"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
  DialogClose,
} from "@/components/ui/dialog"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import { Switch } from "@/components/ui/switch"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"

interface Voucher {
  id: string
  code: string
  amount: number
  description: string | null
  is_active: boolean
  max_uses: number | null
  used_count: number
  created_by: string | null
  created_at: string
  expires_at: string | null
  creator?: {
    username: string
  }
}

export default function VouchersPage() {
  const router = useRouter()
  const [vouchers, setVouchers] = useState<Voucher[]>([])
  const [loading, setLoading] = useState(true)
  const [refreshing, setRefreshing] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState<string | null>(null)
  const [isAdmin, setIsAdmin] = useState(false)
  const [checkingAdmin, setCheckingAdmin] = useState(true)

  // New voucher form state
  const [newVoucherCode, setNewVoucherCode] = useState("")
  const [newVoucherAmount, setNewVoucherAmount] = useState("")
  const [newVoucherDescription, setNewVoucherDescription] = useState("")
  const [newVoucherMaxUses, setNewVoucherMaxUses] = useState("")
  const [newVoucherExpiry, setNewVoucherExpiry] = useState("")
  const [creatingVoucher, setCreatingVoucher] = useState(false)

  // Edit voucher state
  const [editingVoucher, setEditingVoucher] = useState<Voucher | null>(null)
  const [editVoucherDescription, setEditVoucherDescription] = useState("")
  const [editVoucherMaxUses, setEditVoucherMaxUses] = useState("")
  const [editVoucherExpiry, setEditVoucherExpiry] = useState("")
  const [editVoucherActive, setEditVoucherActive] = useState(true)
  const [updatingVoucher, setUpdatingVoucher] = useState(false)

  // Delete voucher state
  const [deletingVoucher, setDeletingVoucher] = useState<string | null>(null)

  // Filter state
  const [activeFilter, setActiveFilter] = useState<string>("all")

  useEffect(() => {
    const checkAdminAndFetchVouchers = async () => {
      try {
        // Check if admin is authenticated via localStorage
        const adminAuthenticated = localStorage.getItem("adminAuthenticated") === "true"

        if (!adminAuthenticated) {
          router.push("/admin-login")
          return
        }

        setIsAdmin(true)
        fetchVouchers()
      } catch (error: any) {
        console.error("Error checking admin status:", error)
        setError(error.message || "Failed to check admin status")
      } finally {
        setCheckingAdmin(false)
      }
    }

    checkAdminAndFetchVouchers()
  }, [router])

  const fetchVouchers = async () => {
    try {
      setRefreshing(true)
      setError(null)

      // Build query URL based on active filter
      let url = "/api/admin/vouchers"
      if (activeFilter !== "all") {
        url += `?active=${activeFilter === "active" ? "true" : "false"}`
      }

      const response = await fetch(url, {
        headers: {
          "x-admin-auth": "true", // Admin authentication token
        },
      })

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.error || "Failed to fetch vouchers")
      }

      const data = await response.json()
      setVouchers(data.vouchers || [])
    } catch (error: any) {
      console.error("Error fetching vouchers:", error)
      setError(error.message || "Failed to load vouchers")
    } finally {
      setLoading(false)
      setRefreshing(false)
    }
  }

  const createVoucher = async () => {
    try {
      setCreatingVoucher(true)
      setError(null)
      setSuccess(null)

      // Validate inputs
      if (!newVoucherCode.trim()) {
        throw new Error("Voucher code is required")
      }

      const amount = Number.parseFloat(newVoucherAmount)
      if (isNaN(amount) || amount <= 0) {
        throw new Error("Please enter a valid amount")
      }

      // Get admin user ID
      const adminEmail = localStorage.getItem("adminEmail")

      // Prepare request body
      const requestBody: any = {
        code: newVoucherCode,
        amount,
        description: newVoucherDescription.trim() || null,
      }

      // Add optional fields if provided
      if (newVoucherMaxUses.trim()) {
        const maxUses = Number.parseInt(newVoucherMaxUses)
        if (isNaN(maxUses) || maxUses <= 0) {
          throw new Error("Maximum uses must be a positive number")
        }
        requestBody.maxUses = maxUses
      }

      if (newVoucherExpiry.trim()) {
        const expiryDate = new Date(newVoucherExpiry)
        if (isNaN(expiryDate.getTime())) {
          throw new Error("Please enter a valid expiry date")
        }
        requestBody.expiresAt = expiryDate.toISOString()
      }

      const response = await fetch("/api/admin/vouchers", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-admin-auth": "true", // Admin authentication token
        },
        body: JSON.stringify(requestBody),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || "Failed to create voucher")
      }

      // Reset form
      setNewVoucherCode("")
      setNewVoucherAmount("")
      setNewVoucherDescription("")
      setNewVoucherMaxUses("")
      setNewVoucherExpiry("")

      // Show success message
      setSuccess("Voucher created successfully")

      // Refresh vouchers list
      fetchVouchers()

      // Clear success message after 3 seconds
      setTimeout(() => setSuccess(null), 3000)
    } catch (error: any) {
      console.error("Error creating voucher:", error)
      setError(error.message || "Failed to create voucher")
    } finally {
      setCreatingVoucher(false)
    }
  }

  const updateVoucher = async () => {
    if (!editingVoucher) return

    try {
      setUpdatingVoucher(true)
      setError(null)
      setSuccess(null)

      // Prepare request body
      const requestBody: any = {
        id: editingVoucher.id,
        isActive: editVoucherActive,
        description: editVoucherDescription.trim() || null,
      }

      // Add optional fields if provided
      if (editVoucherMaxUses.trim()) {
        const maxUses = Number.parseInt(editVoucherMaxUses)
        if (isNaN(maxUses) || maxUses < 0) {
          throw new Error("Maximum uses must be a non-negative number")
        }
        requestBody.maxUses = maxUses === 0 ? null : maxUses
      } else {
        requestBody.maxUses = null
      }

      if (editVoucherExpiry.trim()) {
        const expiryDate = new Date(editVoucherExpiry)
        if (isNaN(expiryDate.getTime())) {
          throw new Error("Please enter a valid expiry date")
        }
        requestBody.expiresAt = expiryDate.toISOString()
      } else {
        requestBody.expiresAt = null
      }

      const response = await fetch("/api/admin/vouchers", {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          "x-admin-auth": "true", // Admin authentication token
        },
        body: JSON.stringify(requestBody),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || "Failed to update voucher")
      }

      // Show success message
      setSuccess("Voucher updated successfully")

      // Reset edit state
      setEditingVoucher(null)

      // Refresh vouchers list
      fetchVouchers()

      // Clear success message after 3 seconds
      setTimeout(() => setSuccess(null), 3000)
    } catch (error: any) {
      console.error("Error updating voucher:", error)
      setError(error.message || "Failed to update voucher")
    } finally {
      setUpdatingVoucher(false)
    }
  }

  const deleteVoucher = async (voucherId: string) => {
    try {
      setDeletingVoucher(voucherId)
      setError(null)
      setSuccess(null)

      const response = await fetch(`/api/admin/vouchers?id=${voucherId}`, {
        method: "DELETE",
        headers: {
          "x-admin-auth": "true", // Admin authentication token
        },
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || "Failed to delete voucher")
      }

      // Show success message
      setSuccess("Voucher deleted successfully")

      // Refresh vouchers list
      fetchVouchers()

      // Clear success message after 3 seconds
      setTimeout(() => setSuccess(null), 3000)
    } catch (error: any) {
      console.error("Error deleting voucher:", error)
      setError(error.message || "Failed to delete voucher")
    } finally {
      setDeletingVoucher(null)
    }
  }

  const handleEditVoucher = (voucher: Voucher) => {
    setEditingVoucher(voucher)
    setEditVoucherDescription(voucher.description || "")
    setEditVoucherMaxUses(voucher.max_uses !== null ? voucher.max_uses.toString() : "")
    setEditVoucherExpiry(voucher.expires_at ? new Date(voucher.expires_at).toISOString().split("T")[0] : "")
    setEditVoucherActive(voucher.is_active)
  }

  const formatDate = (dateString: string | null) => {
    if (!dateString) return "No expiry"
    const date = new Date(dateString)
    return date.toLocaleDateString()
  }

  if (loading || checkingAdmin) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <LoadingSpinner size="lg" />
      </div>
    )
  }

  if (!isAdmin) {
    return null // Will redirect in useEffect
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <Link href="/admin" className="inline-flex items-center text-primary hover:underline">
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Admin Dashboard
        </Link>
        <h1 className="text-3xl font-bold mt-2">Voucher Management</h1>
        <p className="text-muted-foreground">Create and manage voucher codes for deposits</p>
      </div>

      {error && (
        <Alert variant="destructive" className="mb-6">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {success && (
        <Alert className="mb-6 bg-green-50 border-green-200">
          <CheckCircle className="h-4 w-4 text-green-600" />
          <AlertDescription className="text-green-700">{success}</AlertDescription>
        </Alert>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>Create New Voucher</CardTitle>
            <CardDescription>Create a new voucher code for users to redeem</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="voucherCode">Voucher Code</Label>
                <Input
                  id="voucherCode"
                  value={newVoucherCode}
                  onChange={(e) => setNewVoucherCode(e.target.value)}
                  placeholder="e.g., WELCOME50"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="voucherAmount">Amount (৳)</Label>
                <Input
                  id="voucherAmount"
                  type="number"
                  value={newVoucherAmount}
                  onChange={(e) => setNewVoucherAmount(e.target.value)}
                  placeholder="e.g., 50"
                />
              </div>

              <div className="space-y-2 md:col-span-2">
                <Label htmlFor="voucherDescription">Description (Optional)</Label>
                <Textarea
                  id="voucherDescription"
                  value={newVoucherDescription}
                  onChange={(e) => setNewVoucherDescription(e.target.value)}
                  placeholder="e.g., Welcome bonus for new users"
                  rows={2}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="voucherMaxUses">Maximum Uses (Optional)</Label>
                <Input
                  id="voucherMaxUses"
                  type="number"
                  value={newVoucherMaxUses}
                  onChange={(e) => setNewVoucherMaxUses(e.target.value)}
                  placeholder="Leave empty for unlimited"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="voucherExpiry">Expiry Date (Optional)</Label>
                <Input
                  id="voucherExpiry"
                  type="date"
                  value={newVoucherExpiry}
                  onChange={(e) => setNewVoucherExpiry(e.target.value)}
                />
              </div>
            </div>

            <Button onClick={createVoucher} disabled={creatingVoucher} className="mt-4 w-full">
              {creatingVoucher ? (
                <>
                  <LoadingSpinner size="sm" className="mr-2" /> Creating...
                </>
              ) : (
                <>
                  <Plus className="h-4 w-4 mr-2" /> Create Voucher
                </>
              )}
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Voucher Information</CardTitle>
            <CardDescription>How vouchers work in the system</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <h3 className="font-semibold mb-1">Voucher Codes</h3>
              <p className="text-sm text-muted-foreground">
                Voucher codes can be used by users to add funds to their account. Each code can have a specific amount,
                usage limit, and expiry date.
              </p>
            </div>

            <div>
              <h3 className="font-semibold mb-1">Usage Limits</h3>
              <p className="text-sm text-muted-foreground">
                You can set a maximum number of times a voucher can be used. Leave this empty for unlimited uses.
              </p>
            </div>

            <div>
              <h3 className="font-semibold mb-1">Expiry Dates</h3>
              <p className="text-sm text-muted-foreground">
                Vouchers can have an optional expiry date. After this date, the voucher will no longer be valid.
              </p>
            </div>

            <div>
              <h3 className="font-semibold mb-1">Account Activation</h3>
              <p className="text-sm text-muted-foreground">
                When a user redeems a voucher, their account will be automatically activated, regardless of the voucher
                amount.
              </p>
            </div>

            <div className="bg-amber-50 border border-amber-200 rounded-md p-4">
              <h3 className="font-semibold text-amber-800 mb-1">Important Note</h3>
              <p className="text-sm text-amber-700">
                Each user can only use a specific voucher code once. The system tracks which vouchers have been used by
                each user.
              </p>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader className="flex flex-col sm:flex-row justify-between items-start sm:items-center space-y-2 sm:space-y-0">
          <div>
            <CardTitle>Manage Vouchers</CardTitle>
            <CardDescription>View, edit, and delete existing voucher codes</CardDescription>
          </div>
          <div className="flex items-center space-x-2">
            <Button variant="outline" size="sm" onClick={fetchVouchers} disabled={refreshing} className="h-8">
              {refreshing ? <LoadingSpinner size="sm" /> : <RefreshCw className="h-4 w-4 mr-2" />}
              {refreshing ? "" : "Refresh"}
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="all" className="mb-4" onValueChange={setActiveFilter}>
            <TabsList>
              <TabsTrigger value="all">All Vouchers</TabsTrigger>
              <TabsTrigger value="active">Active</TabsTrigger>
              <TabsTrigger value="inactive">Inactive</TabsTrigger>
            </TabsList>
          </Tabs>

          {vouchers.length > 0 ? (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Code</TableHead>
                    <TableHead>Amount</TableHead>
                    <TableHead>Description</TableHead>
                    <TableHead>Uses</TableHead>
                    <TableHead>Expires</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {vouchers.map((voucher) => (
                    <TableRow key={voucher.id}>
                      <TableCell className="font-medium">{voucher.code}</TableCell>
                      <TableCell>{voucher.amount.toFixed(2)}৳</TableCell>
                      <TableCell>{voucher.description || "—"}</TableCell>
                      <TableCell>
                        {voucher.used_count}
                        {voucher.max_uses !== null && ` / ${voucher.max_uses}`}
                      </TableCell>
                      <TableCell>
                        {voucher.expires_at ? (
                          <div className="flex items-center">
                            <Calendar className="h-4 w-4 mr-1 text-muted-foreground" />
                            {formatDate(voucher.expires_at)}
                          </div>
                        ) : (
                          "No expiry"
                        )}
                      </TableCell>
                      <TableCell>
                        {voucher.is_active ? (
                          <Badge className="bg-green-500">Active</Badge>
                        ) : (
                          <Badge variant="outline" className="text-muted-foreground">
                            Inactive
                          </Badge>
                        )}
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end space-x-2">
                          <Dialog>
                            <DialogTrigger asChild>
                              <Button variant="outline" size="sm" onClick={() => handleEditVoucher(voucher)}>
                                <Edit className="h-4 w-4" />
                              </Button>
                            </DialogTrigger>
                            <DialogContent>
                              <DialogHeader>
                                <DialogTitle>Edit Voucher</DialogTitle>
                                <DialogDescription>Update voucher details</DialogDescription>
                              </DialogHeader>
                              <div className="space-y-4 py-4">
                                <div className="grid grid-cols-4 items-center gap-4">
                                  <Label className="text-right">Code:</Label>
                                  <div className="col-span-3 font-medium">{voucher.code}</div>
                                </div>
                                <div className="grid grid-cols-4 items-center gap-4">
                                  <Label className="text-right">Amount:</Label>
                                  <div className="col-span-3 font-medium">{voucher.amount.toFixed(2)}৳</div>
                                </div>
                                <div className="grid grid-cols-4 items-center gap-4">
                                  <Label htmlFor="description" className="text-right">
                                    Description:
                                  </Label>
                                  <Textarea
                                    id="description"
                                    value={editVoucherDescription}
                                    onChange={(e) => setEditVoucherDescription(e.target.value)}
                                    className="col-span-3"
                                    rows={2}
                                  />
                                </div>
                                <div className="grid grid-cols-4 items-center gap-4">
                                  <Label htmlFor="maxUses" className="text-right">
                                    Max Uses:
                                  </Label>
                                  <Input
                                    id="maxUses"
                                    type="number"
                                    value={editVoucherMaxUses}
                                    onChange={(e) => setEditVoucherMaxUses(e.target.value)}
                                    className="col-span-3"
                                    placeholder="Leave empty for unlimited"
                                  />
                                </div>
                                <div className="grid grid-cols-4 items-center gap-4">
                                  <Label htmlFor="expiry" className="text-right">
                                    Expiry Date:
                                  </Label>
                                  <Input
                                    id="expiry"
                                    type="date"
                                    value={editVoucherExpiry}
                                    onChange={(e) => setEditVoucherExpiry(e.target.value)}
                                    className="col-span-3"
                                  />
                                </div>
                                <div className="grid grid-cols-4 items-center gap-4">
                                  <Label htmlFor="active" className="text-right">
                                    Active:
                                  </Label>
                                  <div className="col-span-3 flex items-center">
                                    <Switch
                                      id="active"
                                      checked={editVoucherActive}
                                      onCheckedChange={setEditVoucherActive}
                                    />
                                    <span className="ml-2">{editVoucherActive ? "Active" : "Inactive"}</span>
                                  </div>
                                </div>
                              </div>
                              <DialogFooter>
                                <DialogClose asChild>
                                  <Button variant="outline">Cancel</Button>
                                </DialogClose>
                                <Button onClick={updateVoucher} disabled={updatingVoucher}>
                                  {updatingVoucher ? (
                                    <>
                                      <LoadingSpinner size="sm" className="mr-2" /> Updating...
                                    </>
                                  ) : (
                                    "Save Changes"
                                  )}
                                </Button>
                              </DialogFooter>
                            </DialogContent>
                          </Dialog>

                          <AlertDialog>
                            <AlertDialogTrigger asChild>
                              <Button variant="outline" size="sm" className="text-red-500">
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </AlertDialogTrigger>
                            <AlertDialogContent>
                              <AlertDialogHeader>
                                <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                                <AlertDialogDescription>
                                  This will permanently delete the voucher code "{voucher.code}". This action cannot be
                                  undone.
                                </AlertDialogDescription>
                              </AlertDialogHeader>
                              <AlertDialogFooter>
                                <AlertDialogCancel>Cancel</AlertDialogCancel>
                                <AlertDialogAction
                                  onClick={() => deleteVoucher(voucher.id)}
                                  className="bg-red-500 text-white hover:bg-red-600"
                                >
                                  {deletingVoucher === voucher.id ? (
                                    <LoadingSpinner size="sm" className="mr-2" />
                                  ) : null}
                                  Delete
                                </AlertDialogAction>
                              </AlertDialogFooter>
                            </AlertDialogContent>
                          </AlertDialog>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          ) : (
            <div className="text-center py-8">
              <XCircle className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
              <h3 className="text-xl font-semibold mb-2">No vouchers found</h3>
              <p className="text-muted-foreground">
                {activeFilter === "all"
                  ? "Create your first voucher to get started"
                  : `No ${activeFilter} vouchers found`}
              </p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
