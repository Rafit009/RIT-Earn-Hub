"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { ArrowLeft, CheckCircle } from "lucide-react"
import Link from "next/link"
import { supabase } from "@/lib/supabase"
import { LoadingSpinner } from "@/components/loading-spinner"

export default function SetupTelegramBot() {
  const [loading, setLoading] = useState(false)
  const [message, setMessage] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [isAdmin, setIsAdmin] = useState(false)
  const [checkingAdmin, setCheckingAdmin] = useState(true)

  useEffect(() => {
    const checkAdminStatus = async () => {
      try {
        const {
          data: { session },
        } = await supabase.auth.getSession()

        if (!session) {
          setError("Not authenticated")
          setCheckingAdmin(false)
          return
        }

        // Check if user is admin
        const { data: profileData, error: profileError } = await supabase
          .from("profiles")
          .select("is_admin")
          .eq("id", session.user.id)
          .single()

        if (profileError || !profileData?.is_admin) {
          setError("Not authorized as admin")
          setCheckingAdmin(false)
          return
        }

        setIsAdmin(true)
        setCheckingAdmin(false)
      } catch (error: any) {
        console.error("Error checking admin status:", error)
        setError(error.message || "An error occurred while checking admin status")
        setCheckingAdmin(false)
      }
    }

    checkAdminStatus()
  }, [])

  const setupWebhook = async () => {
    setLoading(true)
    setMessage(null)
    setError(null)

    try {
      const response = await fetch("/api/telegram-bot?setup=true")
      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || "Failed to set up webhook")
      }

      if (data.ok) {
        setMessage("Telegram Bot webhook set up successfully!")
      } else {
        throw new Error(data.description || "Telegram API returned an error")
      }
    } catch (error: any) {
      setError(error.message || "An error occurred while setting up the webhook")
    } finally {
      setLoading(false)
    }
  }

  const testBot = async () => {
    setLoading(true)
    setMessage(null)
    setError(null)

    try {
      const response = await fetch("/api/telegram-notify", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          table: "deposits",
          record: {
            new: {
              id: `test-${Date.now()}`,
              user_id: "test-user",
              amount: 100,
              method: "test",
              mobile_number: "01712345678",
              transaction_id: "TEST123",
              status: "pending",
              created_at: new Date().toISOString(),
            },
          },
        }),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || "Failed to send test notification")
      }

      setMessage("Test notification sent successfully! Check your Telegram.")
    } catch (error: any) {
      setError(error.message || "An error occurred while sending the test notification")
    } finally {
      setLoading(false)
    }
  }

  if (checkingAdmin) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <LoadingSpinner size="lg" />
      </div>
    )
  }

  if (!isAdmin) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded mb-6">
          <p className="font-medium">Access Denied</p>
          <p>{error || "You do not have permission to access this page."}</p>
        </div>
        <Button onClick={() => (window.location.href = "/dashboard")} className="mt-4">
          Return to Dashboard
        </Button>
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <Link href="/admin" className="inline-flex items-center text-primary hover:underline">
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Admin Dashboard
        </Link>
        <h1 className="text-3xl font-bold mt-2">Telegram Bot Setup</h1>
        <p className="text-muted-foreground">Configure the Telegram Bot for transaction management</p>
      </div>

      {message && (
        <Alert className="mb-6 bg-green-50 border-green-200">
          <CheckCircle className="h-4 w-4 text-green-600 mr-2" />
          <AlertDescription className="text-green-700">{message}</AlertDescription>
        </Alert>
      )}

      {error && (
        <Alert className="mb-6 bg-red-50 border-red-200">
          <AlertDescription className="text-red-700">{error}</AlertDescription>
        </Alert>
      )}

      <Card className="max-w-2xl mx-auto">
        <CardHeader>
          <CardTitle>Telegram Bot Configuration</CardTitle>
          <CardDescription>Set up the Telegram Bot for transaction management</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-2">
            <h3 className="font-semibold">Bot Information</h3>
            <p className="text-sm text-muted-foreground">The Telegram Bot is configured with the following details:</p>
            <div className="bg-muted p-4 rounded-md">
              <p className="text-sm">
                <strong>Bot Token:</strong> 7825284153:AAEKbga9rIBOUnSL2ndRrO6Hl1HsxS1EV7w
              </p>
              <p className="text-sm">
                <strong>Admin Chat ID:</strong> 6880722176
              </p>
            </div>
          </div>

          <div className="space-y-2">
            <h3 className="font-semibold">Setup Instructions</h3>
            <ol className="list-decimal list-inside space-y-2 text-sm">
              <li>Make sure you have started a chat with the bot on Telegram</li>
              <li>Click the "Setup Webhook" button below to configure the bot</li>
              <li>Send the command /start to the bot on Telegram</li>
              <li>Use /pending to view all pending transactions</li>
            </ol>
          </div>

          <div className="flex flex-col space-y-4 sm:flex-row sm:space-y-0 sm:space-x-4">
            <Button onClick={setupWebhook} disabled={loading} className="flex-1">
              {loading ? (
                <>
                  <LoadingSpinner size="sm" className="mr-2" /> Setting up...
                </>
              ) : (
                "Setup Webhook"
              )}
            </Button>
            <Button onClick={testBot} disabled={loading} className="flex-1">
              {loading ? (
                <>
                  <LoadingSpinner size="sm" className="mr-2" /> Testing...
                </>
              ) : (
                "Send Test Notification"
              )}
            </Button>
          </div>

          <div className="bg-blue-50 border border-blue-200 rounded-md p-4 mt-4">
            <h3 className="font-medium text-blue-800 mb-2">Bot Commands</h3>
            <ul className="list-disc list-inside text-sm space-y-1 text-blue-700">
              <li>
                <code>/start</code> - Initialize the bot
              </li>
              <li>
                <code>/pending</code> - View all pending transactions
              </li>
              <li>Use inline buttons to approve or decline transactions</li>
            </ul>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
