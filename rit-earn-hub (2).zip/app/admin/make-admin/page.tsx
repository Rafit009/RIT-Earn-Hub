"use client"

import { useState } from "react"
import { supabase } from "@/lib/supabase"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { ArrowLeft } from "lucide-react"
import Link from "next/link"

export default function MakeAdmin() {
  const [userId, setUserId] = useState("8bed079c-dc1e-47a3-bf31-034666029592")
  const [loading, setLoading] = useState(false)
  const [message, setMessage] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [userData, setUserData] = useState<any>(null)

  const checkUser = async () => {
    setLoading(true)
    setError(null)
    setMessage(null)
    setUserData(null)

    try {
      const { data, error } = await supabase
        .from("profiles")
        .select("id, username, full_name, email, is_admin")
        .eq("id", userId)
        .single()

      if (error) throw error

      if (!data) {
        throw new Error("User not found")
      }

      setUserData(data)
      setMessage(`Found user: ${data.username || data.email}`)
    } catch (error: any) {
      setError(error.message || "An error occurred while checking the user")
    } finally {
      setLoading(false)
    }
  }

  const makeAdmin = async () => {
    if (!userData) {
      setError("Please check the user first")
      return
    }

    setLoading(true)
    setError(null)
    setMessage(null)

    try {
      const { error } = await supabase.from("profiles").update({ is_admin: true }).eq("id", userId)

      if (error) throw error

      setMessage(`User ${userData.username || userData.email} is now an admin!`)
      setUserData({ ...userData, is_admin: true })
    } catch (error: any) {
      setError(error.message || "An error occurred while making the user an admin")
    } finally {
      setLoading(false)
    }
  }

  const removeAdmin = async () => {
    if (!userData) {
      setError("Please check the user first")
      return
    }

    setLoading(true)
    setError(null)
    setMessage(null)

    try {
      const { error } = await supabase.from("profiles").update({ is_admin: false }).eq("id", userId)

      if (error) throw error

      setMessage(`Admin privileges removed from ${userData.username || userData.email}`)
      setUserData({ ...userData, is_admin: false })
    } catch (error: any) {
      setError(error.message || "An error occurred while removing admin privileges")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <Link href="/admin" className="inline-flex items-center text-primary hover:underline">
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Admin Dashboard
        </Link>
        <h1 className="text-3xl font-bold mt-2">Manage Admin Access</h1>
        <p className="text-muted-foreground">Grant or revoke admin privileges</p>
      </div>

      {message && (
        <Alert className="mb-6">
          <AlertDescription>{message}</AlertDescription>
        </Alert>
      )}

      {error && (
        <Alert variant="destructive" className="mb-6">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      <Card className="max-w-2xl mx-auto">
        <CardHeader>
          <CardTitle>User Admin Status</CardTitle>
          <CardDescription>Enter a user ID to check or change admin status</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="userId">User ID</Label>
            <Input id="userId" value={userId} onChange={(e) => setUserId(e.target.value)} placeholder="Enter user ID" />
          </div>

          <div className="flex space-x-2">
            <Button onClick={checkUser} disabled={loading || !userId.trim()}>
              {loading ? "Checking..." : "Check User"}
            </Button>
          </div>

          {userData && (
            <div className="mt-6 p-4 bg-muted rounded-md">
              <h3 className="font-medium mb-2">User Information</h3>
              <p>
                <strong>Username:</strong> {userData.username || "N/A"}
              </p>
              <p>
                <strong>Name:</strong> {userData.full_name || "N/A"}
              </p>
              <p>
                <strong>Email:</strong> {userData.email || "N/A"}
              </p>
              <p>
                <strong>Admin Status:</strong> {userData.is_admin ? "Admin" : "Regular User"}
              </p>

              <div className="mt-4 flex space-x-2">
                {!userData.is_admin ? (
                  <Button onClick={makeAdmin} disabled={loading} className="bg-green-600 hover:bg-green-700">
                    {loading ? "Processing..." : "Make Admin"}
                  </Button>
                ) : (
                  <Button onClick={removeAdmin} disabled={loading} variant="destructive">
                    {loading ? "Processing..." : "Remove Admin Status"}
                  </Button>
                )}
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
