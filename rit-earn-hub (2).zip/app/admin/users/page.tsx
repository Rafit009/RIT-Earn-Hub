"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { LoadingSpinner } from "@/components/loading-spinner"
import { CheckCircle, XCircle, RefreshCw, Edit, Search, UserPlus } from "lucide-react"
import Link from "next/link"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
  DialogClose,
} from "@/components/ui/dialog"

interface User {
  id: string
  username: string
  full_name: string
  email: string
  balance: number
  is_active: boolean
  referral_code: string
  referral_count: number
  total_earnings: number
  created_at: string
}

export default function AdminUsers() {
  const router = useRouter()
  const [users, setUsers] = useState<User[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState<string | null>(null)
  const [searchTerm, setSearchTerm] = useState("")
  const [activatingUser, setActivatingUser] = useState<string | null>(null)
  const [editingUser, setEditingUser] = useState<User | null>(null)
  const [editBalance, setEditBalance] = useState<string>("")
  const [isAdmin, setIsAdmin] = useState(false)
  const [checkingAdmin, setCheckingAdmin] = useState(true)

  useEffect(() => {
    const checkAdminAndFetchUsers = async () => {
      try {
        // Check if admin is authenticated via localStorage
        const adminAuthenticated = localStorage.getItem("adminAuthenticated") === "true"

        if (!adminAuthenticated) {
          router.push("/admin-login")
          return
        }

        setIsAdmin(true)
        fetchUsers()
      } catch (error: any) {
        console.error("Error checking admin status:", error)
        setError(error.message || "Failed to check admin status")
      } finally {
        setCheckingAdmin(false)
      }
    }

    checkAdminAndFetchUsers()
  }, [router])

  const fetchUsers = async () => {
    try {
      setLoading(true)
      setError(null)

      const response = await fetch("/api/admin/users", {
        headers: {
          "x-admin-auth": "true", // Admin authentication token
        },
      })

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.error || "Failed to fetch users")
      }

      const data = await response.json()
      setUsers(data.users || [])
    } catch (error: any) {
      console.error("Error fetching users:", error)
      setError(error.message || "Failed to load users")
    } finally {
      setLoading(false)
    }
  }

  const activateUser = async (userId: string) => {
    try {
      setActivatingUser(userId)
      setError(null)
      setSuccess(null)

      const response = await fetch("/api/admin/activate-user", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-admin-auth": "true", // Admin authentication token
        },
        body: JSON.stringify({ userId }),
      })

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.error || "Failed to activate user")
      }

      // Update local state
      setUsers(users.map((user) => (user.id === userId ? { ...user, is_active: true } : user)))

      setSuccess("User activated successfully")

      // Clear success message after 3 seconds
      setTimeout(() => setSuccess(null), 3000)
    } catch (error: any) {
      console.error("Error activating user:", error)
      setError(error.message || "Failed to activate user. Please try again.")
    } finally {
      setActivatingUser(null)
    }
  }

  const updateUserBalance = async () => {
    if (!editingUser) return

    try {
      setError(null)
      setSuccess(null)

      const newBalance = Number.parseFloat(editBalance)
      if (isNaN(newBalance)) {
        setError("Please enter a valid balance amount")
        return
      }

      const response = await fetch("/api/admin/update-user", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-admin-auth": "true", // Admin authentication token
        },
        body: JSON.stringify({
          userId: editingUser.id,
          balance: newBalance,
        }),
      })

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.error || "Failed to update user")
      }

      // Update local state
      setUsers(users.map((user) => (user.id === editingUser.id ? { ...user, balance: newBalance } : user)))

      setSuccess(`Balance updated successfully for user ${editingUser.username}`)
      setEditingUser(null)

      // Clear success message after 3 seconds
      setTimeout(() => setSuccess(null), 3000)
    } catch (error: any) {
      console.error("Error updating user:", error)
      setError(error.message || "Failed to update user. Please try again.")
    }
  }

  const filteredUsers = users.filter(
    (user) =>
      user.username.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (user.full_name && user.full_name.toLowerCase().includes(searchTerm.toLowerCase())),
  )

  if (loading || checkingAdmin) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <LoadingSpinner size="lg" />
      </div>
    )
  }

  if (!isAdmin) {
    return null // Will redirect in useEffect
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold">User Management</h1>
          <p className="text-muted-foreground">Manage user accounts and balances</p>
        </div>
        <div className="flex space-x-4">
          <Button onClick={fetchUsers} disabled={loading} className="flex items-center gap-2">
            {loading ? <LoadingSpinner size="sm" /> : <RefreshCw className="h-4 w-4" />}
            Refresh
          </Button>
          <Link href="/admin/users/new">
            <Button className="flex items-center gap-2">
              <UserPlus className="h-4 w-4" />
              Add User
            </Button>
          </Link>
        </div>
      </div>

      {error && (
        <Alert variant="destructive" className="mb-6">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {success && (
        <Alert className="mb-6">
          <AlertDescription>{success}</AlertDescription>
        </Alert>
      )}

      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Search Users</CardTitle>
          <CardDescription>Search by username, email, or name</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="Search users..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>User Accounts</CardTitle>
          <CardDescription>Manage all user accounts on the platform</CardDescription>
        </CardHeader>
        <CardContent>
          {filteredUsers.length > 0 ? (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Username</TableHead>
                    <TableHead>Email</TableHead>
                    <TableHead>Name</TableHead>
                    <TableHead>Balance</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Referrals</TableHead>
                    <TableHead>Joined</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredUsers.map((user) => (
                    <TableRow key={user.id}>
                      <TableCell className="font-medium">{user.username}</TableCell>
                      <TableCell>{user.email}</TableCell>
                      <TableCell>{user.full_name || "N/A"}</TableCell>
                      <TableCell>{user.balance.toFixed(2)}৳</TableCell>
                      <TableCell>
                        {user.is_active ? (
                          <Badge className="bg-green-500">Active</Badge>
                        ) : (
                          <Badge className="bg-yellow-500">Inactive</Badge>
                        )}
                      </TableCell>
                      <TableCell>{user.referral_count || 0}</TableCell>
                      <TableCell>{new Date(user.created_at).toLocaleDateString()}</TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end space-x-2">
                          <Dialog>
                            <DialogTrigger asChild>
                              <Button variant="outline" size="sm">
                                <Edit className="h-4 w-4" />
                              </Button>
                            </DialogTrigger>
                            <DialogContent>
                              <DialogHeader>
                                <DialogTitle>Edit User</DialogTitle>
                                <DialogDescription>Update user details</DialogDescription>
                              </DialogHeader>
                              <div className="space-y-4 py-4">
                                <div className="grid grid-cols-4 items-center gap-4">
                                  <p className="text-right font-medium">Username:</p>
                                  <p className="col-span-3">{user.username}</p>
                                </div>
                                <div className="grid grid-cols-4 items-center gap-4">
                                  <p className="text-right font-medium">Email:</p>
                                  <p className="col-span-3">{user.email}</p>
                                </div>
                                <div className="grid grid-cols-4 items-center gap-4">
                                  <p className="text-right font-medium">Current Balance:</p>
                                  <p className="col-span-3">{user.balance.toFixed(2)}৳</p>
                                </div>
                                <div className="grid grid-cols-4 items-center gap-4">
                                  <label htmlFor="balance" className="text-right font-medium">
                                    New Balance:
                                  </label>
                                  <Input
                                    id="balance"
                                    type="number"
                                    step="0.01"
                                    defaultValue={user.balance.toString()}
                                    onChange={(e) => setEditBalance(e.target.value)}
                                    className="col-span-3"
                                  />
                                </div>
                              </div>
                              <DialogFooter>
                                <DialogClose asChild>
                                  <Button variant="outline">Cancel</Button>
                                </DialogClose>
                                <Button
                                  onClick={() => {
                                    setEditingUser(user)
                                    updateUserBalance()
                                  }}
                                >
                                  Save Changes
                                </Button>
                              </DialogFooter>
                            </DialogContent>
                          </Dialog>

                          {!user.is_active && (
                            <Button
                              variant="outline"
                              size="sm"
                              className="bg-green-500 text-white hover:bg-green-600"
                              onClick={() => activateUser(user.id)}
                              disabled={activatingUser === user.id}
                            >
                              {activatingUser === user.id ? (
                                <LoadingSpinner size="sm" className="mr-1" />
                              ) : (
                                <CheckCircle className="h-4 w-4 mr-1" />
                              )}
                              Activate
                            </Button>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          ) : (
            <div className="text-center py-8">
              <XCircle className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
              <h3 className="text-xl font-semibold mb-2">No users found</h3>
              <p className="text-muted-foreground">
                {searchTerm ? "No users match your search criteria" : "There are no users in the system yet"}
              </p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
