"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { CheckCircle, XCircle, AlertCircle, RefreshCw } from "lucide-react"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import { LoadingSpinner } from "@/components/loading-spinner"
import { useRouter } from "next/navigation"

interface Transaction {
  id: string
  user_id: string
  amount: number
  method?: string
  payment_method?: string
  phone_number?: string
  mobile_number?: string
  transaction_id?: string
  status: string
  created_at: string
  user: {
    username: string
    is_active: boolean
  }
}

export default function AdminTransactions() {
  const router = useRouter()
  const [deposits, setDeposits] = useState<Transaction[]>([])
  const [withdrawals, setWithdrawals] = useState<Transaction[]>([])
  const [loading, setLoading] = useState(true)
  const [refreshing, setRefreshing] = useState(false)
  const [processingId, setProcessingId] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState<string | null>(null)
  const [isAdmin, setIsAdmin] = useState(false)
  const [checkingAdmin, setCheckingAdmin] = useState(true)

  const fetchTransactions = async () => {
    try {
      setRefreshing(true)
      setError(null)

      // Check if admin is authenticated via localStorage
      const adminAuthenticated = localStorage.getItem("adminAuthenticated") === "true"

      if (!adminAuthenticated) {
        router.push("/admin-login")
        return
      }

      // Use the API route to fetch transactions with service role key
      const response = await fetch("/api/admin/fetch-transactions", {
        headers: {
          "x-admin-auth": "true", // Admin authentication token
        },
      })

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.error || "Failed to fetch transactions")
      }

      const data = await response.json()

      setDeposits(data.deposits || [])
      setWithdrawals(data.withdrawals || [])
      setIsAdmin(true)
    } catch (error: any) {
      console.error("Error fetching transactions:", error)
      setError(error.message || "Failed to load transactions")
    } finally {
      setLoading(false)
      setRefreshing(false)
      setCheckingAdmin(false)
    }
  }

  useEffect(() => {
    fetchTransactions()
  }, [router])

  // Handle deposit transactions with the new API
  const updateDepositStatus = async (id: string, status: string) => {
    setProcessingId(id)
    setError(null)
    setSuccess(null)

    try {
      // Use the new API route specifically for deposits
      const response = await fetch("/api/admin/fix-deposit", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-admin-auth": "true", // Admin authentication token
        },
        body: JSON.stringify({
          id,
          status,
        }),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || `Failed to update deposit`)
      }

      // Update local state
      setDeposits(deposits.map((deposit) => (deposit.id === id ? { ...deposit, status } : deposit)))
      setSuccess(`Deposit ${status === "completed" ? "approved" : "declined"} successfully`)

      // Clear success message after 3 seconds
      setTimeout(() => setSuccess(null), 3000)
    } catch (error: any) {
      console.error(`Error updating deposit:`, error)
      setError(error.message || `Failed to update deposit. Please try again.`)
    } finally {
      setProcessingId(null)
    }
  }

  // Handle withdrawal transactions with the existing API
  const updateWithdrawalStatus = async (id: string, status: string) => {
    setProcessingId(id)
    setError(null)
    setSuccess(null)

    try {
      // Use the existing API route for withdrawals
      const response = await fetch("/api/admin/process-transaction", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-admin-auth": "true", // Admin authentication token
        },
        body: JSON.stringify({
          type: "withdrawals",
          id,
          status,
        }),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || `Failed to update withdrawal`)
      }

      // Update local state
      setWithdrawals(withdrawals.map((withdrawal) => (withdrawal.id === id ? { ...withdrawal, status } : withdrawal)))
      setSuccess(`Withdrawal ${status === "completed" ? "approved" : "declined"} successfully`)

      // Clear success message after 3 seconds
      setTimeout(() => setSuccess(null), 3000)
    } catch (error: any) {
      console.error(`Error updating withdrawal:`, error)
      setError(error.message || `Failed to update withdrawal. Please try again.`)
    } finally {
      setProcessingId(null)
    }
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "completed":
        return <Badge className="bg-green-500">Completed</Badge>
      case "pending":
        return <Badge className="bg-yellow-500">Pending</Badge>
      case "failed":
        return <Badge className="bg-red-500">Failed</Badge>
      default:
        return <Badge>Unknown</Badge>
    }
  }

  // Helper function to get payment method from either field
  const getPaymentMethod = (transaction: Transaction) => {
    return transaction.method || transaction.payment_method || "N/A"
  }

  // Helper function to get mobile number from either field
  const getMobileNumber = (transaction: Transaction) => {
    return transaction.mobile_number || transaction.phone_number || "N/A"
  }

  if (loading || checkingAdmin) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <LoadingSpinner size="lg" />
      </div>
    )
  }

  if (!isAdmin) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded mb-6">
          <p className="font-medium">Access Denied</p>
          <p>You do not have permission to access this page.</p>
        </div>
        <Button onClick={() => (window.location.href = "/dashboard")} className="mt-4">
          Return to Dashboard
        </Button>
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold">Transaction Management</h1>
          <p className="text-muted-foreground">Manage deposits and withdrawals</p>
        </div>
        <Button onClick={fetchTransactions} disabled={refreshing} className="flex items-center gap-2">
          {refreshing ? <LoadingSpinner size="sm" /> : <RefreshCw className="h-4 w-4" />}
          Refresh
        </Button>
      </div>

      {error && <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded mb-6">{error}</div>}

      {success && (
        <div className="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded mb-6">{success}</div>
      )}

      <Tabs defaultValue="deposits">
        <TabsList className="mb-4">
          <TabsTrigger value="deposits">Deposits ({deposits.length})</TabsTrigger>
          <TabsTrigger value="withdrawals">Withdrawals ({withdrawals.length})</TabsTrigger>
        </TabsList>

        <TabsContent value="deposits">
          <Card>
            <CardHeader>
              <CardTitle>Deposit Requests</CardTitle>
              <CardDescription>Review and process deposit requests</CardDescription>
            </CardHeader>
            <CardContent>
              {deposits.length > 0 ? (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>User</TableHead>
                        <TableHead>Amount</TableHead>
                        <TableHead>Method</TableHead>
                        <TableHead>Phone</TableHead>
                        <TableHead>Transaction ID</TableHead>
                        <TableHead>Date</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {deposits.map((deposit) => (
                        <TableRow key={deposit.id}>
                          <TableCell>
                            <div>
                              <div className="font-medium">@{deposit.user?.username || "unknown"}</div>
                              <div className="text-xs">
                                {!deposit.user?.is_active && deposit.amount >= 50 ? (
                                  <Badge variant="outline" className="bg-amber-100 text-amber-800 border-amber-200">
                                    Will Activate
                                  </Badge>
                                ) : deposit.user?.is_active ? (
                                  <Badge variant="outline" className="bg-green-100 text-green-800 border-green-200">
                                    Active
                                  </Badge>
                                ) : (
                                  <Badge variant="outline" className="bg-gray-100 text-gray-800 border-gray-200">
                                    Inactive
                                  </Badge>
                                )}
                              </div>
                            </div>
                          </TableCell>
                          <TableCell className="font-medium">{deposit.amount.toFixed(2)}৳</TableCell>
                          <TableCell>{getPaymentMethod(deposit)}</TableCell>
                          <TableCell>{getMobileNumber(deposit)}</TableCell>
                          <TableCell>{deposit.transaction_id || "N/A"}</TableCell>
                          <TableCell>{new Date(deposit.created_at).toLocaleDateString()}</TableCell>
                          <TableCell>{getStatusBadge(deposit.status)}</TableCell>
                          <TableCell className="text-right">
                            {deposit.status === "pending" && (
                              <div className="flex justify-end space-x-2">
                                <Button
                                  variant="outline"
                                  size="sm"
                                  className="bg-green-500 text-white hover:bg-green-600"
                                  onClick={() => updateDepositStatus(deposit.id, "completed")}
                                  disabled={processingId === deposit.id}
                                >
                                  {processingId === deposit.id ? (
                                    <LoadingSpinner size="sm" className="mr-1" />
                                  ) : (
                                    <CheckCircle className="h-4 w-4 mr-1" />
                                  )}
                                  Approve
                                </Button>
                                <AlertDialog>
                                  <AlertDialogTrigger asChild>
                                    <Button
                                      variant="outline"
                                      size="sm"
                                      className="bg-red-500 text-white hover:bg-red-600"
                                      disabled={processingId === deposit.id}
                                    >
                                      <XCircle className="h-4 w-4 mr-1" />
                                      Reject
                                    </Button>
                                  </AlertDialogTrigger>
                                  <AlertDialogContent>
                                    <AlertDialogHeader>
                                      <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                                      <AlertDialogDescription>
                                        This will reject the deposit request. The user will be notified.
                                      </AlertDialogDescription>
                                    </AlertDialogHeader>
                                    <AlertDialogFooter>
                                      <AlertDialogCancel>Cancel</AlertDialogCancel>
                                      <AlertDialogAction
                                        onClick={() => updateDepositStatus(deposit.id, "failed")}
                                        className="bg-red-500 text-white hover:bg-red-600"
                                      >
                                        Reject
                                      </AlertDialogAction>
                                    </AlertDialogFooter>
                                  </AlertDialogContent>
                                </AlertDialog>
                              </div>
                            )}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              ) : (
                <div className="text-center py-8">
                  <AlertCircle className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                  <h3 className="text-xl font-semibold mb-2">No deposit requests</h3>
                  <p className="text-muted-foreground">When users make deposit requests, they will appear here</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="withdrawals">
          <Card>
            <CardHeader>
              <CardTitle>Withdrawal Requests</CardTitle>
              <CardDescription>Review and process withdrawal requests</CardDescription>
            </CardHeader>
            <CardContent>
              {withdrawals.length > 0 ? (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>User</TableHead>
                        <TableHead>Amount</TableHead>
                        <TableHead>Method</TableHead>
                        <TableHead>Phone</TableHead>
                        <TableHead>Date</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {withdrawals.map((withdrawal) => (
                        <TableRow key={withdrawal.id}>
                          <TableCell>
                            <div>
                              <div className="font-medium">@{withdrawal.user?.username || "unknown"}</div>
                              <div className="text-xs">
                                {withdrawal.user?.is_active ? (
                                  <Badge variant="outline" className="bg-green-100 text-green-800 border-green-200">
                                    Active
                                  </Badge>
                                ) : (
                                  <Badge variant="outline" className="bg-gray-100 text-gray-800 border-gray-200">
                                    Inactive
                                  </Badge>
                                )}
                              </div>
                            </div>
                          </TableCell>
                          <TableCell className="font-medium">{withdrawal.amount.toFixed(2)}৳</TableCell>
                          <TableCell>{getPaymentMethod(withdrawal)}</TableCell>
                          <TableCell>{getMobileNumber(withdrawal)}</TableCell>
                          <TableCell>{new Date(withdrawal.created_at).toLocaleDateString()}</TableCell>
                          <TableCell>{getStatusBadge(withdrawal.status)}</TableCell>
                          <TableCell className="text-right">
                            {withdrawal.status === "pending" && (
                              <div className="flex justify-end space-x-2">
                                <Button
                                  variant="outline"
                                  size="sm"
                                  className="bg-green-500 text-white hover:bg-green-600"
                                  onClick={() => updateWithdrawalStatus(withdrawal.id, "completed")}
                                  disabled={processingId === withdrawal.id}
                                >
                                  {processingId === withdrawal.id ? (
                                    <LoadingSpinner size="sm" className="mr-1" />
                                  ) : (
                                    <CheckCircle className="h-4 w-4 mr-1" />
                                  )}
                                  Approve
                                </Button>
                                <AlertDialog>
                                  <AlertDialogTrigger asChild>
                                    <Button
                                      variant="outline"
                                      size="sm"
                                      className="bg-red-500 text-white hover:bg-red-600"
                                      disabled={processingId === withdrawal.id}
                                    >
                                      <XCircle className="h-4 w-4 mr-1" />
                                      Reject
                                    </Button>
                                  </AlertDialogTrigger>
                                  <AlertDialogContent>
                                    <AlertDialogHeader>
                                      <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                                      <AlertDialogDescription>
                                        This will reject the withdrawal request and refund the amount to the user's
                                        balance.
                                      </AlertDialogDescription>
                                    </AlertDialogHeader>
                                    <AlertDialogFooter>
                                      <AlertDialogCancel>Cancel</AlertDialogCancel>
                                      <AlertDialogAction
                                        onClick={() => updateWithdrawalStatus(withdrawal.id, "failed")}
                                        className="bg-red-500 text-white hover:bg-red-600"
                                      >
                                        Reject
                                      </AlertDialogAction>
                                    </AlertDialogFooter>
                                  </AlertDialogContent>
                                </AlertDialog>
                              </div>
                            )}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              ) : (
                <div className="text-center py-8">
                  <AlertCircle className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                  <h3 className="text-xl font-semibold mb-2">No withdrawal requests</h3>
                  <p className="text-muted-foreground">When users make withdrawal requests, they will appear here</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
