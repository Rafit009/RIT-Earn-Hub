"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { supabase } from "@/lib/supabase"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { PlusCircle, Edit, Trash2, CheckCircle, Lock, Unlock } from "lucide-react"
import Link from "next/link"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import { LoadingSpinner } from "@/components/loading-spinner"
import { Alert, AlertDescription } from "@/components/ui/alert"

interface Task {
  id: string
  title: string
  description: string
  reward: number
  completion_limit: number | null
  is_closed: boolean
  created_at: string
  updated_at: string
  stats?: {
    total_attempts: number
    completed_count: number
    pending_count: number
    submitted_count: number
  }
}

export default function AdminTasks() {
  const router = useRouter()
  const [tasks, setTasks] = useState<Task[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState<string | null>(null)
  const [deleting, setDeleting] = useState<string | null>(null)
  const [submittedTasksCount, setSubmittedTasksCount] = useState(0)
  const [toggleTaskStatus, setToggleTaskStatus] = useState<string | null>(null)

  useEffect(() => {
    const fetchTasks = async () => {
      try {
        // Check if admin is authenticated via localStorage
        const adminAuthenticated = localStorage.getItem("adminAuthenticated") === "true"

        if (!adminAuthenticated) {
          router.push("/admin-login")
          return
        }

        // Initialize with empty arrays in case of permission errors
        let tasksData = []
        let userTasksData = []

        try {
          // Fetch tasks with error handling
          const { data: fetchedTasks, error: tasksError } = await supabase
            .from("tasks")
            .select("*")
            .order("created_at", { ascending: false })

          if (!tasksError && fetchedTasks) {
            tasksData = fetchedTasks
          }

          // Fetch user_tasks to calculate stats manually
          const { data: fetchedUserTasks, error: userTasksError } = await supabase
            .from("user_tasks")
            .select("task_id, status")

          if (!userTasksError && fetchedUserTasks) {
            userTasksData = fetchedUserTasks

            // Count submitted tasks
            const submittedTasks = fetchedUserTasks.filter((ut: any) => ut.status === "submitted").length
            setSubmittedTasksCount(submittedTasks)
          }
        } catch (error) {
          console.error("Error fetching specific data:", error)
        }

        // Calculate stats for each task
        const tasksWithStats = tasksData.map((task: Task) => {
          // Filter user_tasks for this specific task
          const taskAttempts = userTasksData.filter((ut: any) => ut.task_id === task.id)
          const completedCount = taskAttempts.filter((ut: any) => ut.status === "completed").length
          const pendingCount = taskAttempts.filter((ut: any) => ut.status === "pending").length
          const submittedCount = taskAttempts.filter((ut: any) => ut.status === "submitted").length

          return {
            ...task,
            stats: {
              total_attempts: taskAttempts.length,
              completed_count: completedCount,
              pending_count: pendingCount,
              submitted_count: submittedCount,
            },
          }
        })

        setTasks(tasksWithStats)
      } catch (error: any) {
        console.error("Error fetching tasks:", error)
        setError(error.message || "Failed to load tasks")
      } finally {
        setLoading(false)
      }
    }

    fetchTasks()
  }, [router])

  const deleteTask = async (taskId: string) => {
    try {
      setDeleting(taskId)

      // Use the API route instead of direct Supabase client
      const response = await fetch(`/api/admin/tasks?id=${taskId}`, {
        method: "DELETE",
        headers: {
          "x-admin-auth": "true", // Admin authentication token
        },
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || "Failed to delete task")
      }

      // Update local state
      setTasks(tasks.filter((task) => task.id !== taskId))
      setSuccess("Task deleted successfully")

      // Clear success message after 3 seconds
      setTimeout(() => setSuccess(null), 3000)
    } catch (error: any) {
      console.error("Error deleting task:", error)
      setError(error.message || "Failed to delete task. Please try again.")
    } finally {
      setDeleting(null)
    }
  }

  const toggleTaskClosed = async (taskId: string, currentStatus: boolean) => {
    try {
      setToggleTaskStatus(taskId)

      // Get the task details first
      const taskToUpdate = tasks.find((task) => task.id === taskId)
      if (!taskToUpdate) {
        throw new Error("Task not found")
      }

      // Use the API route to update the task
      const response = await fetch("/api/admin/tasks", {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          "x-admin-auth": "true", // Admin authentication token
        },
        body: JSON.stringify({
          id: taskId,
          title: taskToUpdate.title,
          description: taskToUpdate.description,
          reward: taskToUpdate.reward,
          completion_limit: taskToUpdate.completion_limit,
          is_closed: !currentStatus,
        }),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || "Failed to update task status")
      }

      // Update local state
      setTasks(tasks.map((task) => (task.id === taskId ? { ...task, is_closed: !currentStatus } : task)))

      setSuccess(`Task ${!currentStatus ? "closed" : "reopened"} successfully`)

      // Clear success message after 3 seconds
      setTimeout(() => setSuccess(null), 3000)
    } catch (error: any) {
      console.error("Error updating task status:", error)
      setError(error.message || "Failed to update task status. Please try again.")
    } finally {
      setToggleTaskStatus(null)
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <LoadingSpinner size="lg" />
      </div>
    )
  }

  if (error) {
    return (
      <div className="container mx-auto px-4 py-8">
        <Alert variant="destructive" className="mb-6">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
        <Button onClick={() => (window.location.href = "/dashboard")} className="mt-4">
          Return to Dashboard
        </Button>
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold">Manage Tasks</h1>
          <p className="text-muted-foreground">Create, edit, and delete tasks</p>
        </div>
        <div className="flex space-x-4">
          <Link href="/admin/tasks/review">
            <Button variant={submittedTasksCount > 0 ? "default" : "outline"} className="flex items-center">
              <CheckCircle className="h-4 w-4 mr-2" />
              Review Tasks
              {submittedTasksCount > 0 && <Badge className="ml-2 bg-red-500">{submittedTasksCount}</Badge>}
            </Button>
          </Link>
          <Link href="/admin/tasks/new">
            <Button>
              <PlusCircle className="h-4 w-4 mr-2" />
              Add New Task
            </Button>
          </Link>
        </div>
      </div>

      {success && (
        <Alert className="mb-6">
          <AlertDescription>{success}</AlertDescription>
        </Alert>
      )}

      <Card>
        <CardHeader>
          <CardTitle>All Tasks</CardTitle>
          <CardDescription>List of all available tasks on the platform</CardDescription>
        </CardHeader>
        <CardContent>
          {tasks.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Title</TableHead>
                  <TableHead>Reward</TableHead>
                  <TableHead>Completion</TableHead>
                  <TableHead>Limit</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Created</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {tasks.map((task) => (
                  <TableRow key={task.id} className={task.is_closed ? "bg-muted/50" : ""}>
                    <TableCell className="font-medium">{task.title}</TableCell>
                    <TableCell>{task.reward.toFixed(2)}৳</TableCell>
                    <TableCell>
                      {task.stats?.total_attempts ? (
                        <div className="flex flex-col">
                          <span className="text-sm">
                            {task.stats.completed_count} / {task.stats.total_attempts} completed
                          </span>
                          <div className="w-full bg-muted h-2 rounded-full mt-1">
                            <div
                              className="bg-primary h-2 rounded-full"
                              style={{
                                width: `${(task.stats.completed_count / task.stats.total_attempts) * 100}%`,
                              }}
                            ></div>
                          </div>
                        </div>
                      ) : (
                        <Badge variant="outline">No attempts</Badge>
                      )}
                    </TableCell>
                    <TableCell>
                      {task.completion_limit ? (
                        <Badge variant="outline">
                          {task.stats?.completed_count || 0}/{task.completion_limit}
                        </Badge>
                      ) : (
                        <Badge variant="outline">Unlimited</Badge>
                      )}
                    </TableCell>
                    <TableCell>
                      {task.is_closed ? (
                        <Badge variant="destructive">Closed</Badge>
                      ) : (
                        <Badge variant="success">Open</Badge>
                      )}
                    </TableCell>
                    <TableCell>{new Date(task.created_at).toLocaleDateString()}</TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end space-x-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => toggleTaskClosed(task.id, task.is_closed)}
                          disabled={toggleTaskStatus === task.id}
                        >
                          {toggleTaskStatus === task.id ? (
                            <LoadingSpinner size="sm" />
                          ) : task.is_closed ? (
                            <Unlock className="h-4 w-4" />
                          ) : (
                            <Lock className="h-4 w-4" />
                          )}
                        </Button>
                        <Link href={`/admin/tasks/edit/${task.id}`}>
                          <Button variant="outline" size="sm">
                            <Edit className="h-4 w-4" />
                          </Button>
                        </Link>
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button
                              variant="outline"
                              size="sm"
                              className="text-red-500"
                              disabled={deleting === task.id}
                            >
                              {deleting === task.id ? <LoadingSpinner size="sm" /> : <Trash2 className="h-4 w-4" />}
                            </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                              <AlertDialogDescription>
                                This will permanently delete the task "{task.title}". This action cannot be undone.
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel>Cancel</AlertDialogCancel>
                              <AlertDialogAction
                                onClick={() => deleteTask(task.id)}
                                className="bg-red-500 text-white hover:bg-red-600"
                              >
                                Delete
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <div className="text-center py-8">
              <h3 className="text-xl font-semibold mb-2">No tasks available</h3>
              <p className="text-muted-foreground mb-4">Create your first task to get started</p>
              <Link href="/admin/tasks/new">
                <Button>
                  <PlusCircle className="h-4 w-4 mr-2" />
                  Add New Task
                </Button>
              </Link>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
