"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { CheckCircle, XCircle, AlertCircle, ArrowLeft } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { LoadingSpinner } from "@/components/loading-spinner"
import Link from "next/link"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
  DialogClose,
} from "@/components/ui/dialog"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"

interface TaskSubmission {
  id: string
  user_id: string
  task_id: string
  status: string
  submission_details: string
  submission_date: string
  user: {
    username: string
    is_active: boolean
  }
  task: {
    title: string
    reward: number
  }
}

export default function ReviewTasks() {
  const router = useRouter()
  const [submissions, setSubmissions] = useState<TaskSubmission[]>([])
  const [loading, setLoading] = useState(true)
  const [processingId, setProcessingId] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState<string | null>(null)
  const [selectedSubmission, setSelectedSubmission] = useState<TaskSubmission | null>(null)
  const [isAdmin, setIsAdmin] = useState(false)

  useEffect(() => {
    const checkAdminAndFetchSubmissions = async () => {
      try {
        // Check if admin is authenticated via localStorage
        const adminAuthenticated = localStorage.getItem("adminAuthenticated") === "true"

        if (!adminAuthenticated) {
          router.push("/admin-login")
          return
        }

        setIsAdmin(true)

        // Fetch submitted tasks using the service role key
        const response = await fetch("/api/admin/task-submissions", {
          headers: {
            "x-admin-auth": "true", // Admin authentication token
          },
        })

        if (!response.ok) {
          const errorData = await response.json()
          throw new Error(errorData.error || "Failed to fetch task submissions")
        }

        const data = await response.json()
        setSubmissions(data.submissions || [])
      } catch (error: any) {
        console.error("Error fetching task submissions:", error)
        setError(error.message || "Failed to load task submissions")
      } finally {
        setLoading(false)
      }
    }

    checkAdminAndFetchSubmissions()
  }, [router])

  const approveSubmission = async (submissionId: string, userId: string, taskId: string) => {
    setProcessingId(submissionId)
    setError(null)
    setSuccess(null)

    try {
      const response = await fetch("/api/admin/approve-task", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-admin-auth": "true", // Admin authentication token
        },
        body: JSON.stringify({
          submissionId,
          userId,
          taskId,
        }),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || "Failed to approve task")
      }

      // Update local state
      setSubmissions(submissions.filter((submission) => submission.id !== submissionId))
      setSuccess("Task approved successfully! User has been rewarded.")

      // Clear success message after 3 seconds
      setTimeout(() => setSuccess(null), 3000)
    } catch (error: any) {
      console.error("Error approving task:", error)
      setError(error.message || "Failed to approve task. Please try again.")
    } finally {
      setProcessingId(null)
    }
  }

  const rejectSubmission = async (submissionId: string, userId: string, taskId: string) => {
    setProcessingId(submissionId)
    setError(null)
    setSuccess(null)

    try {
      const response = await fetch("/api/admin/reject-task", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-admin-auth": "true", // Admin authentication token
        },
        body: JSON.stringify({
          submissionId,
          userId,
          taskId,
        }),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || "Failed to reject task")
      }

      // Update local state
      setSubmissions(submissions.filter((submission) => submission.id !== submissionId))
      setSuccess("Task rejected successfully!")

      // Clear success message after 3 seconds
      setTimeout(() => setSuccess(null), 3000)
    } catch (error: any) {
      console.error("Error rejecting task:", error)
      setError(error.message || "Failed to reject task. Please try again.")
    } finally {
      setProcessingId(null)
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <LoadingSpinner size="lg" />
      </div>
    )
  }

  if (!isAdmin) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded mb-6">
          <p className="font-medium">Access Denied</p>
          <p>You do not have permission to access this page.</p>
        </div>
        <Button onClick={() => (window.location.href = "/dashboard")} className="mt-4">
          Return to Dashboard
        </Button>
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <Link href="/admin/tasks" className="inline-flex items-center text-primary hover:underline">
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Tasks Management
        </Link>
        <h1 className="text-3xl font-bold mt-2">Review Task Submissions</h1>
        <p className="text-muted-foreground">Approve or reject user task submissions</p>
      </div>

      {error && (
        <Alert variant="destructive" className="mb-6">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {success && (
        <Alert className="mb-6">
          <AlertDescription>{success}</AlertDescription>
        </Alert>
      )}

      <Card>
        <CardHeader>
          <CardTitle>Pending Task Submissions</CardTitle>
          <CardDescription>Review and process user task submissions</CardDescription>
        </CardHeader>
        <CardContent>
          {submissions.length > 0 ? (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>User</TableHead>
                    <TableHead>Task</TableHead>
                    <TableHead>Reward</TableHead>
                    <TableHead>Submitted</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {submissions.map((submission) => (
                    <TableRow key={submission.id}>
                      <TableCell>
                        <div className="font-medium">@{submission.user?.username || "unknown"}</div>
                      </TableCell>
                      <TableCell>{submission.task?.title}</TableCell>
                      <TableCell>{submission.task?.reward?.toFixed(2) || "0.00"}৳</TableCell>
                      <TableCell>
                        {submission.submission_date
                          ? new Date(submission.submission_date).toLocaleString()
                          : "Unknown date"}
                      </TableCell>
                      <TableCell>
                        <Badge className="bg-yellow-500">Submitted</Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end space-x-2">
                          <Dialog>
                            <DialogTrigger asChild>
                              <Button variant="outline" size="sm">
                                View Details
                              </Button>
                            </DialogTrigger>
                            <DialogContent className="max-w-2xl">
                              <DialogHeader>
                                <DialogTitle>Task Submission Details</DialogTitle>
                                <DialogDescription>
                                  Submitted by @{submission.user?.username || "unknown"} on{" "}
                                  {submission.submission_date
                                    ? new Date(submission.submission_date).toLocaleString()
                                    : "Unknown date"}
                                </DialogDescription>
                              </DialogHeader>
                              <div className="space-y-4 my-4">
                                <div>
                                  <h3 className="font-semibold">Task:</h3>
                                  <p>{submission.task?.title || "Unknown task"}</p>
                                </div>
                                <div>
                                  <h3 className="font-semibold">Reward:</h3>
                                  <p>{submission.task?.reward?.toFixed(2) || "0.00"}৳</p>
                                </div>
                                <div>
                                  <h3 className="font-semibold">Submission Details:</h3>
                                  <div className="bg-muted p-4 rounded-md whitespace-pre-wrap">
                                    {submission.submission_details || "No details provided"}
                                  </div>
                                </div>
                              </div>
                              <DialogFooter>
                                <DialogClose asChild>
                                  <Button variant="outline">Close</Button>
                                </DialogClose>
                              </DialogFooter>
                            </DialogContent>
                          </Dialog>

                          <Button
                            variant="outline"
                            size="sm"
                            className="bg-green-500 text-white hover:bg-green-600"
                            onClick={() => approveSubmission(submission.id, submission.user_id, submission.task_id)}
                            disabled={processingId === submission.id}
                          >
                            {processingId === submission.id ? (
                              <LoadingSpinner size="sm" className="mr-1" />
                            ) : (
                              <CheckCircle className="h-4 w-4 mr-1" />
                            )}
                            Approve
                          </Button>

                          <AlertDialog>
                            <AlertDialogTrigger asChild>
                              <Button
                                variant="outline"
                                size="sm"
                                className="bg-red-500 text-white hover:bg-red-600"
                                disabled={processingId === submission.id}
                              >
                                <XCircle className="h-4 w-4 mr-1" />
                                Reject
                              </Button>
                            </AlertDialogTrigger>
                            <AlertDialogContent>
                              <AlertDialogHeader>
                                <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                                <AlertDialogDescription>
                                  This will reject the task submission. The user will be notified and will need to
                                  resubmit the task.
                                </AlertDialogDescription>
                              </AlertDialogHeader>
                              <AlertDialogFooter>
                                <AlertDialogCancel>Cancel</AlertDialogCancel>
                                <AlertDialogAction
                                  onClick={() =>
                                    rejectSubmission(submission.id, submission.user_id, submission.task_id)
                                  }
                                  className="bg-red-500 text-white hover:bg-red-600"
                                >
                                  Reject
                                </AlertDialogAction>
                              </AlertDialogFooter>
                            </AlertDialogContent>
                          </AlertDialog>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          ) : (
            <div className="text-center py-8">
              <AlertCircle className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
              <h3 className="text-xl font-semibold mb-2">No pending submissions</h3>
              <p className="text-muted-foreground">When users submit tasks, they will appear here for review</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
