"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { ArrowLeft, HelpCircle } from "lucide-react"
import Link from "next/link"
import { LoadingSpinner } from "@/components/loading-spinner"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"

export default function NewTask() {
  const router = useRouter()
  const [title, setTitle] = useState("")
  const [description, setDescription] = useState("")
  const [reward, setReward] = useState("")
  const [completionLimit, setCompletionLimit] = useState<string>("")
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState<string | null>(null)
  const [isAdmin, setIsAdmin] = useState(false)
  const [checkingAdmin, setCheckingAdmin] = useState(true)

  useEffect(() => {
    const checkAdminStatus = async () => {
      try {
        // Check if admin is authenticated via localStorage
        const adminAuthenticated = localStorage.getItem("adminAuthenticated") === "true"

        if (!adminAuthenticated) {
          router.push("/admin-login")
          return
        }

        setIsAdmin(true)
        setCheckingAdmin(false)
      } catch (error) {
        console.error("Error checking admin status:", error)
        router.push("/admin-login")
      } finally {
        setCheckingAdmin(false)
      }
    }

    checkAdminStatus()
  }, [router])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError(null)
    setSuccess(null)

    try {
      // Validate inputs
      if (!title.trim()) {
        throw new Error("Task title is required")
      }

      if (!description.trim()) {
        throw new Error("Task description is required")
      }

      const rewardAmount = Number.parseFloat(reward)
      if (isNaN(rewardAmount) || rewardAmount <= 0) {
        throw new Error("Please enter a valid reward amount")
      }

      // Parse completion limit (can be null)
      let completionLimitValue = null
      if (completionLimit.trim() !== "") {
        completionLimitValue = Number.parseInt(completionLimit, 10)
        if (isNaN(completionLimitValue) || completionLimitValue <= 0) {
          throw new Error("Completion limit must be a positive number")
        }
      }

      // Use the API route instead of direct Supabase client
      const response = await fetch("/api/admin/tasks", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-admin-auth": "true", // Admin authentication token
        },
        body: JSON.stringify({
          title,
          description,
          reward: rewardAmount,
          completion_limit: completionLimitValue,
        }),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || "Failed to create task")
      }

      setSuccess("Task created successfully!")

      // Clear form
      setTitle("")
      setDescription("")
      setReward("")
      setCompletionLimit("")

      // Redirect after a short delay
      setTimeout(() => {
        router.push("/admin/tasks")
      }, 2000)
    } catch (error: any) {
      setError(error.message || "An error occurred while creating the task")
    } finally {
      setLoading(false)
    }
  }

  if (checkingAdmin) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <LoadingSpinner size="lg" />
      </div>
    )
  }

  if (!isAdmin) {
    return null // Will redirect in useEffect
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <Link href="/admin/tasks" className="inline-flex items-center text-primary hover:underline">
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Tasks
        </Link>
        <h1 className="text-3xl font-bold mt-2">Create New Task</h1>
        <p className="text-muted-foreground">Add a new task for users to complete</p>
      </div>

      {error && (
        <Alert variant="destructive" className="mb-6">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {success && (
        <Alert className="mb-6">
          <AlertDescription>{success}</AlertDescription>
        </Alert>
      )}

      <Card className="max-w-2xl mx-auto">
        <form onSubmit={handleSubmit}>
          <CardHeader>
            <CardTitle>Task Details</CardTitle>
            <CardDescription>Enter the information for the new task</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="title">Task Title</Label>
              <Input
                id="title"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Complete a survey"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="description">Task Description</Label>
              <Textarea
                id="description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Fill out a short survey about your experience with our platform."
                rows={4}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="reward">Reward Amount (৳)</Label>
              <Input
                id="reward"
                type="number"
                value={reward}
                onChange={(e) => setReward(e.target.value)}
                placeholder="5.00"
                min="0.01"
                step="0.01"
                required
              />
            </div>
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <Label htmlFor="completionLimit">Completion Limit</Label>
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <HelpCircle className="h-4 w-4 text-muted-foreground" />
                    </TooltipTrigger>
                    <TooltipContent>
                      <p className="max-w-xs">
                        Maximum number of users who can complete this task. Leave empty for unlimited.
                      </p>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
              </div>
              <Input
                id="completionLimit"
                type="number"
                value={completionLimit}
                onChange={(e) => setCompletionLimit(e.target.value)}
                placeholder="Leave empty for unlimited"
                min="1"
                step="1"
              />
              <p className="text-sm text-muted-foreground">Task will automatically close when this limit is reached</p>
            </div>
          </CardContent>
          <CardFooter className="flex justify-end space-x-2">
            <Link href="/admin/tasks">
              <Button variant="outline" type="button">
                Cancel
              </Button>
            </Link>
            <Button type="submit" disabled={loading}>
              {loading ? (
                <>
                  <LoadingSpinner size="sm" className="mr-2" /> Creating...
                </>
              ) : (
                "Create Task"
              )}
            </Button>
          </CardFooter>
        </form>
      </Card>
    </div>
  )
}
