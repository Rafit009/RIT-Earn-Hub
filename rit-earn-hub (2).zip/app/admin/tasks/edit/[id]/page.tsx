"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter, useParams } from "next/navigation"
import { supabase } from "@/lib/supabase"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { ArrowLeft, HelpCircle } from "lucide-react"
import Link from "next/link"
import { LoadingSpinner } from "@/components/loading-spinner"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { Switch } from "@/components/ui/switch"

export default function EditTask() {
  const router = useRouter()
  const params = useParams()
  const taskId = params.id as string

  const [title, setTitle] = useState("")
  const [description, setDescription] = useState("")
  const [reward, setReward] = useState("")
  const [completionLimit, setCompletionLimit] = useState<string>("")
  const [isClosed, setIsClosed] = useState(false)
  const [loading, setLoading] = useState(true)
  const [updating, setUpdating] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [message, setMessage] = useState<string | null>(null)
  const [isAdmin, setIsAdmin] = useState(false)
  const [checkingAdmin, setCheckingAdmin] = useState(true)
  const [completedCount, setCompletedCount] = useState(0)

  useEffect(() => {
    const checkAdminAndFetchTask = async () => {
      try {
        // Check if admin is authenticated via localStorage
        const adminAuthenticated = localStorage.getItem("adminAuthenticated") === "true"

        if (!adminAuthenticated) {
          router.push("/admin-login")
          return
        }

        setIsAdmin(true)

        // Fetch task data
        const { data, error } = await supabase
          .from("tasks")
          .select("*, user_tasks!inner(status)")
          .eq("id", taskId)
          .single()

        if (error) throw error

        setTitle(data.title)
        setDescription(data.description)
        setReward(data.reward.toString())
        setCompletionLimit(data.completion_limit ? data.completion_limit.toString() : "")
        setIsClosed(data.is_closed || false)

        // Count completed tasks
        const { data: completedData, error: countError } = await supabase
          .from("user_tasks")
          .select("id", { count: "exact" })
          .eq("task_id", taskId)
          .eq("status", "completed")

        if (!countError) {
          setCompletedCount(completedData?.length || 0)
        }
      } catch (error: any) {
        console.error("Error fetching task:", error)
        setError("Failed to load task. Please try again.")
      } finally {
        setLoading(false)
        setCheckingAdmin(false)
      }
    }

    if (taskId) {
      checkAdminAndFetchTask()
    }
  }, [taskId, router])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setUpdating(true)
    setError(null)
    setMessage(null)

    try {
      // Validate inputs
      if (!title.trim()) {
        throw new Error("Task title is required")
      }

      if (!description.trim()) {
        throw new Error("Task description is required")
      }

      const rewardAmount = Number.parseFloat(reward)
      if (isNaN(rewardAmount) || rewardAmount <= 0) {
        throw new Error("Please enter a valid reward amount")
      }

      // Parse completion limit (can be null)
      let completionLimitValue = null
      if (completionLimit.trim() !== "") {
        completionLimitValue = Number.parseInt(completionLimit, 10)
        if (isNaN(completionLimitValue) || completionLimitValue <= 0) {
          throw new Error("Completion limit must be a positive number")
        }
      }

      // Use the API route instead of direct Supabase client
      const response = await fetch("/api/admin/tasks", {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          "x-admin-auth": "true", // Admin authentication token
        },
        body: JSON.stringify({
          id: taskId,
          title,
          description,
          reward: rewardAmount,
          completion_limit: completionLimitValue,
          is_closed: isClosed,
        }),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || "Failed to update task")
      }

      setMessage("Task updated successfully!")
    } catch (error: any) {
      setError(error.message || "An error occurred while updating the task")
    } finally {
      setUpdating(false)
    }
  }

  if (loading || checkingAdmin) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <LoadingSpinner size="lg" />
      </div>
    )
  }

  if (!isAdmin) {
    return null // Will redirect in useEffect
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <Link href="/admin/tasks" className="inline-flex items-center text-primary hover:underline">
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Tasks
        </Link>
        <h1 className="text-3xl font-bold mt-2">Edit Task</h1>
        <p className="text-muted-foreground">Update task details</p>
      </div>

      {error && (
        <Alert variant="destructive" className="mb-6">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {message && (
        <Alert className="mb-6">
          <AlertDescription>{message}</AlertDescription>
        </Alert>
      )}

      <Card className="max-w-2xl mx-auto">
        <form onSubmit={handleSubmit}>
          <CardHeader>
            <CardTitle>Task Details</CardTitle>
            <CardDescription>Edit the information for this task</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="title">Task Title</Label>
              <Input id="title" value={title} onChange={(e) => setTitle(e.target.value)} required />
            </div>
            <div className="space-y-2">
              <Label htmlFor="description">Task Description</Label>
              <Textarea
                id="description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                rows={4}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="reward">Reward Amount (৳)</Label>
              <Input
                id="reward"
                type="number"
                value={reward}
                onChange={(e) => setReward(e.target.value)}
                min="0.01"
                step="0.01"
                required
              />
            </div>
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <Label htmlFor="completionLimit">Completion Limit</Label>
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <HelpCircle className="h-4 w-4 text-muted-foreground" />
                    </TooltipTrigger>
                    <TooltipContent>
                      <p className="max-w-xs">
                        Maximum number of users who can complete this task. Leave empty for unlimited.
                      </p>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
              </div>
              <Input
                id="completionLimit"
                type="number"
                value={completionLimit}
                onChange={(e) => setCompletionLimit(e.target.value)}
                placeholder="Leave empty for unlimited"
                min="1"
                step="1"
              />
              <p className="text-sm text-muted-foreground">
                Current completion count: <span className="font-medium">{completedCount}</span>
              </p>
            </div>
            <div className="flex items-center space-x-2 pt-2">
              <Switch id="isClosed" checked={isClosed} onCheckedChange={setIsClosed} />
              <Label htmlFor="isClosed" className="cursor-pointer">
                Mark task as closed
              </Label>
            </div>
          </CardContent>
          <CardFooter className="flex justify-between">
            <Link href="/admin/tasks">
              <Button variant="outline" type="button">
                Cancel
              </Button>
            </Link>
            <Button type="submit" disabled={updating}>
              {updating ? (
                <>
                  <LoadingSpinner size="sm" className="mr-2" /> Updating...
                </>
              ) : (
                "Update Task"
              )}
            </Button>
          </CardFooter>
        </form>
      </Card>
    </div>
  )
}
