"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { ArrowLeft } from "lucide-react"
import Link from "next/link"
import { supabase } from "@/lib/supabase"

export default function TestWebhook() {
  const [loading, setLoading] = useState(false)
  const [message, setMessage] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [amount, setAmount] = useState("100")
  const [method, setMethod] = useState("bkash")
  const [mobileNumber, setMobileNumber] = useState("01712345678")
  const [transactionId, setTransactionId] = useState("TEST123456")
  const [type, setType] = useState("deposit")

  const testWebhook = async () => {
    setLoading(true)
    setMessage(null)
    setError(null)

    try {
      // Get current user ID
      const {
        data: { session },
      } = await supabase.auth.getSession()
      if (!session) {
        throw new Error("You must be logged in to test the webhook")
      }

      const userId = session.user.id

      // Create test transaction data
      const transactionData = {
        id: `test-${Date.now()}`,
        user_id: userId,
        amount: Number.parseFloat(amount),
        method: method,
        mobile_number: mobileNumber,
        transaction_id: transactionId,
        status: "pending",
        created_at: new Date().toISOString(),
      }

      // Send direct webhook
      const response = await fetch("/api/telegram-notify", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          table: type === "deposit" ? "deposits" : "withdrawals", // Explicitly specify the table
          record: {
            new: transactionData,
          },
        }),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || "Failed to send test webhook")
      }

      setMessage(`Test ${type} webhook sent successfully! Check your Telegram.`)
    } catch (error: any) {
      setError(error.message || "An error occurred while sending the test webhook")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <Link href="/admin" className="inline-flex items-center text-primary hover:underline">
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Admin Dashboard
        </Link>
        <h1 className="text-3xl font-bold mt-2">Test Webhook</h1>
        <p className="text-muted-foreground">Test the Telegram webhook directly</p>
      </div>

      {message && (
        <Alert className="mb-6">
          <AlertDescription>{message}</AlertDescription>
        </Alert>
      )}

      {error && (
        <Alert variant="destructive" className="mb-6">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      <Card className="max-w-2xl mx-auto">
        <CardHeader>
          <CardTitle>Telegram Webhook Test</CardTitle>
          <CardDescription>Send a test transaction notification to Telegram</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="type">Transaction Type</Label>
            <select
              id="type"
              value={type}
              onChange={(e) => setType(e.target.value)}
              className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
            >
              <option value="deposit">Deposit</option>
              <option value="withdrawal">Withdrawal</option>
            </select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="amount">Amount</Label>
            <Input
              id="amount"
              type="number"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="100"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="method">Payment Method</Label>
            <Input id="method" value={method} onChange={(e) => setMethod(e.target.value)} placeholder="bkash" />
          </div>

          <div className="space-y-2">
            <Label htmlFor="mobileNumber">Mobile Number</Label>
            <Input
              id="mobileNumber"
              value={mobileNumber}
              onChange={(e) => setMobileNumber(e.target.value)}
              placeholder="01712345678"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="transactionId">Transaction ID</Label>
            <Input
              id="transactionId"
              value={transactionId}
              onChange={(e) => setTransactionId(e.target.value)}
              placeholder="TEST123456"
            />
          </div>

          <Button onClick={testWebhook} disabled={loading} className="w-full">
            {loading ? "Sending..." : "Send Test Webhook"}
          </Button>

          <div className="mt-4 p-4 bg-muted rounded-md">
            <p className="text-sm">
              This will send a test notification to the Telegram bot with the token: <br />
              <code className="bg-gray-100 px-1 py-0.5 rounded">7825284153:AAEKbga9rIBOUnSL2ndRrO6Hl1HsxS1EV7w</code>
              <br />
              and chat ID: <code className="bg-gray-100 px-1 py-0.5 rounded">6880722176</code>
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
