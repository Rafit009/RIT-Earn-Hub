"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { ArrowLeft, CheckCircle, RefreshCw } from "lucide-react"
import Link from "next/link"
import { LoadingSpinner } from "@/components/loading-spinner"

export default function ProcessReferralPage() {
  const [loading, setLoading] = useState(false)
  const [userId, setUserId] = useState("")
  const [message, setMessage] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)

  const processReferral = async () => {
    if (!userId.trim()) {
      setError("Please enter a user ID")
      return
    }

    setLoading(true)
    setError(null)
    setMessage(null)

    try {
      // Check if admin is authenticated via localStorage
      const adminAuthenticated = localStorage.getItem("adminAuthenticated") === "true"

      if (!adminAuthenticated) {
        throw new Error("You must be logged in as an admin to perform this action")
      }

      const response = await fetch("/api/admin/process-referral", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-admin-auth": "true", // Admin authentication token
        },
        body: JSON.stringify({ userId }),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || "Failed to process referral bonus")
      }

      setMessage(data.message || "Referral bonus processed successfully")
    } catch (error: any) {
      console.error("Error processing referral:", error)
      setError(error.message || "An error occurred while processing the referral bonus")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <Link href="/admin" className="inline-flex items-center text-primary hover:underline">
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Admin Dashboard
        </Link>
        <h1 className="text-3xl font-bold mt-2">Process Referral Bonus</h1>
        <p className="text-muted-foreground">Manually process referral bonuses for users</p>
      </div>

      {message && (
        <Alert className="mb-6 bg-green-50 border-green-200">
          <CheckCircle className="h-4 w-4 text-green-600" />
          <AlertDescription className="text-green-700">{message}</AlertDescription>
        </Alert>
      )}

      {error && (
        <Alert className="mb-6 bg-red-50 border-red-200">
          <AlertDescription className="text-red-700">{error}</AlertDescription>
        </Alert>
      )}

      <Card className="max-w-2xl mx-auto">
        <CardHeader>
          <CardTitle>Process Referral Bonus</CardTitle>
          <CardDescription>
            Use this tool to manually process referral bonuses for users who were referred but didn't receive their
            bonus
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="userId">User ID</Label>
            <Input
              id="userId"
              value={userId}
              onChange={(e) => setUserId(e.target.value)}
              placeholder="Enter the user ID of the referred user"
            />
            <p className="text-xs text-muted-foreground">
              This is the ID of the user who signed up using a referral code
            </p>
          </div>

          <div className="bg-amber-50 border border-amber-200 text-amber-700 p-4 rounded-md">
            <p className="text-sm font-medium">How this works:</p>
            <ul className="list-disc list-inside text-sm mt-2">
              <li>The referred user will receive 10৳ bonus</li>
              <li>The referrer will receive 35৳ bonus</li>
              <li>The referral will be marked as active</li>
              <li>The referrer's referral count will be incremented</li>
            </ul>
          </div>
        </CardContent>
        <CardFooter>
          <Button onClick={processReferral} disabled={loading} className="w-full">
            {loading ? (
              <>
                <LoadingSpinner size="sm" className="mr-2" /> Processing...
              </>
            ) : (
              "Process Referral Bonus"
            )}
          </Button>
          <Link href="/admin/fix-referrals" className="ml-2">
            <Button variant="outline" className="flex items-center">
              <RefreshCw className="h-4 w-4 mr-2" />
              Fix All Referrals
            </Button>
          </Link>
        </CardFooter>
      </Card>
    </div>
  )
}
