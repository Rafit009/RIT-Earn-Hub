"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { ExternalLink, Mail, MessageSquare, Phone, Facebook, Instagram, Twitter, Send } from "lucide-react"

export default function Contact() {
  const [name, setName] = useState("")
  const [email, setEmail] = useState("")
  const [message, setMessage] = useState("")
  const [submitting, setSubmitting] = useState(false)
  const [success, setSuccess] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setSubmitting(true)
    setSuccess(null)
    setError(null)

    try {
      // In a real implementation, you would send this data to your backend
      // For now, we'll just simulate a successful submission
      await new Promise((resolve) => setTimeout(resolve, 1000))

      setSuccess("Your message has been sent! We'll get back to you soon.")
      setName("")
      setEmail("")
      setMessage("")
    } catch (error) {
      setError("Failed to send your message. Please try again later.")
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8 animate-fade-in">
        <h1 className="text-3xl font-bold text-gradient">Contact Us</h1>
        <p className="text-muted-foreground">Get in touch with our support team</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
        <Card className="hover-lift animate-slide-in-left">
          <CardHeader>
            <CardTitle>Send Us a Message</CardTitle>
            <CardDescription>Fill out the form below to get in touch with us</CardDescription>
          </CardHeader>
          <CardContent>
            {success && (
              <Alert className="mb-4">
                <AlertDescription>{success}</AlertDescription>
              </Alert>
            )}

            {error && (
              <Alert variant="destructive" className="mb-4">
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="name">Your Name</Label>
                <Input
                  id="name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="John Doe"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="email">Your Email</Label>
                <Input
                  id="email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="john@example.com"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="message">Your Message</Label>
                <Textarea
                  id="message"
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="How can we help you?"
                  rows={5}
                  required
                />
              </div>

              <Button type="submit" className="w-full" disabled={submitting}>
                {submitting ? "Sending..." : "Send Message"}
              </Button>
            </form>
          </CardContent>
        </Card>

        <Card className="hover-lift animate-slide-in-right">
          <CardHeader>
            <CardTitle>Contact Information</CardTitle>
            <CardDescription>Here's how you can reach us</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-4">
              <div className="flex items-start space-x-3">
                <div className="bg-primary/10 rounded-full p-2 mt-0.5">
                  <Mail className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <h3 className="font-medium">Email</h3>
                  <p className="text-sm text-muted-foreground">support@ritearnhub.com</p>
                  <p className="text-sm text-muted-foreground">info@ritearnhub.com</p>
                </div>
              </div>

              <div className="flex items-start space-x-3">
                <div className="bg-primary/10 rounded-full p-2 mt-0.5">
                  <Phone className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <h3 className="font-medium">Phone</h3>
                  <p className="text-sm text-muted-foreground">+880 1736392836 (Nagad)</p>
                  <p className="text-sm text-muted-foreground">+880 1833486175 (bKash)</p>
                </div>
              </div>

              <div className="flex items-start space-x-3">
                <div className="bg-primary/10 rounded-full p-2 mt-0.5">
                  <MessageSquare className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <h3 className="font-medium">Telegram</h3>
                  <a
                    href="https://t.me/ritzoneofficial"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-primary inline-flex items-center hover:underline"
                  >
                    t.me/ritzoneofficial <ExternalLink className="h-3 w-3 ml-1" />
                  </a>
                  <p className="text-sm text-muted-foreground mt-1">
                    Join our official Telegram channel for announcements, vouchers, and support
                  </p>
                </div>
              </div>
            </div>

            <div className="bg-blue-50 border border-blue-200 rounded-md p-4 mt-6">
              <h3 className="font-medium text-blue-800 flex items-center">
                <MessageSquare className="h-4 w-4 mr-2" /> Join Our Telegram Community
              </h3>
              <p className="text-sm text-blue-700 mt-2">
                Get exclusive vouchers, instant support, and stay updated with the latest news by joining our official
                Telegram channel.
              </p>
              <a
                href="https://t.me/ritzoneofficial"
                target="_blank"
                rel="noopener noreferrer"
                className="mt-3 inline-flex items-center bg-blue-600 text-white px-4 py-2 rounded-md text-sm font-medium hover:bg-blue-700 transition-colors"
              >
                Join Now <ExternalLink className="h-3 w-3 ml-2" />
              </a>
            </div>

            <div className="border-t pt-4 mt-4">
              <h3 className="font-medium">Business Hours</h3>
              <p className="text-sm text-muted-foreground mt-1">Monday - Friday: 9:00 AM - 6:00 PM</p>
              <p className="text-sm text-muted-foreground">Saturday: 10:00 AM - 4:00 PM</p>
              <p className="text-sm text-muted-foreground">Sunday: Closed</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Contact the Developer Section */}
      <Card className="hover-lift animate-slide-up mb-8">
        <CardHeader>
          <CardTitle className="text-gradient">Contact the Developer</CardTitle>
          <CardDescription>Get in touch with the developer directly for technical assistance</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col md:flex-row items-center mb-6">
            <div className="w-20 h-20 bg-primary/10 rounded-full flex items-center justify-center mb-4 md:mb-0 md:mr-6">
              <span className="text-xl font-bold text-primary">SRH</span>
            </div>
            <div className="text-center md:text-left">
              <h3 className="text-xl font-bold mb-1">Sheikh Rafit Hasan</h3>
              <p className="text-muted-foreground">Full Stack Developer & Founder</p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 mt-6">
            <a
              href="mailto:sheikhrafithasan@gmail.com"
              className="flex items-center p-3 border border-gray-200 rounded-lg hover:bg-primary/5 transition-colors"
            >
              <Mail className="h-5 w-5 text-primary mr-3" />
              <span className="text-sm">sheikhrafithasan@gmail.com</span>
            </a>

            <a
              href="https://t.me/Knock_rafit_bot"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center p-3 border border-gray-200 rounded-lg hover:bg-primary/5 transition-colors"
            >
              <Send className="h-5 w-5 text-primary mr-3" />
              <span className="text-sm">t.me/Knock_rafit_bot</span>
            </a>

            <a
              href="https://www.facebook.com/sheikh.rafit.hasan.official/"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center p-3 border border-gray-200 rounded-lg hover:bg-primary/5 transition-colors"
            >
              <Facebook className="h-5 w-5 text-primary mr-3" />
              <span className="text-sm">Facebook</span>
            </a>

            <a
              href="https://www.instagram.com/rafit_official/"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center p-3 border border-gray-200 rounded-lg hover:bg-primary/5 transition-colors"
            >
              <Instagram className="h-5 w-5 text-primary mr-3" />
              <span className="text-sm">Instagram</span>
            </a>

            <a
              href="https://x.com/rafit_official"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center p-3 border border-gray-200 rounded-lg hover:bg-primary/5 transition-colors"
            >
              <Twitter className="h-5 w-5 text-primary mr-3" />
              <span className="text-sm">Twitter</span>
            </a>
          </div>

          <div className="mt-6 p-4 bg-primary/5 rounded-lg">
            <p className="text-sm">
              <strong>Note:</strong> For technical issues, bug reports, or feature requests, contacting the developer
              directly may provide faster resolution than general support channels.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
