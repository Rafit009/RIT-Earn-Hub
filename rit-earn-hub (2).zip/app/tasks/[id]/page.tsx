"use client"

import { useEffect, useState } from "react"
import { useRouter, useParams } from "next/navigation"
import { supabase } from "@/lib/supabase"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Textarea } from "@/components/ui/textarea"
import { LoadingSpinner } from "@/components/loading-spinner"
import { ArrowLeft, CheckCircle, Clock, AlertCircle, Lock } from "lucide-react"
import Link from "next/link"

interface Task {
  id: string
  title: string
  description: string
  reward: number
  completion_limit: number | null
  is_closed: boolean
  created_at: string
}

interface UserTask {
  id: string
  user_id: string
  task_id: string
  status: string
  started_at: string | null
  submission_date: string | null
  submission_details: string | null
}

export default function TaskDetailPage() {
  const router = useRouter()
  const params = useParams()
  const taskId = params.id as string

  const [task, setTask] = useState<Task | null>(null)
  const [userTask, setUserTask] = useState<UserTask | null>(null)
  const [userId, setUserId] = useState<string | null>(null)
  const [loading, setLoading] = useState(true)
  const [submitting, setSubmitting] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState<string | null>(null)
  const [submissionDetails, setSubmissionDetails] = useState("")
  const [isActive, setIsActive] = useState(false)
  const [completedCount, setCompletedCount] = useState(0)

  useEffect(() => {
    const fetchTaskDetails = async () => {
      try {
        const {
          data: { session },
        } = await supabase.auth.getSession()

        if (!session) {
          router.push("/login")
          return
        }

        setUserId(session.user.id)

        // Check if account is active
        const { data: profileData, error: profileError } = await supabase
          .from("profiles")
          .select("is_active")
          .eq("id", session.user.id)
          .single()

        if (profileError) {
          console.error("Error fetching profile:", profileError)
          setError("Failed to load user profile. Please try again.")
          setLoading(false)
          return
        }

        setIsActive(profileData.is_active || false)

        // Fetch task details
        const { data: taskData, error: taskError } = await supabase.from("tasks").select("*").eq("id", taskId).single()

        if (taskError) {
          console.error("Error fetching task:", taskError)
          setError("Failed to load task details. Please try again.")
          setLoading(false)
          return
        }

        setTask(taskData)

        // Count completed tasks for this task
        const { count, error: countError } = await supabase
          .from("user_tasks")
          .select("*", { count: "exact" })
          .eq("task_id", taskId)
          .eq("status", "completed")

        if (!countError) {
          setCompletedCount(count || 0)
        }

        // Fetch user task status
        const { data: userTaskData, error: userTaskError } = await supabase
          .from("user_tasks")
          .select("*")
          .eq("user_id", session.user.id)
          .eq("task_id", taskId)
          .single()

        if (userTaskError && userTaskError.code !== "PGRST116") {
          console.error("Error fetching user task:", userTaskError)
        } else if (userTaskData) {
          setUserTask(userTaskData)
        }

        setLoading(false)
      } catch (error: any) {
        console.error("Error in task detail page:", error)
        setError("An unexpected error occurred. Please try again.")
        setLoading(false)
      }
    }

    fetchTaskDetails()
  }, [taskId, router])

  const startTask = async () => {
    if (!userId || !isActive) return

    try {
      setSubmitting(true)
      setError(null)

      const response = await fetch("/api/tasks/start-task", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          taskId,
          userId,
        }),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || "Failed to start task")
      }

      setUserTask(data.task)
      setSuccess("Task started successfully!")
    } catch (error: any) {
      console.error("Error starting task:", error)
      setError(error.message || "Failed to start task. Please try again.")
    } finally {
      setSubmitting(false)
    }
  }

  const submitTask = async () => {
    if (!userId || !isActive || !userTask) return

    try {
      setSubmitting(true)
      setError(null)

      if (!submissionDetails.trim()) {
        setError("Please provide details about how you completed the task")
        setSubmitting(false)
        return
      }

      const response = await fetch("/api/tasks/submit-task", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          taskId,
          userId,
          submissionDetails,
        }),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || "Failed to submit task")
      }

      setSuccess(data.message || "Task submitted successfully!")

      // Update local state
      setUserTask({
        ...userTask,
        status: "submitted",
        submission_date: new Date().toISOString(),
        submission_details: submissionDetails,
      })

      // Redirect after a short delay
      setTimeout(() => {
        router.push("/tasks?message=Task submitted successfully and sent for review")
      }, 2000)
    } catch (error: any) {
      console.error("Error submitting task:", error)
      setError(error.message || "Failed to submit task. Please try again.")
    } finally {
      setSubmitting(false)
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <LoadingSpinner size="lg" />
      </div>
    )
  }

  if (!task) {
    return (
      <div className="container mx-auto px-4 py-8">
        <Alert variant="destructive">
          <AlertDescription>Task not found</AlertDescription>
        </Alert>
        <div className="mt-4">
          <Link href="/tasks">
            <Button variant="outline">
              <ArrowLeft className="h-4 w-4 mr-2" /> Back to Tasks
            </Button>
          </Link>
        </div>
      </div>
    )
  }

  const isStarted = userTask?.status === "pending"
  const isSubmitted = userTask?.status === "submitted" || userTask?.status === "completed"
  const isTaskClosed = task.is_closed || (task.completion_limit !== null && completedCount >= task.completion_limit)

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-6">
        <Link href="/tasks">
          <Button variant="outline" className="mb-4">
            <ArrowLeft className="h-4 w-4 mr-2" /> Back to Tasks
          </Button>
        </Link>
      </div>

      <Card className="mb-6">
        <CardHeader>
          <div className="flex justify-between items-start">
            <CardTitle className="text-gradient text-2xl">{task.title}</CardTitle>
            <div className="flex space-x-2">
              {isTaskClosed && (
                <span className="inline-flex items-center text-red-600 bg-red-100 px-3 py-1 rounded-full text-sm">
                  <Lock className="h-4 w-4 mr-1" /> Closed
                </span>
              )}
              {isSubmitted ? (
                <span className="inline-flex items-center text-green-600 bg-green-100 px-3 py-1 rounded-full text-sm">
                  <CheckCircle className="h-4 w-4 mr-1" /> Submitted
                </span>
              ) : isStarted ? (
                <span className="inline-flex items-center text-amber-600 bg-amber-100 px-3 py-1 rounded-full text-sm">
                  <Clock className="h-4 w-4 mr-1" /> In Progress
                </span>
              ) : (
                <span className="inline-flex items-center text-blue-600 bg-blue-100 px-3 py-1 rounded-full text-sm">
                  <AlertCircle className="h-4 w-4 mr-1" /> Not Started
                </span>
              )}
            </div>
          </div>
          <CardDescription>
            Reward: <span className="text-gradient-success font-semibold">{task.reward.toFixed(2)}৳</span>
            {task.completion_limit && (
              <span className="ml-4">
                Completion:{" "}
                <span className="font-semibold">
                  {completedCount}/{task.completion_limit}
                </span>
              </span>
            )}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="prose max-w-none">
            <h3 className="text-lg font-semibold mb-2">Task Description</h3>
            <p className="whitespace-pre-line">{task.description}</p>
          </div>
        </CardContent>
      </Card>

      {error && (
        <Alert variant="destructive" className="mb-6">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {success && (
        <Alert className="mb-6 bg-green-50 border-green-200">
          <CheckCircle className="h-4 w-4 text-green-600" />
          <AlertDescription className="text-green-700">{success}</AlertDescription>
        </Alert>
      )}

      {!isActive && (
        <Alert className="mb-6 bg-yellow-50 border-yellow-200">
          <AlertCircle className="h-4 w-4 text-yellow-600" />
          <AlertDescription className="text-yellow-700">
            Your account is not activated yet. You need to deposit at least 50৳ to activate your account.
            <Link href="/deposit" className="ml-2 text-primary underline">
              Deposit now
            </Link>
          </AlertDescription>
        </Alert>
      )}

      {isTaskClosed && !isSubmitted && (
        <Alert className="mb-6 bg-red-50 border-red-200">
          <Lock className="h-4 w-4 text-red-600" />
          <AlertDescription className="text-red-700">
            This task is no longer available for completion. It has reached its maximum number of completions or has
            been closed by an admin.
          </AlertDescription>
        </Alert>
      )}

      <Card>
        <CardHeader>
          <CardTitle>Task Actions</CardTitle>
        </CardHeader>
        <CardContent>
          {isSubmitted ? (
            <div className="text-center py-4">
              <CheckCircle className="h-12 w-12 mx-auto text-green-500 mb-2" />
              <h3 className="text-xl font-semibold mb-2">Task Submitted</h3>
              <p className="text-muted-foreground">
                Your submission is being reviewed by our team. You will receive your reward once approved.
              </p>
            </div>
          ) : isStarted ? (
            <div className="space-y-4">
              <div>
                <h3 className="text-lg font-semibold mb-2">Submit Your Work</h3>
                <p className="text-muted-foreground mb-4">
                  Please provide details about how you completed this task. This will help us verify your work.
                </p>
                <Textarea
                  placeholder="Describe how you completed the task..."
                  value={submissionDetails}
                  onChange={(e) => setSubmissionDetails(e.target.value)}
                  rows={5}
                  className="mb-4"
                  disabled={isTaskClosed}
                />
              </div>
              <Button
                onClick={submitTask}
                disabled={submitting || !isActive || !submissionDetails.trim() || isTaskClosed}
                className="w-full"
              >
                {submitting ? (
                  <>
                    <LoadingSpinner size="sm" className="mr-2" /> Submitting...
                  </>
                ) : (
                  <>
                    <CheckCircle className="h-4 w-4 mr-2" /> Yes, I have done it
                  </>
                )}
              </Button>
            </div>
          ) : (
            <div className="text-center py-4">
              <Button onClick={startTask} disabled={submitting || !isActive || isTaskClosed} className="w-full">
                {submitting ? (
                  <>
                    <LoadingSpinner size="sm" className="mr-2" /> Starting...
                  </>
                ) : isTaskClosed ? (
                  <>Task Unavailable</>
                ) : (
                  <>Start Task</>
                )}
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
