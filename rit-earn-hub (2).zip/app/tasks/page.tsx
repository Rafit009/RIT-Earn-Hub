"use client"

import { useEffect, useState } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import { supabase } from "@/lib/supabase"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { LoadingSpinner } from "@/components/loading-spinner"
import { AlertCircle, CheckCircle, Clock, ArrowRight } from "lucide-react"
import Link from "next/link"

interface Task {
  id: string
  title: string
  description: string
  reward: number
  user_task?: {
    status: string
  }[]
}

export default function TasksPage() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const message = searchParams.get("message")

  const [loading, setLoading] = useState(true)
  const [tasks, setTasks] = useState<Task[]>([])
  const [userId, setUserId] = useState<string | null>(null)
  const [isActive, setIsActive] = useState(false)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const fetchTasks = async () => {
      try {
        const {
          data: { session },
        } = await supabase.auth.getSession()

        if (!session) {
          router.push("/login")
          return
        }

        setUserId(session.user.id)

        // Check if account is active
        const { data: profileData, error: profileError } = await supabase
          .from("profiles")
          .select("is_active")
          .eq("id", session.user.id)
          .single()

        if (profileError) {
          console.error("Error fetching profile:", profileError)
          setError("Failed to load user profile. Please try again.")
          setLoading(false)
          return
        }

        setIsActive(profileData.is_active || false)

        // Fetch tasks with user_task status using service role key for reliable access
        const adminSupabase = supabase.auth.admin

        const { data, error: tasksError } = await supabase
          .from("tasks")
          .select(`
            *,
            user_task:user_tasks(status)
          `)
          .eq("user_task.user_id", session.user.id)
          .or("user_task.is.null")
          .order("created_at", { ascending: false })

        if (tasksError) {
          console.error("Error fetching tasks:", tasksError)
          setError("Failed to load tasks. Please try again.")
          setLoading(false)
          return
        }

        // Filter out completed and submitted tasks
        const filteredTasks = data.filter((task) => {
          // If user_task is null, task is available
          if (!task.user_task || task.user_task.length === 0) return true

          // If user_task exists, only show if status is pending
          return task.user_task[0]?.status === "pending"
        })

        setTasks(filteredTasks)
        setLoading(false)
      } catch (error: any) {
        console.error("Error in tasks page:", error)
        setError("An unexpected error occurred. Please try again.")
        setLoading(false)
      }
    }

    fetchTasks()
  }, [router])

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <LoadingSpinner size="lg" />
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">Available Tasks</h1>

      {message && (
        <Alert className="mb-6">
          <AlertDescription>{message}</AlertDescription>
        </Alert>
      )}

      {error && (
        <Alert variant="destructive" className="mb-6">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {!isActive && (
        <Alert className="mb-6 bg-yellow-50 border-yellow-200">
          <AlertCircle className="h-4 w-4 text-yellow-600" />
          <AlertDescription className="text-yellow-700">
            Your account is not activated yet. You need to deposit at least 50৳ to activate your account.
            <Link href="/deposit" className="ml-2 text-primary underline">
              Deposit now
            </Link>
          </AlertDescription>
        </Alert>
      )}

      {tasks.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {tasks.map((task) => {
            const userTask = task.user_task && task.user_task.length > 0 ? task.user_task[0] : null
            const isStarted = userTask?.status === "pending"

            return (
              <Card key={task.id} className="animate-fade-in hover:shadow-lg transition-shadow">
                <CardHeader>
                  <CardTitle className="text-gradient">{task.title}</CardTitle>
                  <CardDescription>
                    Reward: <span className="text-gradient-success font-semibold">{task.reward.toFixed(2)}৳</span>
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="line-clamp-3">{task.description}</p>
                </CardContent>
                <CardFooter className="flex justify-between items-center">
                  <div>
                    {isStarted ? (
                      <span className="inline-flex items-center text-amber-600">
                        <Clock className="h-4 w-4 mr-1" /> In Progress
                      </span>
                    ) : (
                      <span className="inline-flex items-center text-green-600">
                        <CheckCircle className="h-4 w-4 mr-1" /> Available
                      </span>
                    )}
                  </div>
                  <Button onClick={() => router.push(`/tasks/${task.id}`)} disabled={!isActive} className="hover-scale">
                    {isStarted ? "Continue" : "Start Task"} <ArrowRight className="h-4 w-4 ml-1" />
                  </Button>
                </CardFooter>
              </Card>
            )
          })}
        </div>
      ) : (
        <div className="text-center py-12">
          <AlertCircle className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
          <h3 className="text-xl font-semibold mb-2">No tasks available</h3>
          <p className="text-muted-foreground">Check back later for new tasks</p>
        </div>
      )}
    </div>
  )
}
