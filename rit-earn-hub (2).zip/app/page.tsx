import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ExternalLink, MessageSquare, Mail, Facebook, Instagram, Twitter, Send } from "lucide-react"

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen">
      <header className="bg-primary text-primary-foreground py-4">
        <div className="container mx-auto px-4 flex justify-between items-center">
          <div className="flex items-center space-x-2 animate-slide-in-left">
            <img src="/images/logo.png" alt="RIT Earn Hub Logo" className="h-10 w-10 rounded-full animate-bounce-in" />
            <h1 className="text-2xl font-bold font-montserrat tracking-tight">RIT Earn Hub</h1>
          </div>
          <div className="space-x-2 animate-slide-in-right">
            <Link href="/login">
              <Button variant="outline" className="bg-primary-foreground text-primary hover-scale">
                Login
              </Button>
            </Link>
            <Link href="/signup">
              <Button className="hover-scale shadow-lg">Sign Up</Button>
            </Link>
          </div>
        </div>
      </header>

      <main className="flex-1">
        <section className="py-20 bg-gradient-to-b from-primary/10 to-background relative overflow-hidden">
          {/* Animated background elements */}
          <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none">
            <div className="absolute top-10 left-10 w-64 h-64 bg-blue-400 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-pulse-subtle"></div>
            <div
              className="absolute bottom-10 right-10 w-64 h-64 bg-indigo-400 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-pulse-subtle"
              style={{ animationDelay: "1s" }}
            ></div>
          </div>

          <div className="container mx-auto px-4 text-center relative z-10">
            <h2 className="text-5xl md:text-6xl font-bold mb-6 animate-slide-up text-gradient">
              Earn Rewards by Completing Tasks
            </h2>
            <p className="text-xl mb-8 max-w-2xl mx-auto animate-slide-up delay-200 opacity-90">
              Join RIT Earn Hub today to start earning rewards by completing simple tasks and referring your friends.
            </p>
            <Link href="/signup">
              <Button
                size="lg"
                className="font-semibold animate-slide-up delay-300 hover-lift shadow-lg px-8 py-6 text-lg"
              >
                Get Started Now
              </Button>
            </Link>
          </div>
        </section>

        {/* Telegram Channel Highlight Section */}
        <section className="py-8 bg-blue-50">
          <div className="container mx-auto px-4">
            <div className="flex flex-col md:flex-row items-center justify-between p-6 bg-white rounded-xl shadow-md border border-blue-100 animate-slide-up">
              <div className="flex items-center mb-4 md:mb-0">
                <div className="bg-blue-100 p-3 rounded-full mr-4">
                  <MessageSquare className="h-8 w-8 text-blue-600" />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-blue-800">Join Our Telegram Channel</h3>
                  <p className="text-blue-600">Get exclusive vouchers, instant support, and latest updates</p>
                </div>
              </div>
              <a
                href="https://t.me/ritzoneofficial"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center bg-blue-600 text-white px-6 py-3 rounded-md font-medium hover:bg-blue-700 transition-colors hover-lift"
              >
                Join Now <ExternalLink className="h-4 w-4 ml-2" />
              </a>
            </div>
          </div>
        </section>

        <section className="py-16">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold mb-12 text-center animate-fade-in">How It Works</h2>
            <div className="grid md:grid-cols-3 gap-8">
              <div className="bg-card p-6 rounded-lg shadow-sm hover-lift animate-slide-up delay-100">
                <div className="bg-primary/10 w-16 h-16 rounded-full flex items-center justify-center mb-4 mx-auto">
                  <span className="text-primary font-bold text-2xl">1</span>
                </div>
                <h3 className="text-xl font-semibold mb-2 text-center">Complete Tasks</h3>
                <p className="text-muted-foreground text-center">
                  Earn rewards by completing simple tasks on our platform.
                </p>
              </div>

              <div className="bg-card p-6 rounded-lg shadow-sm hover-lift animate-slide-up delay-200">
                <div className="bg-primary/10 w-16 h-16 rounded-full flex items-center justify-center mb-4 mx-auto">
                  <span className="text-primary font-bold text-2xl">2</span>
                </div>
                <h3 className="text-xl font-semibold mb-2 text-center">Refer Friends</h3>
                <p className="text-muted-foreground text-center">
                  Share your unique referral link and earn when your friends join.
                </p>
              </div>

              <div className="bg-card p-6 rounded-lg shadow-sm hover-lift animate-slide-up delay-300">
                <div className="bg-primary/10 w-16 h-16 rounded-full flex items-center justify-center mb-4 mx-auto">
                  <span className="text-primary font-bold text-2xl">3</span>
                </div>
                <h3 className="text-xl font-semibold mb-2 text-center">Cash Out</h3>
                <p className="text-muted-foreground text-center">
                  Withdraw your earnings via Bkash or Nagad when you're ready.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* New testimonials section */}
        <section className="py-16 bg-gradient-to-b from-background to-primary/5">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold mb-12 text-center animate-fade-in">What Our Users Say</h2>
            <div className="grid md:grid-cols-2 gap-8">
              <div className="bg-white p-6 rounded-lg shadow-md hover-lift animate-slide-in-left">
                <div className="flex items-center mb-4">
                  <div className="w-12 h-12 bg-primary/20 rounded-full flex items-center justify-center mr-4">
                    <span className="font-bold text-primary">JD</span>
                  </div>
                  <div>
                    <h4 className="font-semibold">John Doe</h4>
                    <p className="text-sm text-muted-foreground">Member since 2023</p>
                  </div>
                </div>
                <p className="italic text-muted-foreground">
                  "I've earned over 5000৳ in just two months by completing simple tasks and referring my friends. This
                  platform is amazing!"
                </p>
              </div>

              <div className="bg-white p-6 rounded-lg shadow-md hover-lift animate-slide-in-right">
                <div className="flex items-center mb-4">
                  <div className="w-12 h-12 bg-primary/20 rounded-full flex items-center justify-center mr-4">
                    <span className="font-bold text-primary">JS</span>
                  </div>
                  <div>
                    <h4 className="font-semibold">Jane Smith</h4>
                    <p className="text-sm text-muted-foreground">Member since 2023</p>
                  </div>
                </div>
                <p className="italic text-muted-foreground">
                  "The referral system is fantastic! I invited 10 friends and now I'm earning passive income from their
                  activities. Highly recommended!"
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Contact the Developer Section */}
        <section className="py-16 bg-gradient-to-b from-primary/5 to-background">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold mb-6 text-center animate-fade-in">Contact the Developer</h2>
            <p className="text-center text-muted-foreground mb-12 max-w-2xl mx-auto">
              Have questions, suggestions, or need technical assistance? Reach out to the developer directly through any
              of these channels.
            </p>

            <div className="bg-white rounded-xl shadow-lg p-8 max-w-3xl mx-auto hover-lift">
              <div className="flex flex-col md:flex-row items-center mb-6">
                <div className="w-24 h-24 bg-primary/10 rounded-full flex items-center justify-center mb-4 md:mb-0 md:mr-6">
                  <span className="text-2xl font-bold text-primary">SRH</span>
                </div>
                <div className="text-center md:text-left">
                  <h3 className="text-2xl font-bold text-gradient mb-1">Sheikh Rafit Hasan</h3>
                  <p className="text-muted-foreground">Full Stack Developer & Founder</p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-6">
                <a
                  href="mailto:sheikhrafithasan@gmail.com"
                  className="flex items-center p-3 border border-gray-200 rounded-lg hover:bg-primary/5 transition-colors"
                >
                  <Mail className="h-5 w-5 text-primary mr-3" />
                  <span>sheikhrafithasan@gmail.com</span>
                </a>

                <a
                  href="https://t.me/Knock_rafit_bot"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center p-3 border border-gray-200 rounded-lg hover:bg-primary/5 transition-colors"
                >
                  <Send className="h-5 w-5 text-primary mr-3" />
                  <span>t.me/Knock_rafit_bot</span>
                </a>

                <a
                  href="https://www.facebook.com/sheikh.rafit.hasan.official/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center p-3 border border-gray-200 rounded-lg hover:bg-primary/5 transition-colors"
                >
                  <Facebook className="h-5 w-5 text-primary mr-3" />
                  <span>Facebook</span>
                </a>

                <a
                  href="https://www.instagram.com/rafit_official/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center p-3 border border-gray-200 rounded-lg hover:bg-primary/5 transition-colors"
                >
                  <Instagram className="h-5 w-5 text-primary mr-3" />
                  <span>Instagram</span>
                </a>

                <a
                  href="https://x.com/rafit_official"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center p-3 border border-gray-200 rounded-lg hover:bg-primary/5 transition-colors"
                >
                  <Twitter className="h-5 w-5 text-primary mr-3" />
                  <span>Twitter</span>
                </a>
              </div>

              <div className="mt-6 text-center">
                <p className="text-sm text-muted-foreground">
                  For business inquiries or technical support, please allow 24-48 hours for a response.
                </p>
              </div>
            </div>
          </div>
        </section>
      </main>

      <footer className="bg-muted py-8">
        <div className="container mx-auto px-4 text-center">
          <div className="flex flex-col md:flex-row justify-between items-center mb-8">
            <div className="flex items-center space-x-2 mb-4 md:mb-0">
              <img src="/images/logo.png" alt="RIT Earn Hub Logo" className="h-8 w-8 rounded-full" />
              <span className="text-xl font-bold">RIT Earn Hub</span>
            </div>
            <div className="flex space-x-6">
              <Link href="/contact" className="text-muted-foreground hover:text-primary transition-colors">
                Contact
              </Link>
              <a href="#" className="text-muted-foreground hover:text-primary transition-colors">
                About
              </a>
              <a href="#" className="text-muted-foreground hover:text-primary transition-colors">
                Terms
              </a>
              <a href="#" className="text-muted-foreground hover:text-primary transition-colors">
                Privacy
              </a>
              <a
                href="https://t.me/ritzoneofficial"
                target="_blank"
                rel="noopener noreferrer"
                className="text-primary hover:text-primary/80 transition-colors flex items-center"
              >
                Telegram <ExternalLink className="h-3 w-3 ml-1" />
              </a>
            </div>
          </div>
          <div className="border-t border-border pt-6">
            <p className="text-muted-foreground">© {new Date().getFullYear()} RIT Earn Hub. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
