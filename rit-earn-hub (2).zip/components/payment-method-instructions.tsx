"use client"

import { useEffect, useState } from "react"
import { supabase } from "@/lib/supabase"
import { useSettings } from "@/contexts/settings-context"

interface PaymentMethod {
  id: string
  name: string
  display_name: string
  account_number: string
  instructions: string
  is_active: boolean
  for_deposit: boolean
  for_withdrawal: boolean
}

interface PaymentMethodInstructionsProps {
  methodName: string
  type: "deposit" | "withdrawal"
}

export function PaymentMethodInstructions({ methodName, type }: PaymentMethodInstructionsProps) {
  const [method, setMethod] = useState<PaymentMethod | null>(null)
  const [loading, setLoading] = useState(true)
  const { getSetting } = useSettings()

  useEffect(() => {
    const fetchPaymentMethod = async () => {
      try {
        setLoading(true)

        const { data, error } = await supabase
          .from("payment_methods")
          .select("*")
          .eq("name", methodName)
          .eq("is_active", true)
          .single()

        if (error) {
          console.error("Error fetching payment method:", error)
          return
        }

        setMethod(data)
      } catch (error) {
        console.error("Error in payment method instructions:", error)
      } finally {
        setLoading(false)
      }
    }

    if (methodName) {
      fetchPaymentMethod()
    }
  }, [methodName])

  if (loading || !method) {
    return null
  }

  const minAmount = type === "deposit" ? getSetting("min_deposit", 50) : getSetting("min_withdrawal", 50)

  return (
    <div className="space-y-4">
      <h3 className="font-semibold">{method.display_name} Instructions:</h3>
      <div className="space-y-2">
        <p className="text-sm font-medium">English Instructions:</p>
        <ol className="list-decimal list-inside space-y-1 text-sm">
          <li>Open your {method.display_name} app</li>
          <li>Select "{type === "deposit" ? "Send Money" : "Cash Out"}"</li>
          <li>
            {type === "deposit" ? (
              <>
                Enter our {method.display_name} number: <span className="font-semibold">{method.account_number}</span>
              </>
            ) : (
              <>Enter your {method.display_name} number where you want to receive the money</>
            )}
          </li>
          <li>
            Enter the amount you want to {type === "deposit" ? "deposit" : "withdraw"} (minimum {minAmount}৳)
          </li>
          <li>
            {type === "deposit" ? (
              <>Complete the transaction and note the Transaction ID</>
            ) : (
              <>Submit your request and wait for processing</>
            )}
          </li>
        </ol>
      </div>
      <div className="space-y-2">
        <p className="text-sm font-medium">বাংলা নির্দেশনা:</p>
        <ol className="list-decimal list-inside space-y-1 text-sm">
          <li>আপনার {method.display_name} অ্যাপ খুলুন</li>
          <li>"{type === "deposit" ? "সেন্ড মানি" : "ক্যাশ আউট"}" নির্বাচন করুন</li>
          <li>
            {type === "deposit" ? (
              <>
                আমাদের {method.display_name} নম্বর লিখুন: <span className="font-semibold">{method.account_number}</span>
              </>
            ) : (
              <>আপনার {method.display_name} নম্বর লিখুন যেখানে আপনি অর্থ পেতে চান</>
            )}
          </li>
          <li>
            আপনি যে পরিমাণ {type === "deposit" ? "জমা" : "উত্তোলন"} করতে চান তা লিখুন (ন্যূনতম {minAmount}৳)
          </li>
          <li>
            {type === "deposit" ? (
              <>লেনদেন সম্পূর্ণ করুন এবং ট্রানজেকশন আইডি নোট করুন</>
            ) : (
              <>আপনার অনুরোধ জমা দিন এবং প্রক্রিয়াকরণের জন্য অপেক্ষা করুন</>
            )}
          </li>
        </ol>
      </div>
      {method.instructions && (
        <div className="bg-muted p-4 rounded-md">
          <p className="text-sm">{method.instructions}</p>
        </div>
      )}
    </div>
  )
}
