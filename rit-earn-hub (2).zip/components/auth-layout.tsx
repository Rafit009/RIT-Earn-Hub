import type React from "react"
import Link from "next/link"

interface AuthLayoutProps {
  children: React.ReactNode
  title: string
  subtitle: string
  alternateLink: {
    text: string
    href: string
    label: string
  }
}

export default function AuthLayout({ children, title, subtitle, alternateLink }: AuthLayoutProps) {
  return (
    <div className="min-h-screen flex flex-col md:flex-row">
      {/* Left side - Branding and graphics */}
      <div className="bg-[#5E4FDB] text-white md:w-1/2 p-8 flex flex-col justify-between">
        <div>
          <Link href="/" className="flex items-center gap-2 mb-6">
            <img src="/logo.png" alt="Rafit IT Zone" className="w-10 h-10 object-contain" />
            <span className="text-xl font-bold">Rafit IT Zone Earn</span>
          </Link>

          <h1 className="text-4xl font-bold mb-4">Welcome to Rafit IT Zone Earn</h1>
          <p className="text-xl">Complete tasks, earn rewards, and grow your income.</p>
        </div>

        <div className="mt-8">
          <p className="text-sm opacity-80">© {new Date().getFullYear()} Rafit IT Zone. All rights reserved.</p>
        </div>
      </div>

      {/* Right side - Form */}
      <div className="md:w-1/2 p-8 flex items-center justify-center">
        <div className="w-full max-w-md">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold text-gray-900">{title}</h2>
            <p className="mt-2 text-gray-600">{subtitle}</p>
          </div>

          {children}

          <div className="text-center mt-8">
            <p className="text-sm text-gray-600">
              {alternateLink.text}{" "}
              <Link href={alternateLink.href} className="font-medium text-[#5E4FDB] hover:text-[#4E3FCB]">
                {alternateLink.label}
              </Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
