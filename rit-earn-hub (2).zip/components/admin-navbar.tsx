"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Menu, User, LogOut, Home, BarChart2, Users, Settings, FileText, DollarSign, MessageSquare } from "lucide-react"

export default function AdminNavbar() {
  const pathname = usePathname()
  const [userName, setUserName] = useState("")
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)

  useEffect(() => {
    const checkAdmin = () => {
      // Check if admin is authenticated via localStorage
      const adminAuthenticated = localStorage.getItem("adminAuthenticated") === "true"
      const adminEmail = localStorage.getItem("adminEmail")

      if (adminAuthenticated && adminEmail) {
        setUserName(adminEmail.split("@")[0] || "Admin")
      } else {
        setUserName("Admin")
      }
    }

    checkAdmin()
  }, [])

  const handleLogout = () => {
    // Clear admin authentication
    localStorage.removeItem("adminAuthenticated")
    localStorage.removeItem("adminEmail")
    window.location.href = "/"
  }

  const navItems = [
    { name: "Dashboard", href: "/admin", icon: <Home className="h-5 w-5 mr-2" /> },
    { name: "Users", href: "/admin/users", icon: <Users className="h-5 w-5 mr-2" /> },
    { name: "Tasks", href: "/admin/tasks", icon: <FileText className="h-5 w-5 mr-2" /> },
    { name: "Transactions", href: "/admin/transactions", icon: <DollarSign className="h-5 w-5 mr-2" /> },
    { name: "Statistics", href: "/admin/stats", icon: <BarChart2 className="h-5 w-5 mr-2" /> },
    { name: "Telegram Bot", href: "/admin/setup-telegram-bot", icon: <MessageSquare className="h-5 w-5 mr-2" /> },
    { name: "Settings", href: "/admin/settings", icon: <Settings className="h-5 w-5 mr-2" /> },
    { name: "Fix Deposits", href: "/admin/fix-deposits", icon: <DollarSign className="h-5 w-5 mr-2" /> },
    { name: "Analytics", href: "/admin/analytics", icon: <BarChart2 className="h-5 w-5 mr-2" /> },
  ]

  return (
    <header className="bg-primary text-primary-foreground sticky top-0 z-50">
      <div className="container mx-auto px-4">
        <div className="flex h-16 items-center justify-between">
          <div className="flex items-center space-x-2">
            <Link href="/admin" className="flex items-center space-x-2">
              <img src="/images/logo.png" alt="RIT Earn Hub Logo" className="h-8 w-8 rounded-full" />
              <span className="text-xl font-bold">RIT Admin Panel</span>
            </Link>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-4">
            {navItems.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className={`flex items-center px-3 py-2 rounded-md text-sm font-medium ${
                  pathname === item.href
                    ? "bg-primary-foreground text-primary"
                    : "text-primary-foreground hover:bg-primary-foreground/10"
                }`}
              >
                {item.icon}
                {item.name}
              </Link>
            ))}

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" className="bg-primary-foreground text-primary">
                  <User className="h-4 w-4 mr-2" />
                  {userName || "Admin"}
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem asChild>
                  <Link href="/dashboard">View User Dashboard</Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href="/profile">Profile</Link>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={handleLogout} className="text-red-500 cursor-pointer">
                  <LogOut className="h-4 w-4 mr-2" />
                  Logout
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </nav>

          {/* Mobile Menu Button */}
          <div className="md:hidden">
            <Button
              variant="outline"
              size="icon"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="bg-primary-foreground text-primary"
            >
              <Menu className="h-6 w-6" />
            </Button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isMobileMenuOpen && (
          <div className="md:hidden py-2 pb-4">
            <div className="px-2 pt-2 pb-3 space-y-1">
              {navItems.map((item) => (
                <Link
                  key={item.href}
                  href={item.href}
                  className={`flex items-center px-3 py-2 rounded-md text-sm font-medium ${
                    pathname === item.href
                      ? "bg-primary-foreground text-primary"
                      : "text-primary-foreground hover:bg-primary-foreground/10"
                  }`}
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  {item.icon}
                  {item.name}
                </Link>
              ))}
              <Link
                href="/dashboard"
                className="flex items-center px-3 py-2 rounded-md text-sm font-medium text-primary-foreground hover:bg-primary-foreground/10"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                <Home className="h-5 w-5 mr-2" />
                User Dashboard
              </Link>
              <button
                onClick={handleLogout}
                className="flex w-full items-center px-3 py-2 rounded-md text-sm font-medium text-red-500 hover:bg-primary-foreground/10"
              >
                <LogOut className="h-5 w-5 mr-2" />
                Logout
              </button>
            </div>
          </div>
        )}
      </div>
    </header>
  )
}
