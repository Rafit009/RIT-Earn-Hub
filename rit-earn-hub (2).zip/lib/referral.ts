/**
 * Generates a unique referral code for a user
 * @param userId The user's ID
 * @returns A unique referral code
 */
export function generateReferralCode(userId: string): string {
  // Format: RAFIT + first 8 chars of userId + 4 random chars
  const userIdPart = userId.substring(0, 8)
  const randomPart = Math.random().toString(36).substring(2, 6).toUpperCase()
  return `RAFIT${userIdPart}${randomPart}`
}

/**
 * Processes a referral when a user signs up with a referral code
 * @param supabase The Supabase client
 * @param userId The new user's ID
 * @param referralCode The referral code used
 */
export async function processReferral(supabase: any, userId: string, referralCode: string | null) {
  if (!referralCode) return null

  try {
    // Find the referrer by referral code
    const { data: referrer, error } = await supabase
      .from("profiles")
      .select("id")
      .eq("referral_code", referralCode)
      .single()

    if (error || !referrer) return null

    // Update the new user's profile with the referrer's ID
    await supabase.from("profiles").update({ referred_by: referrer.id }).eq("id", userId)

    // Create a referral record
    await supabase.from("referrals").insert([
      {
        referrer_id: referrer.id,
        referred_id: userId,
        reward: 5.0,
      },
    ])

    // Update the referrer's stats
    await supabase
      .from("profiles")
      .update({
        referral_count: supabase.rpc("increment", { row_id: referrer.id }),
        referral_earnings: supabase.rpc("add_amount", { row_id: referrer.id, amount: 5.0 }),
        balance: supabase.rpc("add_amount", { row_id: referrer.id, amount: 5.0 }),
        total_earnings: supabase.rpc("add_amount", { row_id: referrer.id, amount: 5.0 }),
      })
      .eq("id", referrer.id)

    return referrer.id
  } catch (error) {
    console.error("Error processing referral:", error)
    return null
  }
}
