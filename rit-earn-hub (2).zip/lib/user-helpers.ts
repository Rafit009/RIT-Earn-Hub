import { createClient } from "@supabase/supabase-js"

// Initialize Supabase client with service role key for admin operations
const supabaseAdmin = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!, {
  auth: {
    autoRefreshToken: false,
    persistSession: false,
  },
})

/**
 * Ensures a user profile exists in the database.
 * If a profile already exists, it updates the profile.
 * @param userId The user's ID
 * @param profileData The profile data to insert or update
 * @returns A boolean indicating success or failure, and any error message
 */
export async function ensureUserProfile(
  userId: string,
  profileData: {
    username: string
    fullName: string
    email: string
    referralCode: string
    referredBy: string | null
  },
): Promise<{ success: boolean; error?: Error }> {
  try {
    const { username, fullName, email, referralCode, referredBy } = profileData

    // Upsert the profile data
    const { error } = await supabaseAdmin.from("profiles").upsert(
      [
        {
          id: userId,
          username: username,
          full_name: fullName,
          email: email,
          referral_code: referralCode,
          referred_by: referredBy,
        },
      ],
      { onConflict: "id", returning: "minimal" },
    )

    if (error) {
      console.error("Error creating or updating profile:", error)
      return { success: false, error }
    }

    return { success: true }
  } catch (error: any) {
    console.error("Error in ensureUserProfile:", error)
    return { success: false, error: new Error(error.message || "An unexpected error occurred") }
  }
}

/**
 * Generates a unique referral code for a user
 * @param name The user's name
 * @returns A unique referral code
 */
export function generateReferralCode(name: string): string {
  // Format: RAFIT + first 8 chars of userId + 4 random chars
  const prefix = name.substring(0, 3).toUpperCase()
  const randomPart = Math.random().toString(36).substring(2, 7).toUpperCase()
  return `${prefix}${randomPart}`
}
