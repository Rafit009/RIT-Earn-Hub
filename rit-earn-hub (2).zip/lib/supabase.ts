import { createClient } from "@supabase/supabase-js"

const supabaseUrl = "https://ndvalchzbaykkwntxwaf.supabase.co"
const supabaseAnonKey =
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im5kdmFsY2h6YmF5a2t3bnR4d2FmIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDI1MzEwOTIsImV4cCI6MjA1ODEwNzA5Mn0.a1h-lrECbilUbuZpDkkjnz9GTwRrpvspcXg84-usQyU"

export const supabase = createClient(supabaseUrl, supabaseAnonKey)
