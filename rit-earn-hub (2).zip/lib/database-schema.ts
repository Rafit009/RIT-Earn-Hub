import { createClient } from "@supabase/supabase-js"

// Initialize Supabase client with service role key for admin operations
const supabaseAdmin = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!, {
  auth: {
    autoRefreshToken: false,
    persistSession: false,
  },
})

export async function ensureDatabaseSchema() {
  try {
    console.log("Checking database schema...")

    // Check if user_tasks table exists
    const { data: tables, error: tablesError } = await supabaseAdmin.rpc("get_tables")

    if (tablesError) {
      console.error("Error checking tables:", tablesError)
      return
    }

    const userTasksExists = tables.some((table: { table_name: string }) => table.table_name === "user_tasks")

    if (!userTasksExists) {
      console.log("Creating user_tasks table...")
      await supabaseAdmin.rpc("create_user_tasks_table")
    }

    // Check if columns exist in user_tasks table
    const { data: columns, error: columnsError } = await supabaseAdmin.rpc("get_columns", { table_name: "user_tasks" })

    if (columnsError) {
      console.error("Error checking columns:", columnsError)
      return
    }

    const columnNames = columns.map((column: { column_name: string }) => column.column_name)

    // Add missing columns
    const requiredColumns = [
      {
        name: "started_at",
        type: "timestamp with time zone",
        nullable: true,
      },
      {
        name: "submission_date",
        type: "timestamp with time zone",
        nullable: true,
      },
      {
        name: "submission_details",
        type: "text",
        nullable: true,
      },
      {
        name: "admin_approved",
        type: "boolean",
        nullable: true,
        default: "false",
      },
    ]

    for (const column of requiredColumns) {
      if (!columnNames.includes(column.name)) {
        console.log(`Adding missing column: ${column.name}`)
        await supabaseAdmin.rpc("add_column", {
          table_name: "user_tasks",
          column_name: column.name,
          column_type: column.type,
          is_nullable: column.nullable,
          column_default: column.default,
        })
      }
    }

    console.log("Database schema check completed")
    return true
  } catch (error) {
    console.error("Error ensuring database schema:", error)
    return false
  }
}

// Create a function to initialize the database
export async function initializeDatabase() {
  try {
    // Create the necessary RPC functions if they don't exist
    await createRpcFunctions()

    // Ensure the database schema is correct
    return await ensureDatabaseSchema()
  } catch (error) {
    console.error("Error initializing database:", error)
    return false
  }
}

// Create the necessary RPC functions
async function createRpcFunctions() {
  try {
    // Create function to get tables
    await supabaseAdmin.rpc("create_get_tables_function")

    // Create function to get columns
    await supabaseAdmin.rpc("create_get_columns_function")

    // Create function to add column
    await supabaseAdmin.rpc("create_add_column_function")

    // Create function to create user_tasks table
    await supabaseAdmin.rpc("create_user_tasks_table_function")

    return true
  } catch (error) {
    console.error("Error creating RPC functions:", error)
    return false
  }
}
