import { Inter, Poppins, Montserrat } from "next/font/google"

// Define the Poppins font with multiple weights
export const poppins = Poppins({
  subsets: ["latin"],
  weight: ["300", "400", "500", "600", "700"],
  variable: "--font-poppins",
  display: "swap",
})

// Define the Montserrat font for headings
export const montserrat = Montserrat({
  subsets: ["latin"],
  weight: ["700", "800", "900"],
  variable: "--font-montserrat",
  display: "swap",
})

// Define Inter as a fallback font
export const inter = Inter({
  subsets: ["latin"],
  variable: "--font-inter",
  display: "swap",
})
