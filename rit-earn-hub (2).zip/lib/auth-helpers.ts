import { supabase } from "@/lib/supabase"

/**
 * Gets the current authenticated user's ID
 * @returns The user ID or null if not authenticated
 */
export async function getCurrentUserId(): Promise<string | null> {
  try {
    const {
      data: { session },
    } = await supabase.auth.getSession()
    return session?.user?.id || null
  } catch (error) {
    console.error("Error getting current user ID:", error)
    return null
  }
}

/**
 * Checks if the current user is an admin
 * @returns Boolean indicating if the user is an admin
 */
export async function isCurrentUserAdmin(): Promise<boolean> {
  try {
    // First check localStorage for admin authentication
    if (typeof window !== "undefined") {
      const adminAuthenticated = localStorage.getItem("adminAuthenticated") === "true"
      if (adminAuthenticated) {
        return true
      }
    }

    // If not admin by localStorage, check database
    const userId = await getCurrentUserId()
    if (!userId) return false

    const { data, error } = await supabase.from("profiles").select("is_admin").eq("id", userId).single()

    if (error || !data) return false

    return data.is_admin === true
  } catch (error) {
    console.error("Error checking if user is admin:", error)
    return false
  }
}
