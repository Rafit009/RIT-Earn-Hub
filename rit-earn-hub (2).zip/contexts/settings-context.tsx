"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"
import { createClientComponentClient } from "@supabase/auth-helpers-nextjs"

interface SettingsContextType {
  settings: Record<string, any>
  isLoading: boolean
  error: string | null
  refreshSettings: () => Promise<void>
  getSetting: (key: string, defaultValue?: any) => any
  isAdmin: boolean
}

const SettingsContext = createContext<SettingsContextType | undefined>(undefined)

export function SettingsProvider({ children }: { children: ReactNode }) {
  const supabase = createClientComponentClient()
  const [settings, setSettings] = useState<Record<string, any>>({})
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [isAdmin, setIsAdmin] = useState(false)

  const fetchSettings = async () => {
    try {
      setIsLoading(true)
      setError(null)

      // First check if user is authenticated and is admin
      const {
        data: { user },
      } = await supabase.auth.getUser()

      if (!user) {
        // If not authenticated, just load public settings
        await fetchPublicSettings()
        return
      }

      // Check if user is admin
      const { data: profile } = await supabase.from("profiles").select("is_admin").eq("id", user.id).single()

      if (profile?.is_admin) {
        setIsAdmin(true)
        // Fetch all settings for admin
        const response = await fetch("/api/admin/settings")

        if (!response.ok) {
          const errorData = await response.json()
          throw new Error(errorData.error || "Failed to fetch settings")
        }

        const data = await response.json()
        setSettings(data)
      } else {
        // For non-admin users, fetch public settings
        await fetchPublicSettings()
      }
    } catch (err: any) {
      console.error("Error fetching settings:", err)
      setError(err.message || "Failed to load settings")
      // Still try to load public settings on error
      await fetchPublicSettings()
    } finally {
      setIsLoading(false)
    }
  }

  const fetchPublicSettings = async () => {
    try {
      // Fetch public settings directly from the database
      const { data, error } = await supabase
        .from("settings")
        .select("key, value")
        .in("key", ["platform_name", "currency_symbol", "min_deposit", "min_withdrawal", "maintenance_mode"])

      if (error) throw error

      // Transform data into a more usable format
      const formattedSettings = data.reduce((acc: Record<string, any>, setting) => {
        acc[setting.key] = setting.value
        return acc
      }, {})

      setSettings(formattedSettings)
    } catch (err: any) {
      console.error("Error fetching public settings:", err)
      // Set default values for essential settings
      setSettings({
        platform_name: "RIT Earn Hub",
        currency_symbol: "৳",
        min_deposit: 50,
        min_withdrawal: 50,
        maintenance_mode: false,
      })
    }
  }

  useEffect(() => {
    fetchSettings()
  }, [])

  const getSetting = (key: string, defaultValue: any = null) => {
    return settings[key] !== undefined ? settings[key] : defaultValue
  }

  return (
    <SettingsContext.Provider
      value={{
        settings,
        isLoading,
        error,
        refreshSettings: fetchSettings,
        getSetting,
        isAdmin,
      }}
    >
      {children}
    </SettingsContext.Provider>
  )
}

export function useSettings() {
  const context = useContext(SettingsContext)
  if (context === undefined) {
    throw new Error("useSettings must be used within a SettingsProvider")
  }
  return context
}
